/* 
 *  Copyright (C) 2000 - 2011 aw2.0 Ltd
 *
 *  This file is part of Open BlueDragon (OpenBD) CFML Server Engine.
 *  
 *  OpenBD is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  Free Software Foundation,version 3.
 *  
 *  OpenBD is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  
 *  You should have received a copy of the GNU General Public License
 *  along with OpenBD.  If not, see http://www.gnu.org/licenses/
 *  
 *  Additional permission under GNU GPL version 3 section 7
 *  
 *  If you modify this Program, or any covered work, by linking or combining 
 *  it with any of the JARS listed in the README.txt (or a modified version of 
 *  (that library), containing parts covered by the terms of that JAR, the 
 *  licensors of this Program grant you additional permission to convey the 
 *  resulting work. 
 *  README.txt @ http://www.openbluedragon.org/license/README.txt
 *  
 *  http://www.openbluedragon.org/
 */

package net.aw20.msexchange.ntlm;

import java.io.IOException;

import jcifs.ntlmssp.Type1Message;
import jcifs.ntlmssp.Type2Message;
import jcifs.ntlmssp.Type3Message;
import jcifs.util.Base64;

import org.apache.http.impl.auth.NTLMEngine;
import org.apache.http.impl.auth.NTLMEngineException;

public class JCIFSEngine implements NTLMEngine {

	public String generateType1Msg(String domain, String workstation) throws NTLMEngineException {

		Type1Message t1m = new Type1Message(Type1Message.getDefaultFlags(), domain, workstation);
		return Base64.encode(t1m.toByteArray());
	}

	public String generateType3Msg(String username, String password, String domain, String workstation, String challenge) throws NTLMEngineException {
		Type2Message t2m;
		try {
			t2m = new Type2Message(Base64.decode(challenge));
		} catch (IOException ex) {
			throw new NTLMEngineException("Invalid Type2 message", ex);
		}
		Type3Message t3m = new Type3Message(t2m, password, domain, username, workstation, 0);
		return Base64.encode(t3m.toByteArray());
	}

}
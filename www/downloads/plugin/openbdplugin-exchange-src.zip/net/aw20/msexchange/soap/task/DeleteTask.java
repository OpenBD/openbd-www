/* 
 *  Copyright (C) 2000 - 2011 aw2.0 Ltd
 *
 *  This file is part of Open BlueDragon (OpenBD) CFML Server Engine.
 *  
 *  OpenBD is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  Free Software Foundation,version 3.
 *  
 *  OpenBD is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  
 *  You should have received a copy of the GNU General Public License
 *  along with OpenBD.  If not, see http://www.gnu.org/licenses/
 *  
 *  Additional permission under GNU GPL version 3 section 7
 *  
 *  If you modify this Program, or any covered work, by linking or combining 
 *  it with any of the JARS listed in the README.txt (or a modified version of 
 *  (that library), containing parts covered by the terms of that JAR, the 
 *  licensors of this Program grant you additional permission to convey the 
 *  resulting work. 
 *  README.txt @ http://www.openbluedragon.org/license/README.txt
 *  
 *  http://www.openbluedragon.org/
 */

package net.aw20.msexchange.soap.task;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.aw20.msexchange.MSExchangeException;
import net.aw20.msexchange.soap.calendar.DeleteCalendarItem;
import net.aw20.msexchange.soap.items.GetItem;
import net.aw20.openbd.plugins.exchange.helpers.ExchangeUtility;

import com.naryx.tagfusion.cfm.engine.cfStructData;

public class DeleteTask extends GetItem {

	public static final String TASK_TAG = "m:DeleteItemResponseMessage";

	public static final String AFFECTED_TASK_OCCURRENCES = "$(AFFECTED_TASK_OCCURRENCES)";

	public DeleteTask() {
		params = new HashMap<String, String>();
	}

	/**
	 * Sets the <b>AffectedTaskOccurrences</b> parameter for the Delete SOAP Template to the input given. If input is null then the parameter is set to <b>"AllOccurrences"</b>.
	 * 
	 * @param _val
	 */
	private void setAffectedTaskOccurrences(String _val) {
		// Default value "AllOccurrences"
		if (_val != null) {
			params.put(AFFECTED_TASK_OCCURRENCES, _val);
		} else {
			params.put(AFFECTED_TASK_OCCURRENCES, "AllOccurrences");
		}

	}

	/**
	 * Based on AffectedTaskOccurrences value in the input ( i.e."AllOccurrences" or "SpecifiedOccurrenceOnly") this function either deletes all or specific occurrences.
	 * 
	 * @param _struct
	 */
	public void setDeletePattern(cfStructData _struct) {
		if ((String) _struct.get("id") != null) {
			params.put(DeleteCalendarItem.DELETE_ITEM_TAG, " <t:ItemId Id=\"" + (String) _struct.get("id") + "\" />");
			setAffectedTaskOccurrences(ExchangeUtility.parseAffectedTaskOccurrences((String) _struct.get("AffectedTaskOccurrences")));
		} else {
			throw new IllegalArgumentException("Invalid input for Delete Task operation.");
		}
	}

	/**
	 * This returns back the SOAP-Action
	 * 
	 * @return String(SOAP-Action url)
	 */
	@Override
	public String getSoapAction() {
		return "http://schemas.microsoft.com/exchange/services/2006/messages/DeleteItem";
	}

	@Override
	public String getSoapPacket() throws IOException {
		return getSoapTemplate("/net/aw20/msexchange/soap/templates/DeleteTaskItem.soap", params);
	}

	/**
	 * Upon a successful 200 status code; this represents the server response raw XML packet
	 * 
	 * @param xmlResponse
	 * @return parsed xmlResponse to List object
	 * @throws MSExchangeException
	 */
	@Override
	public List<Map<String, Object>> onResponse(String xmlResponse) throws MSExchangeException {
		List<Map<String, Object>> tasks = new ArrayList<Map<String, Object>>();
		tasks = processRequest(xmlResponse, TASK_TAG);

		// Calls the processError() function when the Error Response is received from the server.
		if (tasks.isEmpty()) {
			tasks = processError(xmlResponse);
		}
		return tasks;
	}

}

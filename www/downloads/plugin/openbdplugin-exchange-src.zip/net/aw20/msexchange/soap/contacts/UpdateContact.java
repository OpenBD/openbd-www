/* 
 *  Copyright (C) 2000 - 2011 aw2.0 Ltd
 *
 *  This file is part of Open BlueDragon (OpenBD) CFML Server Engine.
 *  
 *  OpenBD is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  Free Software Foundation,version 3.
 *  
 *  OpenBD is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  
 *  You should have received a copy of the GNU General Public License
 *  along with OpenBD.  If not, see http://www.gnu.org/licenses/
 *  
 *  Additional permission under GNU GPL version 3 section 7
 *  
 *  If you modify this Program, or any covered work, by linking or combining 
 *  it with any of the JARS listed in the README.txt (or a modified version of 
 *  (that library), containing parts covered by the terms of that JAR, the 
 *  licensors of this Program grant you additional permission to convey the 
 *  resulting work. 
 *  README.txt @ http://www.openbluedragon.org/license/README.txt
 *  
 *  http://www.openbluedragon.org/
 */

package net.aw20.msexchange.soap.contacts;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.aw20.msexchange.MSExchangeException;
import net.aw20.msexchange.soap.SOAPActionBase;
import net.aw20.msexchange.soap.items.FindItem;
import net.aw20.openbd.plugins.exchange.helpers.ExchangeUtility;

import org.apache.commons.lang.StringEscapeUtils;

public class UpdateContact extends FindItem {

	public UpdateContact() {
		params = new HashMap<String, String>();
	}

	/** UPDATEes the surname field */
	public static final String UPDATE_FIELD_SURNAME = "$(SUR_NAME)";

	public static final String UPDATE_FIELD_GIVENNAME = "$(GIVEN_NAME)";

	public static final String UPDATE_FIELD_MANAGER = "$(MANAGER)";

	/** UPDATEes company name field */
	public static final String UPDATE_FIELD_COMPANY = "$(COMPANY_NAME)";

	public static final String UPDATE_FIELD_DISPLAY_NAME = "$(DISPLAY_NAME)";

	public static final String UPDATE_FIELD_INITIALS = "$(INITIALS)";

	public static final String UPDATE_FIELD_MIDDLE_NAME = "$(MIDDLE_NAME)";

	public static final String UPDATE_FIELD_NICK_NAME = "$(NICK_NAME)";

	public static final String UPDATE_FIELD_TITLE = "$(TITLE)";

	public static final String UPDATE_FIELD_FIRST_NAME = "$(FIRST_NAME)";

	public static final String UPDATE_FIELD_LAST_NAME = "$(LAST_NAME)";

	public static final String UPDATE_FIELD_SUFFIX = "$(SUFFIX)";

	public static final String UPDATE_FIELD_FULL_NAME = "$(FULL_NAME)";

	public static final String UPDATE_FIELD_JOB_TITLE = "$(JOB_TITLE)";

	public static final String UPDATE_FIELD_OFFICE_LOCATION = "$(OFFICE_LOCATION)";

	public static final String UPDATE_FIELD_CHANGE_KEY = "$(CHANGE_KEY)";

	public static final String UPDATE_FIELD_BUSINESS_HOMEPAGE = "$(BUSINESS_HOME_PAGE)";

	public static final String UPDATE_FIELD_ASSISTANT_NAME = "$(ASSISTANT_NAME)";

	public static final String UPDATE_FIELD_ASSISTANT_PHONE = "$(ASSISTANT_PHONE)";

	public static final String UPDATE_FIELD_BUSINESS_PHONE1 = "$(BUSINESS_PHONE1)";

	public static final String UPDATE_FIELD_BUSINESS_PHONE2 = "$(BUSINESS_PHONE2)";

	public static final String UPDATE_FIELD_BUSINESS_FAX = "$(BUSINESS_FAX)";

	public static final String UPDATE_FIELD_HOME_PHONE1 = "$(HOME_PHONE1)";

	public static final String UPDATE_FIELD_HOME_PHONE2 = "$(HOME_PHONE2)";

	public static final String UPDATE_FIELD_HOME_FAX = "$(HOME_FAX)";

	public static final String UPDATE_FIELD_MOBILE_PHONE = "$(MOBILE_PHONE)";

	public static final String UPDATE_FIELD_CALL_BACK = "$(CALL_BACK)";

	public static final String UPDATE_FIELD_CAR_PHONE = "$(CAR_PHONE)";

	public static final String UPDATE_FIELD_OTHER_PHONE = "$(OTHER_PHONE)";

	public static final String UPDATE_FIELD_PAGER = "$(PAGER)";

	public static final String UPDATE_FIELD_PRIMARY_PHONE = "$(PRIMARY_PHONE)";

	public static final String UPDATE_FIELD_COMPANY_MAIN_PHONE = "$(COMPANY_MAIN_PHONE)";

	public static final String UPDATE_FIELD_ISDN_NUMBER = "$(ISDN_NUMBER)";

	public static final String UPDATE_FIELD_RADIO_PHONE = "$(RADIO_PHONE)";

	public static final String UPDATE_FIELD_TELEX_NUMBER = "$(TELEX_NUMBER)";

	public static final String UPDATE_FIELD_TTYTDD_NUMBER = "$(TTYTDD_NUMBER)";

	public static final String UPDATE_FIELD_EMAIL_DISPLAY_NAME1 = "$(EMAIL_ADDRESS_DISPLAY_NAME_1)";

	public static final String UPDATE_FIELD_EMAIL_DISPLAY_NAME2 = "$(EMAIL_ADDRESS_DISPLAY_NAME_2)";

	public static final String UPDATE_FIELD_EMAIL_DISPLAY_NAME3 = "$(EMAIL_ADDRESS_DISPLAY_NAME_3)";

	public static final String UPDATE_FIELD_IM_ADDRESS_1 = "$(IM_ADDRESS_1)";

	public static final String UPDATE_FIELD_IM_ADDRESS_2 = "$(IM_ADDRESS_2)";

	public static final String UPDATE_FIELD_IM_ADDRESS_3 = "$(IM_ADDRESS_3)";

	public static final String UPDATE_FIELD_DEPARTMENT = "$(DEPARTMENT)";

	public static final String UPDATE_FIELD_BUSINESS_STREET = "$(BUSINESS_STREET)";

	public static final String UPDATE_FIELD_BUSINESS_CITY = "$(BUSINESS_CITY)";

	public static final String UPDATE_FIELD_BUSINESS_STATE = "$(BUSINESS_STATE)";

	public static final String UPDATE_FIELD_BUSINESS_COUNTRY = "$(BUSINESS_COUNTRY)";

	public static final String UPDATE_FIELD_BUSINESS_POSTALCODE = "$(BUSINESS_POSTALCODE)";

	public static final String UPDATE_FIELD_HOME_STREET = "$(HOME_STREET)";

	public static final String UPDATE_FIELD_HOME_CITY = "$(HOME_CITY)";

	public static final String UPDATE_FIELD_HOME_STATE = "$(HOME_STATE)";

	public static final String UPDATE_FIELD_HOME_COUNTRY = "$(HOME_COUNTRY)";

	public static final String UPDATE_FIELD_HOME_POSTALCODE = "$(HOME_POSTALCODE)";

	public static final String UPDATE_FIELD_OTHER_STREET = "$(OTHER_STREET)";

	public static final String UPDATE_FIELD_OTHER_CITY = "$(OTHER_CITY)";

	public static final String UPDATE_FIELD_OTHER_STATE = "$(OTHER_STATE)";

	public static final String UPDATE_FIELD_OTHER_COUNTRY = "$(OTHER_COUNTRY)";

	public static final String UPDATE_FIELD_OTHER_POSTALCODE = "$(OTHER_POSTALCODE)";

	public static final String UPDATE_FIELD_NOTES = "$(NOTES)";

	private String id = "";

	private String changeKey = "";

	/**
	 * Provides the ID of an Item.
	 * 
	 * @return Id
	 */
	public String getId() {
		return this.id;
	}

	/**
	 * Sets the <b>ID</b> of the Item for Update Operation.
	 * 
	 * @param _Id
	 */
	public void setId(String _Id) {
		this.id = _Id;
		params.put(SOAPActionBase.ID, _Id);
	}

	/**
	 * Updates the <b>Surname</b> of the Contact.
	 * 
	 * @param _surName
	 */
	public void setSurName(String _surName) {
		if (_surName != null) {
			params.put(UPDATE_FIELD_SURNAME, "<t:SetItemField><t:FieldURI FieldURI=\"contacts:Surname\"/><t:Contact><t:Surname>" + StringEscapeUtils.escapeXml(_surName) + "</t:Surname></t:Contact></t:SetItemField>");
		} else {
			params.put(UPDATE_FIELD_SURNAME, "");
		}
	}

	/**
	 * Updates the <b>GivenName</b> of the Contact.
	 * 
	 * @param _givenName
	 */
	public void setGivenName(String _givenName) {
		if (_givenName != null) {
			params.put(UPDATE_FIELD_GIVENNAME, "<t:SetItemField><t:FieldURI FieldURI=\"contacts:GivenName\"/><t:Contact><t:GivenName>" + StringEscapeUtils.escapeXml(_givenName) + "</t:GivenName></t:Contact></t:SetItemField>");
		} else {
			params.put(UPDATE_FIELD_GIVENNAME, "");
		}
	}

	/**
	 * Updates the <b>Manager</b> of the Contact.
	 * 
	 * @param _val
	 */
	public void setManager(String _val) {
		if (_val != null) {
			params.put(UPDATE_FIELD_MANAGER, "<t:SetItemField><t:FieldURI FieldURI=\"contacts:Manager\"/><t:Contact><t:Manager>" + StringEscapeUtils.escapeXml(_val) + "</t:Manager></t:Contact></t:SetItemField>");
		} else {
			params.put(UPDATE_FIELD_MANAGER, "");
		}
	}

	/**
	 * Updates the <b>Company</b> of the Contact.
	 * 
	 * @param _company
	 */
	public void setCompany(String _company) {
		if (_company != null) {
			params.put(UPDATE_FIELD_COMPANY, "<t:SetItemField><t:FieldURI FieldURI=\"contacts:CompanyName\"/><t:Contact><t:CompanyName>" + StringEscapeUtils.escapeXml(_company) + "</t:CompanyName></t:Contact></t:SetItemField>");
		} else {
			params.put(UPDATE_FIELD_COMPANY, "");
		}
	}

	/**
	 * Updates the <b>Email,DisplayName</b> of the Contact.
	 * 
	 * @param _email
	 * @param _name
	 */
	public void setEmailAndDisplayName(String _email, String _name) {
		if (_name == null) {
			_name = _email;
		}
		if (_email != null) {
			if (ExchangeUtility.validateEmail(_email)) {
				params.put(UPDATE_FIELD_EMAIL_DISPLAY_NAME1, "<t:SetItemField><t:IndexedFieldURI FieldURI=\"contacts:EmailAddress\" FieldIndex=\"EmailAddress1\" /><t:Contact><t:EmailAddresses><t:Entry Key=\"EmailAddress1\" Name=\"" + StringEscapeUtils.escapeXml(_name) + "\">" + StringEscapeUtils.escapeXml(_email) + "</t:Entry></t:EmailAddresses></t:Contact></t:SetItemField>");
			} else {
				throw new IllegalArgumentException("Email should be in valid format.");
			}

		} else {
			params.put(UPDATE_FIELD_EMAIL_DISPLAY_NAME1, "");
		}
	}

	public void setEmailAndDisplayName2(String _email, String _name) {
		if (_name == null) {
			_name = _email;
		}
		if (_email != null) {
			if (ExchangeUtility.validateEmail(_email)) {
				params.put(UPDATE_FIELD_EMAIL_DISPLAY_NAME2, "<t:SetItemField><t:IndexedFieldURI FieldURI=\"contacts:EmailAddress\" FieldIndex=\"EmailAddress2\" /><t:Contact><t:EmailAddresses><t:Entry Key=\"EmailAddress2\" Name=\"" + StringEscapeUtils.escapeXml(_name) + "\">" + StringEscapeUtils.escapeXml(_email) + "</t:Entry></t:EmailAddresses></t:Contact></t:SetItemField>");
			} else {
				throw new IllegalArgumentException("Email2 should be in valid format.");
			}
		} else {
			params.put(UPDATE_FIELD_EMAIL_DISPLAY_NAME2, "");
		}
	}

	public void setEmailAndDisplayName3(String _email, String _name) {
		if (_name == null) {
			_name = _email;
		}
		if (_email != null) {
			if (ExchangeUtility.validateEmail(_email)) {
				params.put(UPDATE_FIELD_EMAIL_DISPLAY_NAME3, "<t:SetItemField><t:IndexedFieldURI FieldURI=\"contacts:EmailAddress\" FieldIndex=\"EmailAddress3\" /><t:Contact><t:EmailAddresses><t:Entry Key=\"EmailAddress3\" Name=\"" + StringEscapeUtils.escapeXml(_name) + "\">" + StringEscapeUtils.escapeXml(_email) + "</t:Entry></t:EmailAddresses></t:Contact></t:SetItemField>");
			} else {
				throw new IllegalArgumentException("Email3 should be in valid format.");
			}
		} else {
			params.put(UPDATE_FIELD_EMAIL_DISPLAY_NAME3, "");
		}
	}

	/**
	 * Updates the <b>ImAddress</b> of the Contact.
	 * 
	 * @param _val
	 */
	public void setImAddress(String _val) {
		if (_val != null) {
			params.put(UPDATE_FIELD_IM_ADDRESS_1, "<t:SetItemField><t:IndexedFieldURI FieldURI=\"contacts:ImAddress\" FieldIndex=\"ImAddress1\" /><t:Contact><t:ImAddresses><t:Entry Key=\"ImAddress1\">" + StringEscapeUtils.escapeXml(_val) + "</t:Entry></t:ImAddresses></t:Contact></t:SetItemField>");
		} else {
			params.put(UPDATE_FIELD_IM_ADDRESS_1, "");
		}
	}

	public void setImAddress2(String _val) {
		if (_val != null) {
			params.put(UPDATE_FIELD_IM_ADDRESS_2, "<t:SetItemField><t:IndexedFieldURI FieldURI=\"contacts:ImAddress\" FieldIndex=\"ImAddress2\" /><t:Contact><t:ImAddresses><t:Entry Key=\"ImAddress2\">" + StringEscapeUtils.escapeXml(_val) + "</t:Entry></t:ImAddresses></t:Contact></t:SetItemField>");
		} else {
			params.put(UPDATE_FIELD_IM_ADDRESS_2, "");
		}
	}

	public void setImAddress3(String _val) {
		if (_val != null) {
			params.put(UPDATE_FIELD_IM_ADDRESS_3, "<t:SetItemField><t:IndexedFieldURI FieldURI=\"contacts:ImAddress\" FieldIndex=\"ImAddress3\" /><t:Contact><t:ImAddresses><t:Entry Key=\"ImAddress3\">" + StringEscapeUtils.escapeXml(_val) + "</t:Entry></t:ImAddresses></t:Contact></t:SetItemField>");
		} else {
			params.put(UPDATE_FIELD_IM_ADDRESS_3, "");
		}
	}

	/**
	 * Updates the <b>DisplayName</b> of the Contact.
	 * 
	 * @param _val
	 */
	public void setDisplayName(String _val) {
		if (_val != null) {
			params.put(UPDATE_FIELD_DISPLAY_NAME, "<t:SetItemField><t:FieldURI FieldURI=\"contacts:DisplayName\"/><t:Contact><t:DisplayName>" + StringEscapeUtils.escapeXml(_val) + "</t:DisplayName></t:Contact></t:SetItemField>");
		} else {
			params.put(UPDATE_FIELD_DISPLAY_NAME, "");
		}
	}

	/**
	 * Updates the <b>Initials</b> of the Contact.
	 * 
	 * @param _initials
	 */
	public void setInitials(String _initials) {
		params.put(UPDATE_FIELD_INITIALS, StringEscapeUtils.escapeXml(_initials));
	}

	/**
	 * Updates the <b>MiddleName</b> of the Contact.
	 * 
	 * @param _middleName
	 */
	public void setMiddleName(String _middleName) {
		if (_middleName != null) {
			params.put(UPDATE_FIELD_MIDDLE_NAME, "<t:SetItemField><t:FieldURI FieldURI=\"contacts:MiddleName\"/><t:Contact><t:MiddleName>" + StringEscapeUtils.escapeXml(_middleName) + "</t:MiddleName></t:Contact></t:SetItemField>");
		} else {
			params.put(UPDATE_FIELD_MIDDLE_NAME, "");
		}
	}

	/**
	 * Updates the <b>NickName</b> of the Contact.
	 * 
	 * @param _nickName
	 */
	public void setNickName(String _nickName) {
		params.put(UPDATE_FIELD_NICK_NAME, StringEscapeUtils.escapeXml(_nickName));
	}

	/**
	 * Updates the <b>Title</b> of the Contact.
	 * 
	 * @param _title
	 */
	public void setTitle(String _title) {
		params.put(UPDATE_FIELD_TITLE, StringEscapeUtils.escapeXml(_title));
	}

	/**
	 * Updates the <b>FirstName</b> of the Contact.
	 * 
	 * @param _firstName
	 */
	public void setFirstName(String _firstName) {
		params.put(UPDATE_FIELD_FIRST_NAME, StringEscapeUtils.escapeXml(_firstName));
	}

	/**
	 * Updates the <b>LastName</b> of the Contact.
	 * 
	 * @param _lastName
	 */
	public void setLastName(String _lastName) {
		params.put(UPDATE_FIELD_LAST_NAME, StringEscapeUtils.escapeXml(_lastName));
	}

	/**
	 * Updates the <b>Suffix</b> of the Contact.
	 * 
	 * @param _suffix
	 */
	public void setSuffix(String _suffix) {
		params.put(UPDATE_FIELD_SUFFIX, StringEscapeUtils.escapeXml(_suffix));
	}

	/**
	 * Updates the <b>FullName</b> of the Contact.
	 * 
	 * @param _fullName
	 */
	public void setFullName(String _fullName) {
		params.put(UPDATE_FIELD_FULL_NAME, StringEscapeUtils.escapeXml(_fullName));
	}

	/**
	 * Updates the <b>MobilePhone</b> Number of the Contact.
	 * 
	 * @param _mobilePhone
	 */
	public void setMobilePhone(String _mobilePhone) {
		if (_mobilePhone != null) {
			params.put(UPDATE_FIELD_MOBILE_PHONE, "<t:SetItemField><t:IndexedFieldURI FieldURI=\"contacts:PhoneNumber\" FieldIndex=\"MobilePhone\"/><t:Contact><t:PhoneNumbers><t:Entry Key=\"MobilePhone\">" + StringEscapeUtils.escapeXml(_mobilePhone) + "</t:Entry></t:PhoneNumbers></t:Contact></t:SetItemField>");
		} else {
			params.put(UPDATE_FIELD_MOBILE_PHONE, "");
		}
	}

	/**
	 * Updates the <b>JobTitle</b> of the Contact.
	 * 
	 * @param _jobTitle
	 */
	public void setJobTitle(String _jobTitle) {
		if (_jobTitle != null) {
			params.put(UPDATE_FIELD_JOB_TITLE, "<t:SetItemField><t:FieldURI FieldURI=\"contacts:JobTitle\"/><t:Contact><t:JobTitle>" + StringEscapeUtils.escapeXml(_jobTitle) + "</t:JobTitle></t:Contact></t:SetItemField>");
		} else {
			params.put(UPDATE_FIELD_JOB_TITLE, "");
		}
	}

	/**
	 * Updates the <b>OfficeLocation</b> of the Contact.
	 * 
	 * @param _val
	 */
	public void setOfficeLocation(String _val) {
		if (_val != null) {
			params.put(UPDATE_FIELD_OFFICE_LOCATION, "<t:SetItemField><t:FieldURI FieldURI=\"contacts:OfficeLocation\"/><t:Contact><t:OfficeLocation>" + StringEscapeUtils.escapeXml(_val) + "</t:OfficeLocation></t:Contact></t:SetItemField>");
		} else {
			params.put(UPDATE_FIELD_OFFICE_LOCATION, "");
		}
	}

	/**
	 * Updates the <b>Notes</b> of the Contact.
	 * 
	 * @param _val
	 */
	public void setNotes(String _val) {
		if (_val != null) {
			params.put(UPDATE_FIELD_NOTES, "<t:SetItemField><t:FieldURI FieldURI=\"item:Body\"/><t:Contact><t:Body BodyType=\"Text\">" + StringEscapeUtils.escapeXml(_val) + "</t:Body></t:Contact></t:SetItemField>");
		} else {
			params.put(UPDATE_FIELD_NOTES, "");
		}
	}

	/**
	 * Updates the <b>OtherStreet</b> of the Contact.
	 * 
	 * @param _val
	 */
	public void setOtherStreet(String _val) {
		if (_val != null) {
			params.put(UPDATE_FIELD_OTHER_STREET, "<t:SetItemField><t:IndexedFieldURI FieldURI=\"contacts:PhysicalAddress:Street\" FieldIndex=\"Other\"/><t:Contact><t:PhysicalAddresses><t:Entry Key=\"Other\"><t:Street>" + StringEscapeUtils.escapeXml(_val) + "</t:Street></t:Entry></t:PhysicalAddresses></t:Contact></t:SetItemField>");
		} else {
			params.put(UPDATE_FIELD_OTHER_STREET, "");
		}
	}

	/**
	 * Updates the <b>OtherCity</b> of the Contact.
	 * 
	 * @param _val
	 */
	public void setOtherCity(String _val) {
		if (_val != null) {
			params.put(UPDATE_FIELD_OTHER_CITY, "<t:SetItemField><t:IndexedFieldURI FieldURI=\"contacts:PhysicalAddress:City\" FieldIndex=\"Other\"/><t:Contact><t:PhysicalAddresses><t:Entry Key=\"Other\"><t:City>" + StringEscapeUtils.escapeXml(_val) + "</t:City></t:Entry></t:PhysicalAddresses></t:Contact></t:SetItemField>");
		} else {
			params.put(UPDATE_FIELD_OTHER_CITY, "");
		}
	}

	/**
	 * Updates the <b>OtherState</b> of the Contact.
	 * 
	 * @param _val
	 */
	public void setOtherState(String _val) {
		if (_val != null) {
			params.put(UPDATE_FIELD_OTHER_STATE, "<t:SetItemField><t:IndexedFieldURI FieldURI=\"contacts:PhysicalAddress:State\" FieldIndex=\"Other\"/><t:Contact><t:PhysicalAddresses><t:Entry Key=\"Other\"><t:State>" + StringEscapeUtils.escapeXml(_val) + "</t:State></t:Entry></t:PhysicalAddresses></t:Contact></t:SetItemField>");
		} else {
			params.put(UPDATE_FIELD_OTHER_STATE, "");
		}
	}

	/**
	 * Updates the <b>OtherCountry</b> of the Contact.
	 * 
	 * 
	 * @param _val
	 */
	public void setOtherCountry(String _val) {
		if (_val != null) {
			params.put(UPDATE_FIELD_OTHER_COUNTRY, "<t:SetItemField><t:IndexedFieldURI FieldURI=\"contacts:PhysicalAddress:CountryOrRegion\" FieldIndex=\"Other\"/><t:Contact><t:PhysicalAddresses><t:Entry Key=\"Other\"><t:CountryOrRegion>" + StringEscapeUtils.escapeXml(_val) + "</t:CountryOrRegion></t:Entry></t:PhysicalAddresses></t:Contact></t:SetItemField>");
		} else {
			params.put(UPDATE_FIELD_OTHER_COUNTRY, "");
		}
	}

	/**
	 * Updates the <b>OtherPostalCode</b> of the Contact.
	 * 
	 * @param _val
	 */
	public void setOtherPostalCode(String _val) {
		if (_val != null) {
			params.put(UPDATE_FIELD_OTHER_POSTALCODE, "<t:SetItemField><t:IndexedFieldURI FieldURI=\"contacts:PhysicalAddress:PostalCode\" FieldIndex=\"Other\"/><t:Contact><t:PhysicalAddresses><t:Entry Key=\"Other\"><t:PostalCode>" + StringEscapeUtils.escapeXml(_val) + "</t:PostalCode></t:Entry></t:PhysicalAddresses></t:Contact></t:SetItemField>");
		} else {
			params.put(UPDATE_FIELD_OTHER_POSTALCODE, "");
		}
	}

	/**
	 * Updates the <b>HomeStreet</b> of the Contact.
	 * 
	 * @param _val
	 */
	public void setHomeStreet(String _val) {
		if (_val != null) {
			params.put(UPDATE_FIELD_HOME_STREET, "<t:SetItemField><t:IndexedFieldURI FieldURI=\"contacts:PhysicalAddress:Street\" FieldIndex=\"Home\"/><t:Contact><t:PhysicalAddresses><t:Entry Key=\"Home\"><t:Street>" + StringEscapeUtils.escapeXml(_val) + "</t:Street></t:Entry></t:PhysicalAddresses></t:Contact></t:SetItemField>");
		} else {
			params.put(UPDATE_FIELD_HOME_STREET, "");
		}
	}

	/**
	 * Updates the <b>HomeCity</b> of the Contact.
	 * 
	 * @param _val
	 */
	public void setHomeCity(String _val) {
		if (_val != null) {
			params.put(UPDATE_FIELD_HOME_CITY, "<t:SetItemField><t:IndexedFieldURI FieldURI=\"contacts:PhysicalAddress:City\" FieldIndex=\"Home\"/><t:Contact><t:PhysicalAddresses><t:Entry Key=\"Home\"><t:City>" + StringEscapeUtils.escapeXml(_val) + "</t:City></t:Entry></t:PhysicalAddresses></t:Contact></t:SetItemField>");
		} else {
			params.put(UPDATE_FIELD_HOME_CITY, "");
		}
	}

	/**
	 * Updates the <b>HomeState</b> of the Contact.
	 * 
	 * @param _val
	 */
	public void setHomeState(String _val) {
		if (_val != null) {
			params.put(UPDATE_FIELD_HOME_STATE, "<t:SetItemField><t:IndexedFieldURI FieldURI=\"contacts:PhysicalAddress:State\" FieldIndex=\"Home\"/><t:Contact><t:PhysicalAddresses><t:Entry Key=\"Home\"><t:State>" + StringEscapeUtils.escapeXml(_val) + "</t:State></t:Entry></t:PhysicalAddresses></t:Contact></t:SetItemField>");
		} else {
			params.put(UPDATE_FIELD_HOME_STATE, "");
		}
	}

	/**
	 * Updates the <b>HomeCountry</b> of the Contact.
	 * 
	 * @param _val
	 */
	public void setHomeCountry(String _val) {
		if (_val != null) {
			params.put(UPDATE_FIELD_HOME_COUNTRY, "<t:SetItemField><t:IndexedFieldURI FieldURI=\"contacts:PhysicalAddress:CountryOrRegion\" FieldIndex=\"Home\"/><t:Contact><t:PhysicalAddresses><t:Entry Key=\"Home\"><t:CountryOrRegion>" + StringEscapeUtils.escapeXml(_val) + "</t:CountryOrRegion></t:Entry></t:PhysicalAddresses></t:Contact></t:SetItemField>");
		} else {
			params.put(UPDATE_FIELD_HOME_COUNTRY, "");
		}
	}

	/**
	 * Updates the <b>HomePostalCode</b> of the Contact.
	 * 
	 * @param _val
	 */
	public void setHomePostalCode(String _val) {
		if (_val != null) {
			params.put(UPDATE_FIELD_HOME_POSTALCODE, "<t:SetItemField><t:IndexedFieldURI FieldURI=\"contacts:PhysicalAddress:PostalCode\" FieldIndex=\"Home\"/><t:Contact><t:PhysicalAddresses><t:Entry Key=\"Home\"><t:PostalCode>" + StringEscapeUtils.escapeXml(_val) + "</t:PostalCode></t:Entry></t:PhysicalAddresses></t:Contact></t:SetItemField>");
		} else {
			params.put(UPDATE_FIELD_HOME_POSTALCODE, "");
		}
	}

	/**
	 * Updates the <b>BusinessStreet</b> of the Contact.
	 * 
	 * @param _val
	 */
	public void setBusinessStreet(String _val) {
		if (_val != null) {
			params.put(UPDATE_FIELD_BUSINESS_STREET, "<t:SetItemField><t:IndexedFieldURI FieldURI=\"contacts:PhysicalAddress:Street\" FieldIndex=\"Business\"/><t:Contact><t:PhysicalAddresses><t:Entry Key=\"Business\"><t:Street>" + StringEscapeUtils.escapeXml(_val) + "</t:Street></t:Entry></t:PhysicalAddresses></t:Contact></t:SetItemField>");
		} else {
			params.put(UPDATE_FIELD_BUSINESS_STREET, "");
		}
	}

	/**
	 * Updates the <b>BusinessCity</b> of the Contact.
	 * 
	 * @param _val
	 */
	public void setBusinessCity(String _val) {
		if (_val != null) {
			params.put(UPDATE_FIELD_BUSINESS_CITY, "<t:SetItemField><t:IndexedFieldURI FieldURI=\"contacts:PhysicalAddress:City\" FieldIndex=\"Business\"/><t:Contact><t:PhysicalAddresses><t:Entry Key=\"Business\"><t:City>" + StringEscapeUtils.escapeXml(_val) + "</t:City></t:Entry></t:PhysicalAddresses></t:Contact></t:SetItemField>");
		} else {
			params.put(UPDATE_FIELD_BUSINESS_CITY, "");
		}
	}

	/**
	 * Updates the <b>BusinessState</b> of the Contact.
	 * 
	 * @param _val
	 */
	public void setBusinessState(String _val) {
		if (_val != null) {
			params.put(UPDATE_FIELD_BUSINESS_STATE, "<t:SetItemField><t:IndexedFieldURI FieldURI=\"contacts:PhysicalAddress:State\" FieldIndex=\"Business\"/><t:Contact><t:PhysicalAddresses><t:Entry Key=\"Business\"><t:State>" + StringEscapeUtils.escapeXml(_val) + "</t:State></t:Entry></t:PhysicalAddresses></t:Contact></t:SetItemField>");
		} else {
			params.put(UPDATE_FIELD_BUSINESS_STATE, "");
		}
	}

	/**
	 * Updates the <b>BusinessCountry</b> of the Contact.
	 * 
	 * @param _val
	 */
	public void setBusinessCountry(String _val) {
		if (_val != null) {
			params.put(UPDATE_FIELD_BUSINESS_COUNTRY, "<t:SetItemField><t:IndexedFieldURI FieldURI=\"contacts:PhysicalAddress:CountryOrRegion\" FieldIndex=\"Business\"/><t:Contact><t:PhysicalAddresses><t:Entry Key=\"Business\"><t:CountryOrRegion>" + StringEscapeUtils.escapeXml(_val) + "</t:CountryOrRegion></t:Entry></t:PhysicalAddresses></t:Contact></t:SetItemField>");
		} else {
			params.put(UPDATE_FIELD_BUSINESS_COUNTRY, "");
		}
	}

	/**
	 * Updates the <b>BusinessPostalCode</b> of the Contact.
	 * 
	 * @param _val
	 */
	public void setBusinessPostalCode(String _val) {
		if (_val != null) {
			params.put(UPDATE_FIELD_BUSINESS_POSTALCODE, "<t:SetItemField><t:IndexedFieldURI FieldURI=\"contacts:PhysicalAddress:PostalCode\" FieldIndex=\"Business\"/><t:Contact><t:PhysicalAddresses><t:Entry Key=\"Business\"><t:PostalCode>" + StringEscapeUtils.escapeXml(_val) + "</t:PostalCode></t:Entry></t:PhysicalAddresses></t:Contact></t:SetItemField>");
		} else {
			params.put(UPDATE_FIELD_BUSINESS_POSTALCODE, "");
		}
	}

	/**
	 * Updates the <b>Department</b> of the Contact.
	 * 
	 * @param _val
	 */
	public void setDepartment(String _val) {
		if (_val != null) {
			params.put(UPDATE_FIELD_DEPARTMENT, "<t:SetItemField><t:FieldURI FieldURI=\"contacts:Department\"/><t:Contact><t:Department>" + StringEscapeUtils.escapeXml(_val) + "</t:Department></t:Contact></t:SetItemField>");
		} else {
			params.put(UPDATE_FIELD_DEPARTMENT, "");
		}
	}

	/**
	 * Updates the <b>AssistantPhone</b> Number of the Contact.
	 * 
	 * @param _val
	 */
	public void setAssistantPhone(String _val) {
		if (_val != null) {
			params.put(UPDATE_FIELD_ASSISTANT_PHONE, "<t:SetItemField><t:IndexedFieldURI FieldURI=\"contacts:PhoneNumber\" FieldIndex=\"AssistantPhone\"/><t:Contact><t:PhoneNumbers><t:Entry Key=\"AssistantPhone\">" + StringEscapeUtils.escapeXml(_val) + "</t:Entry></t:PhoneNumbers></t:Contact></t:SetItemField>");
		} else {
			params.put(UPDATE_FIELD_ASSISTANT_PHONE, "");
		}
	}

	/**
	 * Updates the <b>HomePhone</b> Number of the Contact.
	 * 
	 * @param _val
	 */
	public void setHomePhone1(String _val) {
		if (_val != null) {
			params.put(UPDATE_FIELD_HOME_PHONE1, "<t:SetItemField><t:IndexedFieldURI FieldURI=\"contacts:PhoneNumber\" FieldIndex=\"HomePhone\"/><t:Contact><t:PhoneNumbers><t:Entry Key=\"HomePhone\">" + StringEscapeUtils.escapeXml(_val) + "</t:Entry></t:PhoneNumbers></t:Contact></t:SetItemField>");
		} else {
			params.put(UPDATE_FIELD_HOME_PHONE1, "");
		}
	}

	public void setHomePhone2(String _val) {
		if (_val != null) {
			params.put(UPDATE_FIELD_HOME_PHONE2, "<t:SetItemField><t:IndexedFieldURI FieldURI=\"contacts:PhoneNumber\" FieldIndex=\"HomePhone2\"/><t:Contact><t:PhoneNumbers><t:Entry Key=\"HomePhone2\">" + StringEscapeUtils.escapeXml(_val) + "</t:Entry></t:PhoneNumbers></t:Contact></t:SetItemField>");
		} else {
			params.put(UPDATE_FIELD_HOME_PHONE2, "");
		}
	}

	/**
	 * Updates the <b>HomePhoneFax</b> of the Contact.
	 * 
	 * @param _val
	 */
	public void setHomePhoneFax(String _val) {
		if (_val != null) {
			params.put(UPDATE_FIELD_HOME_FAX, "<t:SetItemField><t:IndexedFieldURI FieldURI=\"contacts:PhoneNumber\" FieldIndex=\"HomeFax\"/><t:Contact><t:PhoneNumbers><t:Entry Key=\"HomeFax\">" + StringEscapeUtils.escapeXml(_val) + "</t:Entry></t:PhoneNumbers></t:Contact></t:SetItemField>");
		} else {
			params.put(UPDATE_FIELD_HOME_FAX, "");
		}
	}

	/**
	 * Updates the <b>BusinessFax</b> of the Contact.
	 * 
	 * @param _val
	 */
	public void setBusinessFax(String _val) {
		if (_val != null) {
			params.put(UPDATE_FIELD_BUSINESS_FAX, "<t:SetItemField><t:IndexedFieldURI FieldURI=\"contacts:PhoneNumber\" FieldIndex=\"BusinessFax\"/><t:Contact><t:PhoneNumbers><t:Entry Key=\"BusinessFax\">" + StringEscapeUtils.escapeXml(_val) + "</t:Entry></t:PhoneNumbers></t:Contact></t:SetItemField>");
		} else {
			params.put(UPDATE_FIELD_BUSINESS_FAX, "");
		}
	}

	/**
	 * Updates the <b>BusinessHomePage</b> of the Contact.
	 * 
	 * @param _homePage
	 */
	public void setBusinessHomePage(String _homePage) {
		if (_homePage != null) {
			params.put(UPDATE_FIELD_BUSINESS_HOMEPAGE, "<t:SetItemField><t:FieldURI FieldURI=\"contacts:BusinessHomePage\"/><t:Contact><t:BusinessHomePage>" + StringEscapeUtils.escapeXml(_homePage) + "</t:BusinessHomePage></t:Contact></t:SetItemField>");
		} else {
			params.put(UPDATE_FIELD_BUSINESS_HOMEPAGE, "");
		}
	}

	/**
	 * Updates the <b>AssistantName</b> of the Contact.
	 * 
	 * @param _val
	 */
	public void setAssistantName(String _val) {
		if (_val != null) {
			params.put(UPDATE_FIELD_ASSISTANT_NAME, "<t:SetItemField><t:FieldURI FieldURI=\"contacts:AssistantName\"/><t:Contact><t:AssistantName>" + StringEscapeUtils.escapeXml(_val) + "</t:AssistantName></t:Contact></t:SetItemField>");
		} else {
			params.put(UPDATE_FIELD_ASSISTANT_NAME, "");
		}
	}

	/**
	 * Updates the <b>BusinessPhone</b> Number of the Contact.
	 * 
	 * @param _val
	 */
	public void setBusinessPhone1(String _val) {
		if (_val != null) {
			params.put(UPDATE_FIELD_BUSINESS_PHONE1, "<t:SetItemField><t:IndexedFieldURI FieldURI=\"contacts:PhoneNumber\" FieldIndex=\"BusinessPhone\"/><t:Contact><t:PhoneNumbers><t:Entry Key=\"BusinessPhone\">" + StringEscapeUtils.escapeXml(_val) + "</t:Entry></t:PhoneNumbers></t:Contact></t:SetItemField>");
		} else {
			params.put(UPDATE_FIELD_BUSINESS_PHONE1, "");
		}
	}

	public void setBusinessPhone2(String _val) {
		if (_val != null) {
			params.put(UPDATE_FIELD_BUSINESS_PHONE2, "<t:SetItemField><t:IndexedFieldURI FieldURI=\"contacts:PhoneNumber\" FieldIndex=\"BusinessPhone2\"/><t:Contact><t:PhoneNumbers><t:Entry Key=\"BusinessPhone2\">" + StringEscapeUtils.escapeXml(_val) + ")</t:Entry></t:PhoneNumbers></t:Contact></t:SetItemField>");
		} else {
			params.put(UPDATE_FIELD_BUSINESS_PHONE2, "");
		}
	}

	/**
	 * Provides the ChangeKey of an Item.
	 * 
	 * @return ChangeKey
	 */
	public String getChangeKey() {
		return this.changeKey;
	}

	/**
	 * Sets the ChangeKey of an Item for Update Operation.
	 * 
	 * @param _val
	 */
	public void setChangeKey(String _val) {
		this.changeKey = _val;
		if (_val != null) {
			params.put(UPDATE_FIELD_CHANGE_KEY, _val);
		}
	}

	/**
	 * Updates the <b>Callback</b> Number of the Contact.
	 * 
	 * @param _val
	 */
	public void setCallback(String _val) {
		if (_val != null) {
			params.put(UPDATE_FIELD_CALL_BACK, "<t:SetItemField><t:IndexedFieldURI FieldURI=\"contacts:PhoneNumber\" FieldIndex=\"Callback\"/><t:Contact><t:PhoneNumbers><t:Entry Key=\"Callback\">" + StringEscapeUtils.escapeXml(_val) + "</t:Entry></t:PhoneNumbers></t:Contact></t:SetItemField>");
		} else {
			params.put(UPDATE_FIELD_CALL_BACK, "");
		}
	}

	/**
	 * Updates the <b>CarPhone</b> Number of the Contact.
	 */
	public void setCarPhone(String _val) {
		if (_val != null) {
			params.put(UPDATE_FIELD_CAR_PHONE, "<t:SetItemField><t:IndexedFieldURI FieldURI=\"contacts:PhoneNumber\" FieldIndex=\"CarPhone\"/><t:Contact><t:PhoneNumbers><t:Entry Key=\"CarPhone\">" + StringEscapeUtils.escapeXml(_val) + "</t:Entry></t:PhoneNumbers></t:Contact></t:SetItemField>");
		} else {
			params.put(UPDATE_FIELD_CAR_PHONE, "");
		}
	}

	/**
	 * Updates the <b>OtherTelephone</b> Number of the Contact.
	 * 
	 * @param _val
	 */
	public void setOtherTelephone(String _val) {
		if (_val != null) {
			params.put(UPDATE_FIELD_OTHER_PHONE, "<t:SetItemField><t:IndexedFieldURI FieldURI=\"contacts:PhoneNumber\" FieldIndex=\"OtherTelephone\"/><t:Contact><t:PhoneNumbers><t:Entry Key=\"OtherTelephone\">" + StringEscapeUtils.escapeXml(_val) + "</t:Entry></t:PhoneNumbers></t:Contact></t:SetItemField>");
		} else {
			params.put(UPDATE_FIELD_OTHER_PHONE, "");
		}
	}

	/**
	 * Updates the <b>Pager</b> of the Contact.
	 * 
	 * @param _val
	 */
	public void setPager(String _val) {
		if (_val != null) {
			params.put(UPDATE_FIELD_PAGER, "<t:SetItemField><t:IndexedFieldURI FieldURI=\"contacts:PhoneNumber\" FieldIndex=\"Pager\"/><t:Contact><t:PhoneNumbers><t:Entry Key=\"Pager\">" + StringEscapeUtils.escapeXml(_val) + "</t:Entry></t:PhoneNumbers></t:Contact></t:SetItemField>");
		} else {
			params.put(UPDATE_FIELD_PAGER, "");
		}
	}

	/**
	 * Updates the <b>PrimaryPhone</b> Number of the Contact.
	 * 
	 * @param _val
	 */
	public void setPrimaryPhone(String _val) {
		if (_val != null) {
			params.put(UPDATE_FIELD_PRIMARY_PHONE, "<t:SetItemField><t:IndexedFieldURI FieldURI=\"contacts:PhoneNumber\" FieldIndex=\"PrimaryPhone\"/><t:Contact><t:PhoneNumbers><t:Entry Key=\"PrimaryPhone\">" + StringEscapeUtils.escapeXml(_val) + "</t:Entry></t:PhoneNumbers></t:Contact></t:SetItemField>");
		} else {
			params.put(UPDATE_FIELD_PRIMARY_PHONE, "");
		}
	}

	/**
	 * Updates the <b>CompanyMainPhone</b> Number of the Contact.
	 * 
	 * @param _val
	 */
	public void setCompanyMainPhone(String _val) {
		if (_val != null) {
			params.put(UPDATE_FIELD_COMPANY_MAIN_PHONE, "<t:SetItemField><t:IndexedFieldURI FieldURI=\"contacts:PhoneNumber\" FieldIndex=\"CompanyMainPhone\"/><t:Contact><t:PhoneNumbers><t:Entry Key=\"CompanyMainPhone\">" + StringEscapeUtils.escapeXml(_val) + "</t:Entry></t:PhoneNumbers></t:Contact></t:SetItemField>");
		} else {
			params.put(UPDATE_FIELD_COMPANY_MAIN_PHONE, "");
		}
	}

	/**
	 * Updates the <b>Isdn</b> of the Contact.
	 * 
	 * @param _val
	 */
	public void setIsdn(String _val) {
		if (_val != null) {
			params.put(UPDATE_FIELD_ISDN_NUMBER, "<t:SetItemField><t:IndexedFieldURI FieldURI=\"contacts:PhoneNumber\" FieldIndex=\"Isdn\"/><t:Contact><t:PhoneNumbers><t:Entry Key=\"Isdn\">" + StringEscapeUtils.escapeXml(_val) + "</t:Entry></t:PhoneNumbers></t:Contact></t:SetItemField>");
		} else {
			params.put(UPDATE_FIELD_ISDN_NUMBER, "");
		}
	}

	/**
	 * Updates the <b>RadioPhone</b> Number of the Contact.
	 * 
	 * @param _val
	 */
	public void setRadioPhone(String _val) {
		if (_val != null) {
			params.put(UPDATE_FIELD_RADIO_PHONE, "<t:SetItemField><t:IndexedFieldURI FieldURI=\"contacts:PhoneNumber\" FieldIndex=\"RadioPhone\"/><t:Contact><t:PhoneNumbers><t:Entry Key=\"RadioPhone\">" + StringEscapeUtils.escapeXml(_val) + "</t:Entry></t:PhoneNumbers></t:Contact></t:SetItemField>");
		} else {
			params.put(UPDATE_FIELD_RADIO_PHONE, "");
		}
	}

	/**
	 * Updates the <b>Telex</b> of the Contact.
	 * 
	 * @param _val
	 */
	public void setTelex(String _val) {
		if (_val != null) {
			params.put(UPDATE_FIELD_TELEX_NUMBER, "<t:SetItemField><t:IndexedFieldURI FieldURI=\"contacts:PhoneNumber\" FieldIndex=\"Telex\"/><t:Contact><t:PhoneNumbers><t:Entry Key=\"Telex\">" + StringEscapeUtils.escapeXml(_val) + "</t:Entry></t:PhoneNumbers></t:Contact></t:SetItemField>");
		} else {
			params.put(UPDATE_FIELD_TELEX_NUMBER, "");
		}
	}

	/**
	 * Updates the <b>TtyTddPhone</b> Number of the Contact.
	 * 
	 * @param _val
	 */
	public void setTtyTddPhone(String _val) {
		if (_val != null) {
			params.put(UPDATE_FIELD_TTYTDD_NUMBER, "<t:SetItemField><t:IndexedFieldURI FieldURI=\"contacts:PhoneNumber\" FieldIndex=\"TtyTddPhone\"/><t:Contact><t:PhoneNumbers><t:Entry Key=\"TtyTddPhone\">" + StringEscapeUtils.escapeXml(_val) + "</t:Entry></t:PhoneNumbers></t:Contact></t:SetItemField>");
		} else {
			params.put(UPDATE_FIELD_TTYTDD_NUMBER, "");
		}
	}

	/**
	 * This returns back the SOAP-Action
	 * 
	 * @return String(SOAP-Action url)
	 */
	@Override
	public String getSoapAction() {
		return "http://schemas.microsoft.com/exchange/services/2006/messages/UpdateItem";
	}

	@Override
	public String getSoapPacket() throws IOException {
		return getSoapTemplate("/net/aw20/msexchange/soap/templates/UpdateContactItem.soap", params);
	}

	private final String ROOT_ELEMENT = "t:Contact";

	/**
	 * Upon a successful 200 status code; this represents the server response raw XML packet
	 * 
	 * @param xmlResponse
	 * @return parsed xmlResponse to List object
	 * @throws MSExchangeException
	 */
	@Override
	public List<Map<String, Object>> onResponse(String xmlResponse) throws MSExchangeException {
		List<Map<String, Object>> contacts = new ArrayList<Map<String, Object>>();
		contacts = processRequest(xmlResponse, ROOT_ELEMENT);
		if (contacts.isEmpty()) {
			contacts = processError(xmlResponse);
		}

		return contacts;
	}
}
/* 
 *  Copyright (C) 2000 - 2011 aw2.0 Ltd
 *
 *  This file is part of Open BlueDragon (OpenBD) CFML Server Engine.
 *  
 *  OpenBD is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  Free Software Foundation,version 3.
 *  
 *  OpenBD is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  
 *  You should have received a copy of the GNU General Public License
 *  along with OpenBD.  If not, see http://www.gnu.org/licenses/
 *  
 *  Additional permission under GNU GPL version 3 section 7
 *  
 *  If you modify this Program, or any covered work, by linking or combining 
 *  it with any of the JARS listed in the README.txt (or a modified version of 
 *  (that library), containing parts covered by the terms of that JAR, the 
 *  licensors of this Program grant you additional permission to convey the 
 *  resulting work. 
 *  README.txt @ http://www.openbluedragon.org/license/README.txt
 *  
 *  http://www.openbluedragon.org/
 */

package net.aw20.msexchange.soap;

import java.io.BufferedReader;
import java.io.CharArrayWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import net.aw20.msexchange.MSExchangeException;

public abstract class SOAPActionBase extends Object {

	// list of substitutions
	public static String BASE_SHAPE = "$(BASE_SHAPE)";

	public static String FOLDER_ID = "$(FOLDER_ID)";

	public static String ID = "$(ID)";

	public static String SEARCH = "$(SEARCH)";

	public static String SEARCH_FIELD = "$(SEARCH_FIELD)";

	public static String SEARCH_CONDITIONS = "$(SEARCH_CONDITIONS)";

	public static String CONTAINMENT_MODE = "$(CONTAINMENT_MODE)";

	public static String CONTAINMENT_COMP = "$(CONTAINMENT_COMP)";

	public static String LIMIT = "$(LIMIT)";

	public static String OFFSET = "$(OFFSET)";

	public static String BASEPOINT = "$(BASEPOINT)";

	public static String MESSAGE_DISPOSITION = "$(MESSAGE_DISPOSITION)";

	public static String SEND_MEETING_INVITATIONS = "$(SEND_MEETING_INVITATIONS)";

	public static String TZ_BASE_OFFSET = "$(TZ_BASE_OFFSET)";

	public static String APPOINTMENT_TITLE = "$(APPOINTMENT_TITLE)";

	public static String APPOINTMENT_START = "$(APPOINTMENT_START)";

	public static String APPOINTMENT_END = "$(APPOINTMENT_END)";

	public static String ADDITIONAL_FOLDERS = "$(ADDITIONAL_FOLDERS)";

	// BASE_SHAPE properties. Common across all requests
	public static final String BASE_SHAPE_IDS_ONLY = "IdOnly";

	public static final String BASE_SHAPE_ALL_PROPS = "AllProperties";

	public static final String BASE_SHAPE_DEFAULT = "Default";

	/**
	 * Returns the SOAP template; the template is part of the package
	 * 
	 * @param soapTemplate
	 * @return
	 * @throws IOException
	 */
	protected String getSoapTemplate(String soapTemplate, Map<String, String> params) throws IOException {
		InputStream in = this.getClass().getResourceAsStream(soapTemplate);

		BufferedReader reader = null;
		InputStreamReader inreader = null;
		CharArrayWriter writer = null;

		try {
			inreader = new InputStreamReader(in);
			reader = new BufferedReader(inreader);
			writer = new CharArrayWriter();

			char[] chars = new char[2048];
			int read;
			while ((read = reader.read(chars, 0, chars.length)) != -1) {
				writer.write(chars, 0, read);
			}

			return doSubstitutions(writer.toString(), params);

		} finally {
			if (in != null) {
				try {
					in.close();
				} catch (IOException ignored) {
				}
			}
			if (inreader != null) {
				try {
					inreader.close();
				} catch (IOException ignored) {
				}
			}
		}
	}

	/**
	 * Retrieves the contents between the <b>m:MessageText</b> tag of the XML Response in case of an Error(Operation fails).
	 * 
	 * @param xmlResponse
	 * @return List containing the Error Message Details
	 * @throws MSExchangeException
	 */
	protected List<Map<String, Object>> processError(String xmlResponse) throws MSExchangeException {
		return processRequest(xmlResponse, "m:MessageText");
	}

	/**
	 * Parses the XML response into a List.The <b>parentTag</b> should be either <b>t:Contact</b> or <b>m:MessageText</b>
	 * 
	 * @return List
	 * @throws MSExchangeException
	 */
	protected List<Map<String, Object>> processRequest(String xmlResponse, String parentTag) throws MSExchangeException {
		SOAPResponseParser s = new SOAPResponseParser();
		List<Map<String, Object>> list = s.parseResponse(xmlResponse, parentTag);
		return list;
	}

	/**
	 * Substitute the <b>parameters</b> in the SOAP Request Template with the <b>actual tags</b>
	 * 
	 * @param str
	 * @param params
	 * @return String(SOAP Template)
	 */
	protected String doSubstitutions(String str, Map<String, String> params) {

		// do SOAPActionBase.SEARCH_CONDITIONS first as it requires further substitutions
		String searchConditions = params.get(SOAPActionBase.SEARCH_CONDITIONS);
		if (searchConditions != null) {
			str = str.replace(SOAPActionBase.SEARCH_CONDITIONS, searchConditions);
		}

		for (Entry<String, String> entry : params.entrySet()) {
			if (!SOAPActionBase.SEARCH_CONDITIONS.equals(entry.getKey())) {
				str = str.replace(entry.getKey(), entry.getValue());
			}
		}
		return str;
	}

}

/* 
 *  Copyright (C) 2000 - 2011 aw2.0 Ltd
 *
 *  This file is part of Open BlueDragon (OpenBD) CFML Server Engine.
 *  
 *  OpenBD is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  Free Software Foundation,version 3.
 *  
 *  OpenBD is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  
 *  You should have received a copy of the GNU General Public License
 *  along with OpenBD.  If not, see http://www.gnu.org/licenses/
 *  
 *  Additional permission under GNU GPL version 3 section 7
 *  
 *  If you modify this Program, or any covered work, by linking or combining 
 *  it with any of the JARS listed in the README.txt (or a modified version of 
 *  (that library), containing parts covered by the terms of that JAR, the 
 *  licensors of this Program grant you additional permission to convey the 
 *  resulting work. 
 *  README.txt @ http://www.openbluedragon.org/license/README.txt
 *  
 *  http://www.openbluedragon.org/
 */

package net.aw20.msexchange.soap.task;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.aw20.msexchange.MSExchangeException;
import net.aw20.msexchange.soap.SOAPActionBase;
import net.aw20.msexchange.soap.items.FindItem;
import net.aw20.openbd.plugins.exchange.functions.ExchangeSearchTasks;

public class SearchTasks extends FindItem {

	public static final String TASK_TAG = "t:Task";

	public static final String TASK_DUE_DATE = "$(SEARCH_CONDITION_DATE)";

	public static final String TASK_SUBJECT = "$(SEARCH_CONDITION_SUBJECT)";

	public static final String TASK_BODY = "$(SEARCH_CONDITION_BODY)";

	public static final String TASK_STATUS = "$(SEARCH_CONDITION_STATUS)";

	public static final String TASK_IMPORTANCE = "$(SEARCH_CONDITION_IMPORTANCE)";

	public static final String RESTRICTION_TAG_OPEN = "$(RESTRICTION_TAG_OPEN)";

	public static final String RESTRICTION_TAG_CLOSE = "$(RESTRICTION_TAG_CLOSE)";

	public static final String OPERATOR_TAG_OPEN = "$(OPERATOR_TAG_OPEN)";

	public static final String OPERATOR_TAG_CLOSE = "$(OPERATOR_TAG_CLOSE)";

	public static final String STATUS_NOT_EQUALS = "$(SEARCH_CONDITION_STATUS_NOT_EQUALS)";

	public static final String ITEM_SENSITIVITY = "$(SEARCH_CONDITION_SENSITIVITY)";

	public static final String ITEM_BEGIN_START_DATE = "$(SEARCH_CONDITION_BEGIN_START_DATE)";

	public static final String ITEM_END_START_DATE = "$(SEARCH_CONDITION_END_START_DATE)";

	public static final String FOLDER_ID_TASK = "tasks";

	/**
	 * Sets the BASE_SHAPE and FOLDER_ID parameter for the Search SOAP Request Template.
	 */

	public SearchTasks() {
		params = new HashMap<String, String>();
		params.put(SOAPActionBase.BASE_SHAPE, BASE_SHAPE_IDS_ONLY);
		params.put(SOAPActionBase.FOLDER_ID, FOLDER_ID_TASK);
	}

	/**
	 * Initializes the required tags for the Search SOAP Request Template when the <b>Search</b> operation is to be performed.
	 */
	public void initializeTags() {
		params.put(RESTRICTION_TAG_OPEN, "<Restriction>");
		params.put(RESTRICTION_TAG_CLOSE, "</Restriction>");
		params.put(OPERATOR_TAG_OPEN, "<t:Or>");
		params.put(OPERATOR_TAG_CLOSE, "</t:Or>");
	}

	/**
	 * Initializes the required tags for the Search SOAP Request Template depending on whether the <b>List / Search </b> Operation is to be performed on the Items.
	 * 
	 * @param listOrSearch
	 */
	public void initializeConditions(int listOrSearch) {
		params.put(RESTRICTION_TAG_OPEN, "");
		params.put(RESTRICTION_TAG_CLOSE, "");
		params.put(OPERATOR_TAG_OPEN, "");
		params.put(OPERATOR_TAG_CLOSE, "");
		params.put(TASK_DUE_DATE, "");
		params.put(TASK_SUBJECT, "");
		params.put(TASK_BODY, "");
		params.put(TASK_STATUS, "");
		params.put(TASK_IMPORTANCE, "");
		params.put(STATUS_NOT_EQUALS, "");
		params.put(ITEM_SENSITIVITY, "");
		params.put(ITEM_BEGIN_START_DATE, "");
		params.put(ITEM_END_START_DATE, "");
		if (listOrSearch == ExchangeSearchTasks.SEARCH) {
			initializeTags();
		}
	}

	/**
	 * Sets the Search condition for Task <b>ITEM_BEGIN_START_DATE</b> parameter.
	 * 
	 * @param _condition
	 */

	public void setTaskBeginStartDate(String _condition) {
		if (_condition != null) {
			params.put(ITEM_BEGIN_START_DATE, "<t:And><t:IsGreaterThan> <t:FieldURI FieldURI=\"task:StartDate\"/> <t:FieldURIOrConstant><t:Constant Value=\"" + _condition + "\"/> </t:FieldURIOrConstant> </t:IsGreaterThan>");
		}
	}

	/**
	 * Sets the Search condition for Task <b>ITEM_END_START_DATE</b> parameter.
	 * 
	 * @param _condition
	 */
	public void setTaskEndStartDate(String _condition) {
		if (_condition != null) {
			params.put(ITEM_END_START_DATE, "<t:IsLessThan> <t:FieldURI FieldURI=\"task:StartDate\"/> <t:FieldURIOrConstant><t:Constant Value=\"" + _condition + "\"/> </t:FieldURIOrConstant> </t:IsLessThan></t:And>");
		}
	}

	/**
	 * Sets the Search condition for Item <b>Sensitivity</b> parameter.
	 * 
	 * @param _condition
	 */
	public void setSensitivity(String _condition) {
		if (_condition != null) {
			params.put(ITEM_SENSITIVITY, "<t:IsEqualTo> <t:FieldURI FieldURI=\"item:Sensitivity\"/> <t:FieldURIOrConstant><t:Constant Value=\"" + _condition + "\"/> </t:FieldURIOrConstant> </t:IsEqualTo>");
		}
	}

	/**
	 * Sets the <b>Operator</b> tag for the Search SOAP Template to the input given, provided the input is not null.
	 * 
	 * @param _condition
	 */
	public void setOperator(String _condition) {
		if (_condition != null) {
			params.put(OPERATOR_TAG_OPEN, "<t:" + _condition + ">");
			params.put(OPERATOR_TAG_CLOSE, "</t:" + _condition + ">");
		}
	}

	/**
	 * Sets the <b>Status</b> tag for the Search SOAP Template to the input given, provided the input is not null.
	 * 
	 * @param _condition
	 */
	public void setStatusNotEquals(Integer _condition) {
		if (_condition != null) {
			params.put(STATUS_NOT_EQUALS, "<t:IsNotEqualTo> <t:FieldURI FieldURI=\"task:Status\"/> <t:FieldURIOrConstant><t:Constant Value=\"" + _condition + "\"/> </t:FieldURIOrConstant> </t:IsNotEqualTo>");
		}
	}

	/**
	 * Sets the Search condition for Item <b>DueDate</b> parameter.
	 * 
	 * @param _condition
	 */
	public void setDueDate(String _condition) {
		if (_condition != null) {
			params.put(TASK_DUE_DATE, "<t:IsGreaterThanOrEqualTo> <t:FieldURI FieldURI=\"task:DueDate\"/> <t:FieldURIOrConstant><t:Constant Value=\"" + _condition + "\"/> </t:FieldURIOrConstant> </t:IsGreaterThanOrEqualTo>");
		}
	}

	/**
	 * Sets the Search condition for Item <b>Subject</b> parameter.
	 * 
	 * @param _condition
	 */
	public void setSubject(String _condition) {
		if (_condition != null) {
			_condition = "<t:Contains ContainmentMode=\"Substring\" ContainmentComparison=\"IgnoreCaseAndNonSpacingCharacters\"><t:FieldURI FieldURI=\"item:Subject\"/><t:Constant Value=\"" + _condition + "\"/></t:Contains>";
			params.put(TASK_SUBJECT, _condition);
		}
	}

	/**
	 * Sets the Search condition for Item <b>Body</b> parameter.
	 * 
	 * @param _condition
	 */
	public void setBody(String _condition) {
		if (_condition != null) {
			_condition = "<t:Contains ContainmentMode=\"Substring\" ContainmentComparison=\"IgnoreCaseAndNonSpacingCharacters\"><t:FieldURI FieldURI=\"item:Body\"/><t:Constant Value=\"" + _condition + "\"/></t:Contains>";
			params.put(TASK_BODY, _condition);
		}
	}

	/**
	 * Sets the Search condition for Item <b>Status</b> parameter.
	 * 
	 * @param _condition
	 */
	public void setStatus(Integer _condition) {
		if (_condition != null) {
			params.put(TASK_STATUS, "<t:IsEqualTo> <t:FieldURI FieldURI=\"task:Status\"/> <t:FieldURIOrConstant><t:Constant Value=\"" + _condition + "\"/> </t:FieldURIOrConstant> </t:IsEqualTo>");
		}
	}

	/**
	 * Sets the Search condition for Item <b>Importance</b> parameter.
	 * 
	 * @param _condition
	 */
	public void setImportance(String _condition) {
		if (_condition != null) {
			_condition = "<t:IsEqualTo> <t:FieldURI FieldURI=\"item:Importance\"/> <t:FieldURIOrConstant><t:Constant Value=\"" + _condition + "\"/> </t:FieldURIOrConstant> </t:IsEqualTo>";
			params.put(TASK_IMPORTANCE, _condition);
		}
	}

	/**
	 * This returns back the SOAP-Action
	 * 
	 * @return String(SOAP-Action url)
	 */
	@Override
	public String getSoapAction() {
		return "http://schemas.microsoft.com/exchange/services/2006/messages/FindItem";
	}

	@Override
	public String getSoapPacket() throws IOException {
		return getSoapTemplate("/net/aw20/msexchange/soap/templates/SearchTasks.soap", params);
	}

	/**
	 * Upon a successful 200 status code; this represents the server response raw XML packet
	 * 
	 * @param xmlResponse
	 * @return parsed xmlResponse to List object
	 * @throws MSExchangeException
	 */
	@Override
	public List<Map<String, Object>> onResponse(String xmlResponse) throws MSExchangeException {
		List<Map<String, Object>> tasks = new ArrayList<Map<String, Object>>();
		tasks = processRequest(xmlResponse, TASK_TAG);

		// Calls the processError() function when the Error Response is received from the server.
		if (tasks.isEmpty()) {
			tasks = processError(xmlResponse);
		}

		return tasks;
	}
}
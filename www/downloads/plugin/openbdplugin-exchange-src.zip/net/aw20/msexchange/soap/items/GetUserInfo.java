package net.aw20.msexchange.soap.items;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.ParserConfigurationException;

import net.aw20.msexchange.MSExchangeException;
import net.aw20.msexchange.soap.SOAPActionBase;
import net.aw20.msexchange.soap.SOAPRequestInterface;

import org.apache.commons.lang.StringEscapeUtils;
import org.xml.sax.SAXException;

public class GetUserInfo extends SOAPActionBase implements SOAPRequestInterface {
	protected Map<String, String> params;

	public static final String USERNAME = "$(USERNAME)";

	/**
	 * Provides an information about an user.
	 * 
	 * @param _username
	 */
	public GetUserInfo(String _username) {
		params = new HashMap<String, String>();
		params.put(USERNAME, StringEscapeUtils.escapeXml(_username).concat("@"));
	}

	/**
	 * This returns back the SOAP-Action
	 * 
	 * @return String(SOAP-Action url)
	 */
	@Override
	public String getSoapAction() {
		return "http://schemas.microsoft.com/exchange/services/2006/messages/GetItem";
	}

	@Override
	public String getSoapPacket() throws IOException {
		return getSoapTemplate("/net/aw20/msexchange/soap/templates/GetUserInfo.soap", params);
	}

	/**
	 * Upon a successful 200 status code; this represents the server response raw XML packet
	 * 
	 * @param xmlResponse
	 * @return parsed xmlResponse to List object
	 * @throws MSExchangeException
	 * @throws ParserConfigurationException
	 * @throws SAXException
	 * @throws IOException
	 */
	@Override
	public List<Map<String, Object>> onResponse(String xmlResponse) throws MSExchangeException, IOException, ParserConfigurationException, SAXException {

		List<Map<String, Object>> tasks = new ArrayList<Map<String, Object>>();
		tasks = processRequest(xmlResponse, "t:Resolution");

		// Calls the processError() function when the Error Response is recieved from the server.
		if (tasks.isEmpty()) {
			tasks = processError(xmlResponse);
		}
		return tasks;

	}
}

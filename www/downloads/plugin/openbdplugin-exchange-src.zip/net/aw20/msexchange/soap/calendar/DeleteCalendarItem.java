/* 
 *  Copyright (C) 2000 - 2011 aw2.0 Ltd
 *
 *  This file is part of Open BlueDragon (OpenBD) CFML Server Engine.
 *  
 *  OpenBD is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  Free Software Foundation,version 3.
 *  
 *  OpenBD is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  
 *  You should have received a copy of the GNU General Public License
 *  along with OpenBD.  If not, see http://www.gnu.org/licenses/
 *  
 *  Additional permission under GNU GPL version 3 section 7
 *  
 *  If you modify this Program, or any covered work, by linking or combining 
 *  it with any of the JARS listed in the README.txt (or a modified version of 
 *  (that library), containing parts covered by the terms of that JAR, the 
 *  licensors of this Program grant you additional permission to convey the 
 *  resulting work. 
 *  README.txt @ http://www.openbluedragon.org/license/README.txt
 *  
 *  http://www.openbluedragon.org/
 */

package net.aw20.msexchange.soap.calendar;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.ParserConfigurationException;

import net.aw20.msexchange.MSExchangeException;
import net.aw20.msexchange.soap.items.GetItem;
import net.aw20.openbd.plugins.exchange.helpers.ExchangeUtility;

import org.xml.sax.SAXException;

import com.naryx.tagfusion.cfm.engine.cfStructData;

public class DeleteCalendarItem extends GetItem {

	public static final String TASK_TAG = "m:DeleteItemResponseMessage";

	public static final String SEND_MEETING_CANCELLATIONS = "$(SEND_MEETING_CANCELLATIONS)";

	public static final String DELETE_ITEM_TAG = "$(DELETE_ITEM_TAG)";

	public DeleteCalendarItem() {
		params = new HashMap<String, String>();
	}

	/**
	 * Sets the <b>SendMeetingCancellations</b> parameter for the Delete SOAP Template to the input given. If input is null then the parameter is set to <b>"SendOnlyToAll"</b>.
	 * 
	 * @param _val
	 */
	private void setSendMeetingCancellations(String _val) {
		// Default value "SendOnlyToAll"
		if (_val != null) {
			params.put(SEND_MEETING_CANCELLATIONS, _val);
		} else {
			params.put(SEND_MEETING_CANCELLATIONS, "SendOnlyToAll");
		}

	}

	/**
	 * Based on the input provided (i.e. 1. id, 2. OccurrenceId and InstanceIndex, 3.RecurringMasterId ), deletes all or specific occurrences.
	 * 
	 * @param _struct
	 */
	public void setDeletePattern(cfStructData _struct) {
		Integer instanceIndex = ExchangeUtility.parseInt(_struct.get("InstanceIndex"), "InstanceIndex");

		setSendMeetingCancellations(ExchangeUtility.parseSendMeetingCancellations((String) _struct.get("sendmeetingcancellations")));

		if (((String) _struct.get("occurrenceid") != null) & (instanceIndex != null)) {
			params.put(DELETE_ITEM_TAG, "<t:OccurrenceItemId RecurringMasterId=\"" + (String) _struct.get("occurrenceid") + "\" InstanceIndex=\"" + instanceIndex + "\"/>");
		} else if ((String) _struct.get("id") != null) {
			params.put(DELETE_ITEM_TAG, " <t:ItemId Id=\"" + (String) _struct.get("id") + "\" />");
		} else if ((String) _struct.get("recurringmasterid") != null) {
			params.put(DELETE_ITEM_TAG, "<t:RecurringMasterItemId OccurrenceId=\"" + (String) _struct.get("recurringmasterid") + "\"/>");
		} else {
			throw new IllegalArgumentException("Invalid input for Delete operation.");
		}
	}

	/**
	 * This returns back the SOAP-Action
	 * 
	 * @return String(SOAP-Action url)
	 */
	@Override
	public String getSoapAction() {
		return "http://schemas.microsoft.com/exchange/services/2006/messages/DeleteItem";
	}

	@Override
	public String getSoapPacket() throws IOException {
		return getSoapTemplate("/net/aw20/msexchange/soap/templates/DeleteCalendarItem.soap", params);
	}

	/**
	 * Upon a successful 200 status code; this represents the server response raw XML packet
	 * 
	 * @param xmlResponse
	 * @return parsed xmlResponse to List object
	 * @throws ParserConfigurationException
	 * @throws SAXException
	 * @throws MSExchangeException
	 */
	@Override
	public List<Map<String, Object>> onResponse(String xmlResponse) throws MSExchangeException {
		List<Map<String, Object>> calendarItem = new ArrayList<Map<String, Object>>();
		calendarItem = processRequest(xmlResponse, TASK_TAG);

		// Calls the processError() function when the Error Response is received from the server.
		if (calendarItem.isEmpty()) {
			calendarItem = processError(xmlResponse);
		}
		return calendarItem;
	}

}

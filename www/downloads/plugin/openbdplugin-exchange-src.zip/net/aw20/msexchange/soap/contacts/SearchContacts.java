/* 
 *  Copyright (C) 2000 - 2011 aw2.0 Ltd
 *
 *  This file is part of Open BlueDragon (OpenBD) CFML Server Engine.
 *  
 *  OpenBD is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  Free Software Foundation,version 3.
 *  
 *  OpenBD is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  
 *  You should have received a copy of the GNU General Public License
 *  along with OpenBD.  If not, see http://www.gnu.org/licenses/
 *  
 *  Additional permission under GNU GPL version 3 section 7
 *  
 *  If you modify this Program, or any covered work, by linking or combining 
 *  it with any of the JARS listed in the README.txt (or a modified version of 
 *  (that library), containing parts covered by the terms of that JAR, the 
 *  licensors of this Program grant you additional permission to convey the 
 *  resulting work. 
 *  README.txt @ http://www.openbluedragon.org/license/README.txt
 *  
 *  http://www.openbluedragon.org/
 */

package net.aw20.msexchange.soap.contacts;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.aw20.msexchange.MSExchangeException;
import net.aw20.msexchange.soap.SOAPActionBase;
import net.aw20.msexchange.soap.SOAPField;
import net.aw20.msexchange.soap.task.SearchTasks;

import com.naryx.tagfusion.cfm.engine.cfArrayData;
import com.naryx.tagfusion.cfm.engine.cfData;
import com.naryx.tagfusion.cfm.engine.dataNotSupportedException;

public class SearchContacts extends SearchTasks {

	public static final String CONTACT_TAG = "t:Contact";

	public static final String FOLDER_ID_CONTACT = "contacts";

	public static final String ITEM_SEARCH_MODE = "$(ITEM_SEARCH_MODE)";

	// Search Field options
	/** Searches the subject field which is usually givenname middlename surname */
	public static final String SEARCH_FIELD_SUBJECT = "item:Subject";

	/** Searches the surname field */
	public static final String SEARCH_FIELD_SURNAME = "contacts:Surname";

	/** Searches the surname field */
	public static final String SEARCH_FIELD_GIVENNAME = "contacts:GivenName";

	/** Searches company name field */
	public static final String SEARCH_FIELD_COMPANY = "contacts:CompanyName";

	/** Searches street */
	public static final String SEARCH_FIELD_STREET = "contacts:PhysicalAddress:Street";

	/** Searches city */
	public static final String SEARCH_FIELD_CITY = "contacts:PhysicalAddress:City";

	/** Searches state */
	public static final String SEARCH_FIELD_STATE = "contacts:PhysicalAddress:State";

	/** Searches state */
	public static final String SEARCH_FIELD_POSTALCODE = "contacts:PhysicalAddress:PostalCode";

	/** Searches state */
	public static final String SEARCH_FIELD_COUNTRYORREGION = "contacts:PhysicalAddress:CountryOrRegion";

	/** Searches fileAs */
	public static final String SEARCH_FIELD_FILEAS = "contacts:FileAs";

	/** Searches emailaddress */
	public static final String SEARCH_FIELD_EMAILADDRESS = "contacts:EmailAddress";

	// end of search field options

	// search indexes for indexed fields
	public static final String SEARCH_INDEX_HOME = "Home";

	public static final String SEARCH_INDEX_BUSINESS = "Business";

	public static final String SEARCH_INDEX_OTHER = "Other";

	public static final String SEARCH_INDEX_EMAILADDRESS1 = "EmailAddress1";

	public static final String SEARCH_INDEX_EMAILADDRESS2 = "EmailAddress2";

	public static final String SEARCH_INDEX_EMAILADDRESS3 = "EmailAddress3";

	public static final String CONTAINMENT_COMP = "Loose";

	public static final String CONTAINS_SEARCH = "<t:Contains ContainmentMode='$(CONTAINMENT_MODE)'" + "	ContainmentComparison='$(CONTAINMENT_COMP)'>" + "<t:FieldURI	FieldURI='$(SEARCH_FIELD)'/>" + "<t:Constant Value='$(SEARCH)'/>" + "</t:Contains>";

	private static String ALL_FIELDS = "givenname,surname,subject,company,homestreet,homecity,homestate,homepostalcode,homecountry,businessstreet,businesscity,businessstate,businesspostalcode,businesscountry,fileas,emailaddress";

	/**
	 * Sets the BASE_SHAPE , FOLDER_ID and CONTAINMENT_COMP parameter for the Search SOAP Request Template.
	 */

	public SearchContacts() {

		params = new HashMap<String, String>();
		params.put(SOAPActionBase.BASE_SHAPE, BASE_SHAPE_ALL_PROPS);
		params.put(SOAPActionBase.FOLDER_ID, FOLDER_ID_CONTACT);
		params.put(SOAPActionBase.CONTAINMENT_COMP, CONTAINMENT_COMP);

	}

	/**
	 * Initializes the required tags for the Search SOAP Request Template depending on whether the <b>List / Search </b> Operation is to be performed on the Contact Item.
	 * 
	 * @param listOrSearch
	 */
	public void initializeConditions(int listOrSearch) {
		super.initializeConditions(listOrSearch);
		params.put(ITEM_SEARCH_MODE, "" + "Substring");
		params.put(SOAPActionBase.LIMIT, "" + 100);
		params.put(SOAPActionBase.OFFSET, "" + 0);
		params.put(SOAPActionBase.BASEPOINT, "" + "Beginning");
		params.put(SOAPActionBase.SEARCH_CONDITIONS, "");
		params.put(SOAPActionBase.ADDITIONAL_FOLDERS, "");
	}

	/**
	 * Sets the Search condition for <b>ADDITIONAL_FOLDERS</b> parameter in the SOAP template. It defaults to <b>contacts</b>.
	 * 
	 * @param d
	 * @throws dataNotSupportedException
	 */

	public void setAdditionalFolders(cfData d) throws dataNotSupportedException {
		if (d != null) {
			String[] additionalFolders = getAdditionalFolders(d);
			if (additionalFolders.length > 0) {
				params.put(SOAPActionBase.ADDITIONAL_FOLDERS, createAdditionalFolderString(additionalFolders));
			}
		}
	}

	/**
	 * Sets the search condition on the fields given in the Input data.
	 * 
	 * @param _field
	 * @param _keyword
	 */

	public void setField(String _field, String _keyword) {
		if (_field != null && _keyword != null) {
			if ("All".equalsIgnoreCase(_field)) {
				_field = ALL_FIELDS;
			}
			SOAPField[] fields = createFieldArray(_field);
			params.put(SOAPActionBase.SEARCH_CONDITIONS, createSearchString(fields, _keyword.trim()));
		} else if (_field == null && _keyword != null) {
			params.put(SOAPActionBase.SEARCH_CONDITIONS, "<t:Contains ContainmentMode='$(ITEM_SEARCH_MODE)' ContainmentComparison=\"IgnoreCaseAndNonSpacingCharacters\"><t:FieldURI FieldURI=\"item:Subject\"/><t:Constant Value=\"" + _keyword.trim() + "\"/></t:Contains>");
		}
	}

	/**
	 * Creates MSExchangeField[] from field list
	 * 
	 * @param _field
	 * @return List containing all the fields given in the input.
	 */
	private SOAPField[] createFieldArray(String _field) {

		// check if _field is a comma seperated list
		String[] fields;

		if (_field.indexOf(",") > -1) {
			// comma seperated list
			fields = _field.split(",");

		} else {
			fields = new String[] { _field };
		}

		// If the list of fields includes emailaddress then emailaddress1,emailaddress2,emailaddress3 fields are added to it in place of emailaddress field.
		String[] newFields = new String[fields.length + 2];
		int cnt = 0;
		for (int i = 0; i < fields.length; i++) {
			if ("emailaddress1".equalsIgnoreCase(fields[i].trim()) || "emailaddress2".equalsIgnoreCase(fields[i].trim()) || "emailaddress3".equalsIgnoreCase(fields[i].trim())) {
				throw new IllegalArgumentException("\"field\" is not valid. Must be one of the following: givenname, surname, subject, company, homecity,homestreet, businesscity,homestate,homepostalcode,homecountry,businessstreet,businessstate,businesspostalcode,businesscountry,fileas,emailaddress");
			} else if ("emailaddress".equalsIgnoreCase(fields[i].trim())) {
				newFields[cnt++] = "emailaddress1";
				newFields[cnt++] = "emailaddress2";
				newFields[cnt++] = "emailaddress3";
			} else {
				newFields[cnt++] = fields[i];
			}
		}

		SOAPField[] list = new SOAPField[newFields.length];
		for (int i = 0; i < newFields.length; i++) {
			if (newFields[i] != null) {
				list[i] = getValidSearchField((newFields[i]).trim());
			}
		}

		return list;
	}

	/**
	 * Creates String[] from FolderId List
	 * 
	 * @param data
	 * @return String array containing folder Id's.
	 * @throws dataNotSupportedException
	 */
	private String[] getAdditionalFolders(cfData data) throws dataNotSupportedException {
		String[] s = null;

		if (data != null && data instanceof cfArrayData) {
			cfArrayData a = (cfArrayData) data;

			s = new String[a.size()];

			for (int i = 1; i <= a.size(); i++) {
				s[i - 1] = a.getElement(i).getString();
			}
		}

		return s;
	}

	/**
	 * Sets the <b>Folder Id</b> parameter of the SOAP Template to the Id given in the input data.
	 * 
	 * @param additionalFolders
	 * @return String containing the actual tags associated with FolderIds.
	 */
	private String createAdditionalFolderString(String[] additionalFolders) {
		StringBuilder sb = new StringBuilder();

		for (int i = 0; i < additionalFolders.length; i++) {
			sb.append("<t:FolderId Id='" + additionalFolders[i] + "'/>");
		}

		return sb.toString();
	}

	/**
	 * Sets the search condition on the fields specified in the <b>field</b> parameter of the Input Data.
	 * 
	 * @param _searchFields
	 * @return String containing search condition on the fields given in the input.
	 */
	private String createSearchString(SOAPField[] _searchFields, String _search) {
		StringBuilder sb = new StringBuilder();
		String[] searchList = _search.split(" ");
		for (int i = 0; i < searchList.length; i++) {
			for (int j = 0; j < _searchFields.length; j++) {
				// creating contains tag
				if (_searchFields[j] != null) {
					sb.append("<t:Contains ContainmentMode='$(ITEM_SEARCH_MODE)' " + "ContainmentComparison='$(CONTAINMENT_COMP)'>");
					sb.append(_searchFields[j].getSOAPTag());

					sb.append("<t:Constant Value='" + searchList[i] + "'/>" + "</t:Contains>");
				}
			}
		}

		return sb.toString();
	}

	/**
	 * Validates the fields given in the <b>field</b> parameter of the Input Data. The <b>_searchField</b> values should be any of these <b>"givenname, surname, subject, company, homecity,homestreet, businesscity,homestate,homepostalcode,homecountry,businessstreet,businessstate,businesspostalcode,businesscountry,fileas,emailaddress"</b>
	 * 
	 * @param _searchField
	 * @return Instance of SOAPField after validation.
	 */
	private SOAPField getValidSearchField(String _searchField) {

		SOAPField m = null;
		if ("givenname".equalsIgnoreCase(_searchField)) {
			m = new SOAPField(SOAPField.FIELDURI, SearchContacts.SEARCH_FIELD_GIVENNAME, null);
		} else if ("surname".equalsIgnoreCase(_searchField)) {
			m = new SOAPField(SOAPField.FIELDURI, SearchContacts.SEARCH_FIELD_SURNAME, null);
		} else if ("subject".equalsIgnoreCase(_searchField)) {
			m = new SOAPField(SOAPField.FIELDURI, SearchContacts.SEARCH_FIELD_SUBJECT, null);
		} else if ("company".equalsIgnoreCase(_searchField)) {
			m = new SOAPField(SOAPField.FIELDURI, SearchContacts.SEARCH_FIELD_COMPANY, null);
		} else if ("homestreet".equalsIgnoreCase(_searchField)) {
			m = new SOAPField(SOAPField.INDEXEDFIELDURI, SearchContacts.SEARCH_FIELD_STREET, SearchContacts.SEARCH_INDEX_HOME);
		} else if ("homecity".equalsIgnoreCase(_searchField)) {
			m = new SOAPField(SOAPField.INDEXEDFIELDURI, SearchContacts.SEARCH_FIELD_CITY, SearchContacts.SEARCH_INDEX_HOME);
		} else if ("homestate".equalsIgnoreCase(_searchField)) {
			m = new SOAPField(SOAPField.INDEXEDFIELDURI, SearchContacts.SEARCH_FIELD_STATE, SearchContacts.SEARCH_INDEX_HOME);
		} else if ("homepostalcode".equalsIgnoreCase(_searchField)) {
			m = new SOAPField(SOAPField.INDEXEDFIELDURI, SearchContacts.SEARCH_FIELD_POSTALCODE, SearchContacts.SEARCH_INDEX_HOME);
		} else if ("homecountry".equalsIgnoreCase(_searchField)) {
			m = new SOAPField(SOAPField.INDEXEDFIELDURI, SearchContacts.SEARCH_FIELD_COUNTRYORREGION, SearchContacts.SEARCH_INDEX_HOME);
		} else if ("businessstreet".equalsIgnoreCase(_searchField)) {
			m = new SOAPField(SOAPField.INDEXEDFIELDURI, SearchContacts.SEARCH_FIELD_STREET, SearchContacts.SEARCH_INDEX_BUSINESS);
		} else if ("businesscity".equalsIgnoreCase(_searchField)) {
			m = new SOAPField(SOAPField.INDEXEDFIELDURI, SearchContacts.SEARCH_FIELD_CITY, SearchContacts.SEARCH_INDEX_BUSINESS);
		} else if ("businessstate".equalsIgnoreCase(_searchField)) {
			m = new SOAPField(SOAPField.INDEXEDFIELDURI, SearchContacts.SEARCH_FIELD_STATE, SearchContacts.SEARCH_INDEX_BUSINESS);
		} else if ("businesspostalcode".equalsIgnoreCase(_searchField)) {
			m = new SOAPField(SOAPField.INDEXEDFIELDURI, SearchContacts.SEARCH_FIELD_POSTALCODE, SearchContacts.SEARCH_INDEX_BUSINESS);
		} else if ("businesscountry".equalsIgnoreCase(_searchField)) {
			m = new SOAPField(SOAPField.INDEXEDFIELDURI, SearchContacts.SEARCH_FIELD_COUNTRYORREGION, SearchContacts.SEARCH_INDEX_BUSINESS);
		} else if ("fileas".equalsIgnoreCase(_searchField)) {
			m = new SOAPField(SOAPField.FIELDURI, SearchContacts.SEARCH_FIELD_FILEAS, null);
		} else if ("emailaddress1".equalsIgnoreCase(_searchField)) {
			m = new SOAPField(SOAPField.INDEXEDFIELDURI, SearchContacts.SEARCH_FIELD_EMAILADDRESS, SEARCH_INDEX_EMAILADDRESS1);
		} else if ("emailaddress2".equalsIgnoreCase(_searchField)) {
			m = new SOAPField(SOAPField.INDEXEDFIELDURI, SearchContacts.SEARCH_FIELD_EMAILADDRESS, SEARCH_INDEX_EMAILADDRESS2);
		} else if ("emailaddress3".equalsIgnoreCase(_searchField)) {
			m = new SOAPField(SOAPField.INDEXEDFIELDURI, SearchContacts.SEARCH_FIELD_EMAILADDRESS, SEARCH_INDEX_EMAILADDRESS3);
		} else {
			throw new IllegalArgumentException("\"field\" is not valid. Must be one of the following: givenname, surname, subject, company, homecity,homestreet, businesscity,homestate,homepostalcode,homecountry,businessstreet,businessstate,businesspostalcode,businesscountry,fileas,emailaddress");
		}

		return m;

	}

	/**
	 * Sets the Search Mode On the SOAP Template. .
	 * 
	 * @param _containmentMode
	 */
	public void setSearchMode(String _containmentMode) {
		if (_containmentMode != null) {
			params.put(ITEM_SEARCH_MODE, _containmentMode);
		}
	}

	/**
	 * Sets the Limit for the number of Items to be displayed on the SOAP template.
	 * 
	 * @param _limit
	 */
	public void setEntriesLimit(Integer _limit) {
		if (_limit != null) {
			params.put(SOAPActionBase.LIMIT, "" + _limit);
		}
	}

	/**
	 * Sets the Offset parameter for the SOAP Template.
	 * 
	 * @param _offset
	 */
	public void setOffset(Integer _offset) {
		if (_offset != null) {
			params.put(SOAPActionBase.OFFSET, "" + _offset);
		}
	}

	/**
	 * Sets the Basepoint value for the SOAP template depending on Whether the search is to be performed from the <b>Beginning</b> or from the <b>End</b>.
	 * 
	 * @param _basepoint
	 */
	public void setBasePoint(String _basepoint) {
		if (_basepoint != null) {
			params.put(SOAPActionBase.BASEPOINT, "" + _basepoint);
		}
	}

	/**
	 * This returns back the SOAP-Action
	 * 
	 * @return String(SOAP-Action url)
	 */
	@Override
	public String getSoapAction() {
		return "http://schemas.microsoft.com/exchange/services/2006/messages/FindItem";
	}

	@Override
	public String getSoapPacket() throws IOException {
		return getSoapTemplate("/net/aw20/msexchange/soap/templates/SearchItem.soap", params);
	}

	/**
	 * Upon a successful 200 status code; this represents the server response raw XML packet
	 * 
	 * @param xmlResponse
	 * @return parsed xmlResponse to List object
	 * @throws MSExchangeException
	 */
	@Override
	public List<Map<String, Object>> onResponse(String xmlResponse) throws MSExchangeException {
		List<Map<String, Object>> contacts = new ArrayList<Map<String, Object>>();
		contacts = processRequest(xmlResponse, CONTACT_TAG);

		// Calls the processError() function when the Error Response is received from the server.
		if (contacts.isEmpty()) {
			contacts = processError(xmlResponse);
		}

		return contacts;
	}

}

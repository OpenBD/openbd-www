/* 
 *  Copyright (C) 2000 - 2011 aw2.0 Ltd
 *
 *  This file is part of Open BlueDragon (OpenBD) CFML Server Engine.
 *  
 *  OpenBD is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  Free Software Foundation,version 3.
 *  
 *  OpenBD is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  
 *  You should have received a copy of the GNU General Public License
 *  along with OpenBD.  If not, see http://www.gnu.org/licenses/
 *  
 *  Additional permission under GNU GPL version 3 section 7
 *  
 *  If you modify this Program, or any covered work, by linking or combining 
 *  it with any of the JARS listed in the README.txt (or a modified version of 
 *  (that library), containing parts covered by the terms of that JAR, the 
 *  licensors of this Program grant you additional permission to convey the 
 *  resulting work. 
 *  README.txt @ http://www.openbluedragon.org/license/README.txt
 *  
 *  http://www.openbluedragon.org/
 */

package net.aw20.msexchange.soap.calendar;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.aw20.msexchange.MSExchangeException;
import net.aw20.msexchange.soap.SOAPActionBase;
import net.aw20.msexchange.soap.items.CreateItem;
import net.aw20.msexchange.soap.task.CreateTask;
import net.aw20.openbd.plugins.exchange.helpers.ExchangeUtility;

import org.apache.commons.lang.StringEscapeUtils;

import com.naryx.tagfusion.cfm.engine.cfArrayData;
import com.naryx.tagfusion.cfm.engine.cfStructData;
import com.naryx.tagfusion.cfm.engine.cfmRunTimeException;

public class CreateCalendarItem extends CreateTask {
	public static final String FOLDER_ID_CONTACT = "calendar";

	public static final String UPDATE_FIELD_LOCATION = "$(LOCATION)";

	public static final String UPDATE_FIELD_LEGACY_FREE_BUSY_STATUS = "$(LEGACY_FREE_BUSY_STATUS)";

	public static final String UPDATE_FIELD_IS_ALLDAY_EVENT = "$(IS_ALLDAY_EVENT)";

	public static final String UPDATE_FIELD_REMINDER_MINUTES_BEFORE_START = "$(REMINDER_MINUTES_BEFORE_START)";

	public static final String UPDATE_FIELD_REQUIRED_ATTENDEES = "$(REQUIRED_ATTENDEES)";

	public static final String UPDATE_FIELD_OPTIONAL_ATTENDEES = "$(OPTIONAL_ATTENDEES)";

	public static final String UPDATE_FIELD_RESOURCES = "$(RESOURCES)";

	public static final String UPDATE_FIELD_REQUIRED_ATTENDEES_DISPLAY_NAME = "$(REQUIRED_ATTENDEES_DISPLAY_NAME)";

	public static final String UPDATE_FIELD_OPTIONAL_ATTENDEES_DISPLAY_NAME = "$(OPTIONAL_ATTENDEES_DISPLAY_NAME)";

	public static final String UPDATE_FIELD_RESOURCES_DISPLAY_NAME = "$(RESOURCES_DISPLAY_NAME)";

	public static final String UPDATE_FIELD_CULTURE = "$(CULTURE)";

	public static final String UPDATE_FIELD_WHEN = "$(WHEN)";

	public static final String UPDATE_FIELD_CONFERENCE_TYPE = "$(CONFERENCE_TYPE)";

	public static final String UPDATE_FIELD_ALLOW_NEW_TIME_PROPOSAL = "$(ALLOW_NEW_TIME_PROPOSAL)";

	public static final String UPDATE_FIELD_MEETING_WORKSPACE_URL = "$(MEETING_WORKSPACE_URL)";

	public static final String UPDATE_FIELD_NET_SHOW_URL = "$(NET_SHOW_URL)";

	private final String ROOT_TAG = "t:CalendarItem";

	/**
	 * Sets SendMeetingInvitations, MessageDisposition, FolderId values in the CreateCalendarItem operation.
	 */
	public CreateCalendarItem() {
		params = new HashMap<String, String>();
		params.put(SOAPActionBase.SEND_MEETING_INVITATIONS, CreateItem.MEETING_INVITATIONS_SEND_TO_NONE);
		params.put(SOAPActionBase.MESSAGE_DISPOSITION, "");
		params.put(SOAPActionBase.FOLDER_ID, FOLDER_ID_CONTACT);
	}

	/**
	 * Sets the <b>Culture</b> of the Item.
	 * 
	 * @param _var
	 */
	public void setCulture(String _var) {
		StringBuilder tagString = new StringBuilder("");
		if (_var != null) {
			tagString.append("<t:Culture>").append(_var).append("</t:Culture>");
			params.put(UPDATE_FIELD_CULTURE, tagString.toString());
		} else {
			params.put(UPDATE_FIELD_CULTURE, tagString.toString());
		}
	}

	/**
	 * Sets the <b>When</b> of the CalendarItem.
	 * 
	 * @param _var
	 */
	public void setWhen(String _var) {
		StringBuilder tagString = new StringBuilder("");
		if (_var != null) {
			tagString.append("<t:When>").append(StringEscapeUtils.escapeXml(_var)).append("</t:When>");
			params.put(UPDATE_FIELD_WHEN, tagString.toString());
		} else {
			params.put(UPDATE_FIELD_WHEN, tagString.toString());
		}
	}

	/**
	 * Sets the <b>ConferenceType</b> of the CalendarItem.
	 * 
	 * @param _var
	 */
	public void setConferenceType(Integer _var) {
		StringBuilder tagString = new StringBuilder("");
		if (_var != null) {
			tagString.append("<t:ConferenceType>").append(_var).append("</t:ConferenceType>");
			params.put(UPDATE_FIELD_CONFERENCE_TYPE, tagString.toString());
		} else {
			params.put(UPDATE_FIELD_CONFERENCE_TYPE, tagString.toString());
		}
	}

	/**
	 * Sets the <b>AllowNewTimeProposal</b> of the CalendarItem.
	 * 
	 * @param _var
	 */
	public void setAllowNewTimeProposal(Boolean _var) {
		StringBuilder tagString = new StringBuilder("");
		if (_var != null) {
			tagString.append("<t:AllowNewTimeProposal>").append(_var).append("</t:AllowNewTimeProposal>");
			params.put(UPDATE_FIELD_ALLOW_NEW_TIME_PROPOSAL, tagString.toString());
		} else {
			params.put(UPDATE_FIELD_ALLOW_NEW_TIME_PROPOSAL, tagString.toString());
		}
	}

	/**
	 * Sets the <b>MeetingWorkspaceUrl</b> of the CalendarItem.
	 * 
	 * @param _var
	 */
	public void setMeetingWorkspaceUrl(String _var) {
		StringBuilder tagString = new StringBuilder("");
		if (_var != null) {
			tagString.append("<t:MeetingWorkspaceUrl>").append(StringEscapeUtils.escapeXml(_var)).append("</t:MeetingWorkspaceUrl>");
			params.put(UPDATE_FIELD_MEETING_WORKSPACE_URL, tagString.toString());
		} else {
			params.put(UPDATE_FIELD_MEETING_WORKSPACE_URL, tagString.toString());
		}
	}

	/**
	 * Sets the <b>NetShowUrl</b> of the CalendarItem.
	 * 
	 * @param _var
	 */
	public void setNetShowUrl(String _var) {
		StringBuilder tagString = new StringBuilder("");
		if (_var != null) {
			tagString.append("<t:NetShowUrl>").append(StringEscapeUtils.escapeXml(_var)).append("</t:NetShowUrl>");
			params.put(UPDATE_FIELD_NET_SHOW_URL, tagString.toString());
		} else {
			params.put(UPDATE_FIELD_NET_SHOW_URL, tagString.toString());
		}
	}

	/**
	 * Sets the <b>Start</b> of the CalendarItem.
	 * 
	 * @param _var
	 */
	public void setCalendarStart(String _var) {
		StringBuilder tagString = new StringBuilder("");
		if (_var != null) {
			tagString.append("<t:Start>").append(_var).append("</t:Start>");
			params.put(SOAPActionBase.APPOINTMENT_START, tagString.toString());
		} else {
			params.put(SOAPActionBase.APPOINTMENT_START, tagString.toString());
		}
	}

	/**
	 * Sets the <b>End</b> of the CalendarItem.
	 * 
	 * @param _var
	 */
	public void setCalendarEnd(String _var) {
		StringBuilder tagString = new StringBuilder("");
		if (_var != null) {
			tagString.append("<t:End>").append(_var).append("</t:End>");
			params.put(SOAPActionBase.APPOINTMENT_END, tagString.toString());
		} else {
			params.put(SOAPActionBase.APPOINTMENT_END, tagString.toString());
		}
	}

	/**
	 * Sets the <b>IsAllDayEvent</b> of the CalendarItem.
	 * 
	 * @param _var
	 */
	public void setIsAllDayEvent(Boolean _var) {
		StringBuilder tagString = new StringBuilder("");
		if (_var != null) {
			tagString.append("<t:IsAllDayEvent>").append(_var).append("</t:IsAllDayEvent>");
			params.put(UPDATE_FIELD_IS_ALLDAY_EVENT, tagString.toString());
		} else {
			params.put(UPDATE_FIELD_IS_ALLDAY_EVENT, tagString.toString());
		}
	}

	/**
	 * Sets the <b>LegacyFreeBusyStatus</b> of the CalendarItem.
	 * 
	 * @param _var
	 */
	public void setFreeBusyStatus(String _var) {
		StringBuilder tagString = new StringBuilder("");
		if (_var != null) {
			tagString.append("<t:LegacyFreeBusyStatus>").append(_var).append("</t:LegacyFreeBusyStatus>");
			params.put(UPDATE_FIELD_LEGACY_FREE_BUSY_STATUS, tagString.toString());
		} else {
			params.put(UPDATE_FIELD_LEGACY_FREE_BUSY_STATUS, tagString.toString());
		}
	}

	/**
	 * Sets the <b>Location</b> of the CalendarItem.
	 * 
	 * @param _var
	 */
	public void setLocation(String _var) {
		StringBuilder tagString = new StringBuilder("");
		if (_var != null) {
			tagString.append("<t:Location>").append(StringEscapeUtils.escapeXml(_var)).append("</t:Location>");
			params.put(UPDATE_FIELD_LOCATION, tagString.toString());
		} else {
			params.put(UPDATE_FIELD_LOCATION, tagString.toString());
		}
	}

	/**
	 * Sets the <b>RequiredAttendees</b> of the CalendarItem. RequiredAttendees are provided as the array of Structures in the input, Each structure containing email address and DisplayName of email address.
	 * 
	 * @param _attendees
	 * @throws cfmRunTimeException
	 */
	public void setRequiredAttendees(cfArrayData _attendees) throws cfmRunTimeException {
		StringBuilder tagString = new StringBuilder("");
		if (_attendees != null) {
			// checks whether the the attendees array is empty.
			ExchangeUtility.parseAttendees(_attendees, "RequiredAttendees");
			tagString.append("<t:RequiredAttendees>");
			for (int counter = 0; counter < _attendees.size(); counter++) {
				cfStructData attendees = (cfStructData) _attendees.getData(counter + 1);
				tagString.append("<t:Attendee><t:Mailbox><t:Name>").append(StringEscapeUtils.escapeXml(ExchangeUtility.parseDisplayName(attendees, "RequiredAttendees -> DisplayName"))).append("</t:Name><t:EmailAddress>").append(StringEscapeUtils.escapeXml(ExchangeUtility.parseEmail(attendees, "RequiredAttendees -> Email"))).append("</t:EmailAddress></t:Mailbox></t:Attendee>");
			}
			tagString.append("</t:RequiredAttendees>");
			params.put(SOAPActionBase.SEND_MEETING_INVITATIONS, CreateItem.MEETING_INVITATIONS_SEND_TO_ALL_AND_SAVE_COPY);
			params.put(UPDATE_FIELD_REQUIRED_ATTENDEES, tagString.toString());
		} else {
			params.put(UPDATE_FIELD_REQUIRED_ATTENDEES, tagString.toString());
		}
	}

	/**
	 * Sets the <b>OptionalAttendees</b> of the CalendarItem. OptionalAttendees are provided as the array of Structures in the input, Each structure containing email address and DisplayName of email address.
	 * 
	 * @param _attendees
	 * @throws cfmRunTimeException
	 */
	public void setOptionalAttendees(cfArrayData _attendees) throws cfmRunTimeException {
		StringBuilder tagString = new StringBuilder("");
		if (_attendees != null) {
			// checks whether the the attendees array is empty.
			ExchangeUtility.parseAttendees(_attendees, "OptionalAttendees");
			tagString.append("<t:OptionalAttendees>");
			for (int counter = 0; counter < _attendees.size(); counter++) {
				cfStructData attendees = (cfStructData) _attendees.getData(counter + 1);
				tagString.append("<t:Attendee><t:Mailbox><t:Name>").append(StringEscapeUtils.escapeXml(ExchangeUtility.parseDisplayName(attendees, "OptionalAttendees -> DisplayName"))).append("</t:Name><t:EmailAddress>").append(StringEscapeUtils.escapeXml(ExchangeUtility.parseEmail(attendees, "OptionalAttendees -> Email"))).append("</t:EmailAddress></t:Mailbox></t:Attendee>");
			}
			tagString.append("</t:OptionalAttendees>");
			params.put(SOAPActionBase.SEND_MEETING_INVITATIONS, CreateItem.MEETING_INVITATIONS_SEND_TO_ALL_AND_SAVE_COPY);
			params.put(UPDATE_FIELD_OPTIONAL_ATTENDEES, tagString.toString());
		} else {
			params.put(UPDATE_FIELD_OPTIONAL_ATTENDEES, tagString.toString());
		}
	}

	/**
	 * Sets the <b>Resources</b> of the CalendarItem. Resources are provided as the array of Structures in the input, Each structure containing email address and DisplayName of email address.
	 * 
	 * @param _attendees
	 * @throws cfmRunTimeException
	 */
	public void setResources(cfArrayData _attendees) throws cfmRunTimeException {
		StringBuilder tagString = new StringBuilder("");
		if (_attendees != null) {
			// checks whether the the attendees array is empty.
			ExchangeUtility.parseAttendees(_attendees, "Resources");
			tagString.append("<t:Resources>");
			for (int counter = 0; counter < _attendees.size(); counter++) {
				cfStructData attendees = (cfStructData) _attendees.getData(counter + 1);
				tagString.append("<t:Attendee><t:Mailbox><t:Name>").append(StringEscapeUtils.escapeXml(ExchangeUtility.parseDisplayName(attendees, "Resources -> DisplayName"))).append("</t:Name><t:EmailAddress>").append(StringEscapeUtils.escapeXml(ExchangeUtility.parseEmail(attendees, "Resources -> Email"))).append("</t:EmailAddress></t:Mailbox></t:Attendee>");
			}
			tagString.append("</t:Resources>");
			params.put(SOAPActionBase.SEND_MEETING_INVITATIONS, CreateItem.MEETING_INVITATIONS_SEND_TO_ALL_AND_SAVE_COPY);
			params.put(UPDATE_FIELD_RESOURCES, tagString.toString());
		} else {
			params.put(UPDATE_FIELD_RESOURCES, tagString.toString());
		}
	}

	@Override
	public String getSoapPacket() throws IOException {
		return getSoapTemplate("/net/aw20/msexchange/soap/templates/CreateCalendarItem.soap", params);
	}

	/**
	 * Upon a successful 200 status code; this represents the server response raw XML packet
	 * 
	 * @param xmlResponse
	 * @return parsed xmlResponse to List object
	 * @throws MSExchangeException
	 */
	@Override
	public List<Map<String, Object>> onResponse(String xmlResponse) throws MSExchangeException {
		List<Map<String, Object>> calendarItem = new ArrayList<Map<String, Object>>();
		calendarItem = processRequest(xmlResponse, ROOT_TAG);
		if (calendarItem.isEmpty()) {
			calendarItem = processError(xmlResponse);
		}
		return calendarItem;
	}

}

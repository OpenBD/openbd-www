/* 
 *  Copyright (C) 2000 - 2011 aw2.0 Ltd
 *
 *  This file is part of Open BlueDragon (OpenBD) CFML Server Engine.
 *  
 *  OpenBD is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  Free Software Foundation,version 3.
 *  
 *  OpenBD is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  
 *  You should have received a copy of the GNU General Public License
 *  along with OpenBD.  If not, see http://www.gnu.org/licenses/
 *  
 *  Additional permission under GNU GPL version 3 section 7
 *  
 *  If you modify this Program, or any covered work, by linking or combining 
 *  it with any of the JARS listed in the README.txt (or a modified version of 
 *  (that library), containing parts covered by the terms of that JAR, the 
 *  licensors of this Program grant you additional permission to convey the 
 *  resulting work. 
 *  README.txt @ http://www.openbluedragon.org/license/README.txt
 *  
 *  http://www.openbluedragon.org/
 */

package net.aw20.msexchange.soap.items;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import net.aw20.msexchange.MSExchangeException;
import net.aw20.msexchange.soap.SOAPActionBase;
import net.aw20.msexchange.soap.SOAPRequestInterface;

public abstract class CreateItem extends SOAPActionBase implements SOAPRequestInterface {

	public static String MEETING_INVITATIONS_SEND_TO_NONE = " SendMeetingInvitations='SendToNone' ";

	public static String MEETING_INVITATIONS_SEND_ONLY_TO_ALL = " SendMeetingInvitations='SendOnlyToAll' ";

	public static String MEETING_INVITATIONS_SEND_TO_ALL_AND_SAVE_COPY = " SendMeetingInvitations='SendToAllAndSaveCopy' ";

	protected Map<String, String> params;

	/**
	 * This returns back the SOAP-Action
	 * 
	 * @return String(SOAP-Action url)
	 */
	public String getSoapAction() {
		return "http://schemas.microsoft.com/exchange/services/2006/messages/CreateItem";
	}

	public String getSoapPacket() throws IOException {
		return getSoapTemplate("/net/aw20/msexchange/soap/templates/CreateItem.soap", params);
	}

	/**
	 * Upon a successful 200 status code; this represents the server response raw XML packet
	 * 
	 * @param xmlResponse
	 * @return parsed xmlResponse to List object
	 * @throws MSExchangeException
	 */
	public abstract List<Map<String, Object>> onResponse(String xmlResponse) throws MSExchangeException;

}

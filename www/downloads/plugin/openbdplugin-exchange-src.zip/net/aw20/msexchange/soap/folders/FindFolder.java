/* 
 *  Copyright (C) 2000 - 2011 aw2.0 Ltd
 *
 *  This file is part of Open BlueDragon (OpenBD) CFML Server Engine.
 *  
 *  OpenBD is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  Free Software Foundation,version 3.
 *  
 *  OpenBD is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  
 *  You should have received a copy of the GNU General Public License
 *  along with OpenBD.  If not, see http://www.gnu.org/licenses/
 *  
 *  Additional permission under GNU GPL version 3 section 7
 *  
 *  If you modify this Program, or any covered work, by linking or combining 
 *  it with any of the JARS listed in the README.txt (or a modified version of 
 *  (that library), containing parts covered by the terms of that JAR, the 
 *  licensors of this Program grant you additional permission to convey the 
 *  resulting work. 
 *  README.txt @ http://www.openbluedragon.org/license/README.txt
 *  
 *  http://www.openbluedragon.org/
 */

package net.aw20.msexchange.soap.folders;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.aw20.msexchange.MSExchangeException;
import net.aw20.msexchange.soap.SOAPActionBase;
import net.aw20.msexchange.soap.SOAPRequestInterface;

public class FindFolder extends SOAPActionBase implements SOAPRequestInterface {

	public static String FOLDER_CALENDAR = "calendar";

	public static String FOLDER_CONTACTS = "contacts";

	public static String FOLDER_INBOX = "inbox";

	public static String FOLDER_DELETEDITEMS = "deleteditems";

	public static String FOLDER_DRAFTS = "drafts";

	public static String FOLDER_JOURNAL = "journal";

	public static String FOLDER_NOTES = "notes";

	public static String FOLDER_OUTBOX = "outbox";

	public static String FOLDER_SENTITEMS = "sentitems";

	public static String FOLDER_TASKS = "tasks";

	public static String FOLDER_MSGFOLDERROOT = "msgfolderroot";

	public static String FOLDER_ROOT = "root";

	public static String FOLDER_JUNKEMAIL = "junkemail";

	public static String FOLDER_SEARCHFOLDERS = "searchfolders";

	public static String FOLDER_VOICEMAIL = "voicemail";

	protected Map<String, String> params;

	public static final Map<String, String> responseTagValues = new HashMap<String, String>();

	static {
		responseTagValues.put("calendar", "CalendarFolder");
		responseTagValues.put("contacts", "ContactsFolder");
		responseTagValues.put("inbox", "Folder");
		responseTagValues.put("deleteditems", "Folder");
		responseTagValues.put("drafts", "Folder");
		responseTagValues.put("journal", "Folder");
		responseTagValues.put("notes", "Folder");
		responseTagValues.put("outbox", "Folder");
		responseTagValues.put("sentitems", "Folder");
		responseTagValues.put("tasks", "TasksFolder");
		responseTagValues.put("msgfolderroot", "Folder");
		responseTagValues.put("root", "Folder");
		responseTagValues.put("junkemail", "Folder");
		responseTagValues.put("searchfolders", "SearchFolder");
		responseTagValues.put("voicemail", "Folder");
	}

	/**
	 * Sets the BaseShape and FolderId.
	 * 
	 * @param _baseShape
	 * @param folders
	 */
	public FindFolder(String _baseShape, String folders) {
		params = new HashMap<String, String>();
		params.put(BASE_SHAPE, _baseShape);
		params.put(FOLDER_ID, folders);
	}

	/**
	 * This returns back the SOAP-Action
	 * 
	 * @return String(SOAP-Action url)
	 */
	@Override
	public String getSoapAction() {
		return "http://schemas.microsoft.com/exchange/services/2006/messages/FindFolder";
	}

	@Override
	public String getSoapPacket() throws IOException {
		return getSoapTemplate("/net/aw20/msexchange/soap/templates/FindFolder.soap", params);
	}

	/**
	 * Upon a successful 200 status code; this represents the server response raw XML packet
	 * 
	 * @param xmlResponse
	 * @return parsed xmlResponse to List object
	 * @throws MSExchangeException
	 */
	@Override
	public List<Map<String, Object>> onResponse(String xmlResponse) throws MSExchangeException {
		List<Map<String, Object>> folders = new ArrayList<Map<String, Object>>();
		folders = processRequest(xmlResponse, "t:" + responseTagValues.get(params.get(FOLDER_ID)));
		return folders;
	}

}

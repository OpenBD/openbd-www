/* 
 *  Copyright (C) 2000 - 2011 aw2.0 Ltd
 *
 *  This file is part of Open BlueDragon (OpenBD) CFML Server Engine.
 *  
 *  OpenBD is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  Free Software Foundation,version 3.
 *  
 *  OpenBD is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  
 *  You should have received a copy of the GNU General Public License
 *  along with OpenBD.  If not, see http://www.gnu.org/licenses/
 *  
 *  Additional permission under GNU GPL version 3 section 7
 *  
 *  If you modify this Program, or any covered work, by linking or combining 
 *  it with any of the JARS listed in the README.txt (or a modified version of 
 *  (that library), containing parts covered by the terms of that JAR, the 
 *  licensors of this Program grant you additional permission to convey the 
 *  resulting work. 
 *  README.txt @ http://www.openbluedragon.org/license/README.txt
 *  
 *  http://www.openbluedragon.org/
 */

package net.aw20.msexchange.soap;

import java.io.IOException;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import net.aw20.msexchange.MSExchangeException;

import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import com.sun.org.apache.xerces.internal.dom.DeferredTextImpl;

public class SOAPResponseParser extends DefaultHandler {

	/**
	 * Produces a List from xml response string for a parent tag
	 * 
	 * @param response
	 * @param parentTag
	 * @return converted List from response
	 * @throws MSExchangeException
	 */
	public List<Map<String, Object>> parseResponse(String xmlResponseString, String parentTag) throws MSExchangeException {
		List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
		StringReader reader = null;

		try {
			DocumentBuilderFactory fact = DocumentBuilderFactory.newInstance();
			DocumentBuilder parser = fact.newDocumentBuilder();

			reader = new StringReader(xmlResponseString);
			InputSource inputSource = new InputSource(reader);
			Document doc = parser.parse(inputSource);

			doc.getDocumentElement().normalize();

			NodeList nodes = doc.getElementsByTagName(parentTag);

			list = processNodeList(nodes);
		} catch (ParserConfigurationException e) {
			new MSExchangeException(e);
		} catch (SAXException e) {
			new MSExchangeException(e);
		} catch (IOException e) {
			new MSExchangeException(e);
		} finally {
			reader.close();
		}
		return list;

	}

	/**
	 * Converts an XML NodeList to a List
	 * 
	 * @param nodeList
	 * @return converted List from NodeList
	 */
	private List<Map<String, Object>> processNodeList(NodeList nodeList) {
		List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();

		int i;
		DeferredTextImpl dti;
		// Element e;
		String name = null;
		NamedNodeMap map;
		Node attNode, n;
		for (i = 0; i < nodeList.getLength(); i++) {
			Map<String, Object> m = new HashMap<String, Object>();
			n = nodeList.item(i);
			if (nodeList.item(i) instanceof DeferredTextImpl) {
				dti = (DeferredTextImpl) nodeList.item(i);
				m.put("value", dti.getData());
			} else {
				// e = (Element) nodeList.item(i);

				name = n.getNodeName().toLowerCase().substring(2);

				// process attributes
				map = n.getAttributes();
				if (map != null && map.getLength() > 0) {
					Map<String, Object> attMap = new HashMap<String, Object>();
					for (int j = 0; j < map.getLength(); j++) {

						attNode = map.item(j);
						attMap.put(attNode.getNodeName().toLowerCase(), attNode.getTextContent());
					}
					m.put("attributes", attMap);
				}

				if (n.hasChildNodes()) {
					m.put(name, processNodeList(n.getChildNodes()));
				} else {
					m.put(name, n.getTextContent());
				}
			}
			list.add(m);
		}
		return list;
	}

}

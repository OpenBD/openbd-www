/* 
 *  Copyright (C) 2000 - 2011 aw2.0 Ltd
 *
 *  This file is part of Open BlueDragon (OpenBD) CFML Server Engine.
 *  
 *  OpenBD is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  Free Software Foundation,version 3.
 *  
 *  OpenBD is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  
 *  You should have received a copy of the GNU General Public License
 *  along with OpenBD.  If not, see http://www.gnu.org/licenses/
 *  
 *  Additional permission under GNU GPL version 3 section 7
 *  
 *  If you modify this Program, or any covered work, by linking or combining 
 *  it with any of the JARS listed in the README.txt (or a modified version of 
 *  (that library), containing parts covered by the terms of that JAR, the 
 *  licensors of this Program grant you additional permission to convey the 
 *  resulting work. 
 *  README.txt @ http://www.openbluedragon.org/license/README.txt
 *  
 *  http://www.openbluedragon.org/
 */

package net.aw20.msexchange.soap.task;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.ParserConfigurationException;

import net.aw20.msexchange.MSExchangeException;
import net.aw20.msexchange.soap.SOAPActionBase;
import net.aw20.msexchange.soap.items.CreateItem;
import net.aw20.openbd.plugins.exchange.helpers.ExchangeRecurrenceUtility;
import net.aw20.openbd.plugins.exchange.helpers.ExchangeUtility;

import org.apache.commons.lang.StringEscapeUtils;
import org.xml.sax.SAXException;

import com.naryx.tagfusion.cfm.engine.cfArrayData;
import com.naryx.tagfusion.cfm.engine.cfStructData;
import com.naryx.tagfusion.cfm.engine.cfmRunTimeException;

public class CreateTask extends CreateItem {

	public static final String UPDATE_FIELD_SUBJECT = "$(SUBJECT)";

	public static final String UPDATE_FIELD_START_DATE = "$(START_DATE)";

	public static final String UPDATE_FIELD_DUE_DATE = "$(DUE_DATE)";

	public static final String UPDATE_FIELD_IMPORTANCE = "$(IMPORTANCE)";

	public static final String UPDATE_FIELD_PERCENT_COMPLETE = "$(PERCENT_COMPLETE)";

	public static final String UPDATE_FIELD_STATUS = "$(STATUS)";

	public static final String UPDATE_FIELD_BODY = "$(BODY)";

	public static final String UPDATE_FIELD_REMINDER_DUE_BY = "$(REMINDER_DUE_BY)";

	public static final String UPDATE_FIELD_REMINDER_IS_SET = "$(REMINDER_IS_SET)";

	public static final String UPDATE_FIELD_REMINDER_MINUTES_BEFORE_START = "$(REMINDER_MINUTES_BEFORE_START)";

	public static final String UPDATE_FIELD_CATEGORIES = "$(CATEGORIES)";

	public static final String UPDATE_FIELD_INREPLYTO = "$(INREPLYTO)";

	public static final String UPDATE_FIELD_SENSITIVITY = "$(SENSITIVITY)";

	public static final String UPDATE_FIELD_MILEAGE = "$(MILEAGE)";

	public static final String UPDATE_FIELD_BILLING_INFORMATION = "$(BILLING_INFORMATION)";

	public static final String UPDATE_FIELD_TOTAL_WORK = "$(TOTAL_WORK)";

	public static final String UPDATE_FIELD_ACTUAL_WORK = "$(ACTUAL_WORK)";

	public static final String UPDATE_FIELD_COMPANIES = "$(COMPANIES)";

	public static final String UPDATE_FIELD_RECURRENCE = "$(RECURRENCE)";

	public static final String UPDATE_FIELD_CONTACTS = "$(CONTACTS)";

	private final String ROOT_TAG = "t:Task";

	/**
	 * Sets SendMeetingInvitations, MessageDisposition values in the CreateTaskItem operation.
	 */

	public CreateTask() {
		params = new HashMap<String, String>();
		params.put(SOAPActionBase.SEND_MEETING_INVITATIONS, CreateItem.MEETING_INVITATIONS_SEND_TO_NONE);
		params.put(SOAPActionBase.MESSAGE_DISPOSITION, "");
	}

	/**
	 * Sets the <b>Subject</b> of the Item.
	 * 
	 * @param _var
	 */
	public void setSubject(String _var) {
		if (_var != null) {
			params.put(UPDATE_FIELD_SUBJECT, "<t:Subject>" + StringEscapeUtils.escapeXml(_var) + "</t:Subject>");
		} else {
			params.put(UPDATE_FIELD_SUBJECT, "");
		}
	}

	/**
	 * Sets the <b>StartDate</b> of the Task.
	 * 
	 * @param _var
	 */
	public void setTaskStartDate(String _var) {
		if (_var != null) {
			params.put(UPDATE_FIELD_START_DATE, _var = "<t:StartDate>" + _var + "</t:StartDate>");
		} else {
			params.put(UPDATE_FIELD_START_DATE, "");
		}
	}

	/**
	 * Sets the <b>DueDate</b> of the Task.
	 * 
	 * @param _var
	 */
	public void setTaskDueDate(String _var) {
		if (_var != null) {
			params.put(UPDATE_FIELD_DUE_DATE, "<t:DueDate>" + _var + "</t:DueDate>");
		} else {
			params.put(UPDATE_FIELD_DUE_DATE, "");
		}
	}

	/**
	 * Sets the <b>Importance</b> of the Item.
	 * 
	 * @param _var
	 */
	public void setImportance(String _var) {
		if (_var != null) {
			params.put(UPDATE_FIELD_IMPORTANCE, "<t:Importance>" + _var + "</t:Importance>");
		} else {
			params.put(UPDATE_FIELD_IMPORTANCE, "");
		}
	}

	/**
	 * Sets the <b>PercentComplete</b> of the Task.
	 * 
	 * @param _var
	 */
	public void setPercentComplete(String _var) {
		if (_var != null) {
			params.put(UPDATE_FIELD_PERCENT_COMPLETE, "<t:PercentComplete>" + _var + "</t:PercentComplete>");
		} else {
			params.put(UPDATE_FIELD_PERCENT_COMPLETE, "");
		}
	}

	/**
	 * Sets the <b>Status</b> of the Task.
	 * 
	 * @param _var
	 */
	public void setStatus(String _var) {
		if (_var != null) {
			params.put(UPDATE_FIELD_STATUS, "<t:Status>" + _var + "</t:Status>");
		} else {
			params.put(UPDATE_FIELD_STATUS, "");
		}
	}

	/**
	 * Sets the <b>Body</b> and <b>BodyType</b> of the Item.
	 * 
	 * @param _var
	 * @param _bodyType
	 */
	public void setBody(String _var, String _bodyType) {
		if (_var != null) {
			params.put(UPDATE_FIELD_BODY, "<t:Body BodyType=\"" + _bodyType + "\">" + StringEscapeUtils.escapeXml(_var) + "</t:Body>");
		} else {
			params.put(UPDATE_FIELD_BODY, "");
		}
	}

	/**
	 * Sets the <b>ReminderDueBy</b> of the Item.
	 * 
	 * @param _var
	 */
	public void setReminderDueBy(String _var) {
		if (_var != null) {
			params.put(UPDATE_FIELD_REMINDER_DUE_BY, "<t:ReminderDueBy>" + _var + "</t:ReminderDueBy>");
		} else {
			params.put(UPDATE_FIELD_REMINDER_DUE_BY, "");
		}
	}

	/**
	 * Sets the <b>ReminderIsSet</b> of the Item.
	 * 
	 * @param _var
	 */
	public void setReminderIsSet(Boolean _var) {
		if (_var != null) {
			params.put(UPDATE_FIELD_REMINDER_IS_SET, "<t:ReminderIsSet>" + _var + "</t:ReminderIsSet>");
		} else {
			params.put(UPDATE_FIELD_REMINDER_IS_SET, "");
		}
	}

	/**
	 * Sets the <b>ReminderMinutesBeforeStart</b> of the Item.
	 * 
	 * @param _var
	 */
	public void setReminderMinutesBeforeStart(Integer _var) {
		if (_var != null) {
			params.put(UPDATE_FIELD_REMINDER_MINUTES_BEFORE_START, "<t:ReminderMinutesBeforeStart>" + _var + "</t:ReminderMinutesBeforeStart>");
		} else {
			params.put(UPDATE_FIELD_REMINDER_MINUTES_BEFORE_START, "");
		}
	}

	/**
	 * Sets the <b>Categories</b> of the Item.
	 * 
	 * @param _var
	 */
	public void setCategories(String _var) {
		if (_var != null) {
			params.put(UPDATE_FIELD_CATEGORIES, "<t:Categories><t:String>" + _var + "</t:String></t:Categories>");
		} else {
			params.put(UPDATE_FIELD_CATEGORIES, "");
		}
	}

	/**
	 * Sets the <b>InReplyTo</b> of the Item.
	 * 
	 * @param _var
	 */

	public void setInReplyTo(String _var) {
		StringBuilder tagString = new StringBuilder("");
		if (_var != null) {
			tagString.append("<t:InReplyTo>").append(_var).append("</t:InReplyTo>");
			params.put(UPDATE_FIELD_INREPLYTO, tagString.toString());
		} else {
			params.put(UPDATE_FIELD_INREPLYTO, tagString.toString());
		}
	}

	/**
	 * Sets the <b>Sensitivity</b> of the Item.
	 * 
	 * @param _var
	 */
	public void setSensitivity(String _var) {
		StringBuilder tagString = new StringBuilder("");
		if (_var != null) {
			tagString.append("<t:Sensitivity>").append(_var).append("</t:Sensitivity>");
			params.put(UPDATE_FIELD_SENSITIVITY, tagString.toString());
		} else {
			params.put(UPDATE_FIELD_SENSITIVITY, tagString.toString());
		}
	}

	/**
	 * Sets the <b>Mileage</b> of the Task.
	 * 
	 * @param _var
	 */
	public void setMileage(String _var) {
		if (_var != null) {
			params.put(UPDATE_FIELD_MILEAGE, "<t:Mileage>" + StringEscapeUtils.escapeXml(_var) + "</t:Mileage>");
		} else {
			params.put(UPDATE_FIELD_MILEAGE, "");
		}
	}

	/**
	 * Sets the <b>BillingInformation</b> of the Task.
	 * 
	 * @param _var
	 */
	public void setBillingInformation(String _var) {
		if (_var != null) {
			params.put(UPDATE_FIELD_BILLING_INFORMATION, "<t:BillingInformation>" + StringEscapeUtils.escapeXml(_var) + "</t:BillingInformation>");
		} else {
			params.put(UPDATE_FIELD_BILLING_INFORMATION, "");
		}
	}

	/**
	 * Sets the <b>TotalWork</b> of the Task.
	 * 
	 * @param _var
	 */
	public void setTotalWork(Integer _var) {
		if (_var != null) {
			params.put(UPDATE_FIELD_TOTAL_WORK, "<t:TotalWork>" + _var + "</t:TotalWork>");
		} else {
			params.put(UPDATE_FIELD_TOTAL_WORK, "");
		}
	}

	/**
	 * Sets the <b>ActualWork</b> of the Task.
	 * 
	 * @param _var
	 */
	public void setActualWork(Integer _var) {
		if (_var != null) {
			params.put(UPDATE_FIELD_ACTUAL_WORK, "<t:ActualWork>" + _var + "</t:ActualWork>");
		} else {
			params.put(UPDATE_FIELD_ACTUAL_WORK, "");
		}
	}

	/**
	 * Sets the <b>Companies</b> of the Task.Accepts an array of Strings containing Company names.
	 * 
	 * @param _var
	 * @throws cfmRunTimeException
	 */
	public void setCompanies(cfArrayData _var) throws cfmRunTimeException {
		StringBuilder tagString = new StringBuilder("");
		if (_var != null) {
			tagString.append("<t:Companies>");
			for (int counter = 0; counter < _var.size(); counter++) {
				tagString.append("<t:String>").append(StringEscapeUtils.escapeXml(_var.getData(counter + 1).getString())).append("</t:String>");
			}
			tagString.append("</t:Companies>");
		}
		params.put(UPDATE_FIELD_COMPANIES, tagString.toString());
	}

	/**
	 * Sets the <b>Contacts</b> of the Task.Accepts an array of Strings containing Contacts names.
	 * 
	 * @param _var
	 * @throws cfmRunTimeException
	 */
	public void setContacts(cfArrayData _var) throws cfmRunTimeException {
		StringBuilder tagString = new StringBuilder("");
		if (_var != null) {
			tagString.append("<t:Contacts>");
			for (int counter = 0; counter < _var.size(); counter++) {
				tagString.append("<t:String>").append(StringEscapeUtils.escapeXml(_var.getData(counter + 1).getString())).append("</t:String>");
			}
			tagString.append("</t:Contacts>");
		}
		params.put(UPDATE_FIELD_CONTACTS, tagString.toString());
	}

	/**
	 * Sets the <b>Recurrence</b> of the Task or Calendar.Gets recurrenceType form parseRecurrenceInput function of ExchangeRecurrenceUtility. recurrenceType is an array of String which contains two strings. First string will give repeatpattern value and second will give one these values:"NoEndDateRecurrence,EndDateRecurrence,NumberedRecurrence". Based on recurrenceType the Recurrence is selected.
	 * 
	 * @param struct
	 * @param itemType
	 */
	public void setRecurrence(cfStructData struct, String itemType) {
		if (struct != null) {
			// parseRecurrenceInput validates the input.Returns a sting containing two space separated sub strings.By splitting that we can choose the proper Recurrence.
			String recurrenceType[] = ExchangeRecurrenceUtility.parseRecurrenceInput(struct, itemType).split(" ");
			if ("Daily".equalsIgnoreCase(recurrenceType[0])) {
				setDailyRecurrence(struct, recurrenceType[1]);
			} else if ("DailyRegeneration".equalsIgnoreCase(recurrenceType[0]) || "WeeklyRegeneration".equalsIgnoreCase(recurrenceType[0]) || "MonthlyRegeneration".equalsIgnoreCase(recurrenceType[0]) || "YearlyRegeneration".equalsIgnoreCase(recurrenceType[0])) {
				setRegeneration(struct, recurrenceType[1], recurrenceType[0]);
			} else if ("Weekly".equalsIgnoreCase(recurrenceType[0])) {
				setWeeklyRecurrence(struct, recurrenceType[1]);
			} else if ("AbsoluteMonthlyRecurrence".equals(recurrenceType[0])) {
				setAbsoluteMonthlyRecurrence(struct, recurrenceType[1]);
			} else if ("RelativeMonthlyRecurrence".equals(recurrenceType[0])) {
				setRelativeMonthlyRecurrence(struct, recurrenceType[1]);
			} else if ("AbsoluteYearlyRecurrence".equals(recurrenceType[0])) {
				setAbsoluteYearlyRecurrence(struct, recurrenceType[1]);
			} else if ("RelativeYearlyRecurrence".equals(recurrenceType[0])) {
				setRelativeYearlyRecurrence(struct, recurrenceType[1]);
			}
		} else {
			params.put(UPDATE_FIELD_RECURRENCE, "");
		}

	}

	/**
	 * Sets the <b>RelativeYearlyRecurrence</b> of the Task or Calendar.
	 * 
	 * @param struct
	 * @param durationFormat
	 */
	private void setRelativeYearlyRecurrence(cfStructData struct, String durationFormat) {
		StringBuilder tagString = new StringBuilder("");
		Integer interval = (Integer) struct.get("Interval");
		if (interval == null) {
			interval = 1;
		}
		tagString.append("<t:Recurrence><t:RelativeYearlyRecurrence><t:DaysOfWeek>").append((String) struct.get("DaysOfWeek")).append("</t:DaysOfWeek><t:DayOfWeekIndex>").append((String) struct.get("DayOfWeekIndex")).append("</t:DayOfWeekIndex><t:Month>").append((String) struct.get("Month")).append("</t:Month></t:RelativeYearlyRecurrence>");
		tagString.append(getDurationTag(struct, durationFormat));
		params.put(UPDATE_FIELD_RECURRENCE, tagString.toString());

	}

	/**
	 * Sets the <b>AbsoluteYearlyRecurrence</b> of the Task or Calendar.
	 * 
	 * @param struct
	 * @param durationFormat
	 */
	private void setAbsoluteYearlyRecurrence(cfStructData struct, String durationFormat) {
		StringBuilder tagString = new StringBuilder("");
		Integer interval = (Integer) struct.get("Interval");
		if (interval == null) {
			interval = 1;
		}
		tagString.append("<t:Recurrence><t:AbsoluteYearlyRecurrence><t:DayOfMonth>").append((Integer) struct.get("DayOfMonth")).append("</t:DayOfMonth><t:Month>").append((String) struct.get("Month")).append("</t:Month></t:AbsoluteYearlyRecurrence>");
		tagString.append(getDurationTag(struct, durationFormat));
		params.put(UPDATE_FIELD_RECURRENCE, tagString.toString());

	}

	/**
	 * Sets the <b>RelativeMonthlyRecurrence</b> of the Task or Calendar.
	 * 
	 * @param struct
	 * @param durationFormat
	 */
	private void setRelativeMonthlyRecurrence(cfStructData struct, String durationFormat) {
		StringBuilder tagString = new StringBuilder("");
		Integer interval = (Integer) struct.get("Interval");
		if (interval == null) {
			interval = 1;
		}
		tagString.append("<t:Recurrence><t:RelativeMonthlyRecurrence><t:Interval>").append(interval).append("</t:Interval><t:DaysOfWeek>").append((String) struct.get("DaysOfWeek")).append("</t:DaysOfWeek><t:DayOfWeekIndex>").append((String) struct.get("DayOfWeekIndex")).append("</t:DayOfWeekIndex></t:RelativeMonthlyRecurrence>");
		tagString.append(getDurationTag(struct, durationFormat));
		params.put(UPDATE_FIELD_RECURRENCE, tagString.toString());

	}

	/**
	 * Sets the <b>AbsoluteMonthlyRecurrence</b> of the Task or Calendar.
	 * 
	 * @param struct
	 * @param durationFormat
	 */
	private void setAbsoluteMonthlyRecurrence(cfStructData struct, String durationFormat) {
		StringBuilder tagString = new StringBuilder("");
		Integer interval = (Integer) struct.get("Interval");
		if (interval == null) {
			interval = 1;
		}
		tagString.append("<t:Recurrence><t:AbsoluteMonthlyRecurrence><t:Interval>").append(interval).append("</t:Interval><t:DayOfMonth>").append((Integer) struct.get("DayOfMonth")).append("</t:DayOfMonth></t:AbsoluteMonthlyRecurrence>");
		tagString.append(getDurationTag(struct, durationFormat));
		params.put(UPDATE_FIELD_RECURRENCE, tagString.toString());

	}

	/**
	 * Sets the <b>WeeklyRecurrence</b> of the Task or Calendar.
	 * 
	 * @param struct
	 * @param durationFormat
	 */
	private void setWeeklyRecurrence(cfStructData struct, String durationFormat) {
		StringBuilder tagString = new StringBuilder("");
		Integer interval = (Integer) struct.get("Interval");
		if (interval == null) {
			interval = 1;
		}
		tagString.append("<t:Recurrence><t:WeeklyRecurrence><t:Interval>").append(interval).append("</t:Interval><t:DaysOfWeek>").append((String) struct.get("DaysOfWeek")).append("</t:DaysOfWeek></t:WeeklyRecurrence>");
		tagString.append(getDurationTag(struct, durationFormat));
		params.put(UPDATE_FIELD_RECURRENCE, tagString.toString());

	}

	/**
	 * Sets the <b>DailyRecurrence</b> of the Task or Calendar.
	 * 
	 * @param struct
	 * @param durationFormat
	 */
	private void setDailyRecurrence(cfStructData struct, String durationFormat) {
		StringBuilder tagString = new StringBuilder("");
		Integer interval = (Integer) struct.get("Interval");
		if (interval == null) {
			interval = 1;
		}
		tagString.append("<t:Recurrence><t:DailyRecurrence><t:Interval>").append(interval).append("</t:Interval></t:DailyRecurrence>");
		tagString.append(getDurationTag(struct, durationFormat));
		params.put(UPDATE_FIELD_RECURRENCE, tagString.toString());
	}

	/**
	 * Sets the <b>Regeneration</b> of the Task.Based on the regenerationType provided it will set appropriate Regeneration.
	 * 
	 * @param struct
	 * @param durationFormat
	 * @param regenerationType
	 */
	private void setRegeneration(cfStructData struct, String durationFormat, String regenerationType) {
		StringBuilder tagString = new StringBuilder("");
		Integer interval = (Integer) struct.get("Interval");
		if (interval == null) {
			interval = 1;
		}
		if ("DailyRegeneration".equals(regenerationType)) {
			tagString.append("<t:Recurrence><t:DailyRegeneration><t:Interval>").append(interval).append("</t:Interval></t:DailyRegeneration>");
		} else if ("WeeklyRegeneration".equals(regenerationType)) {
			tagString.append("<t:Recurrence><t:WeeklyRegeneration><t:Interval>").append(interval).append("</t:Interval></t:WeeklyRegeneration>");
		} else if ("MonthlyRegeneration".equals(regenerationType)) {
			tagString.append("<t:Recurrence><t:MonthlyRegeneration><t:Interval>").append(interval).append("</t:Interval></t:MonthlyRegeneration>");
		} else if ("YearlyRegeneration".equals(regenerationType)) {
			tagString.append("<t:Recurrence><t:YearlyRegeneration><t:Interval>").append(interval).append("</t:Interval></t:YearlyRegeneration>");
		}
		tagString.append(getDurationTag(struct, durationFormat));
		params.put(UPDATE_FIELD_RECURRENCE, tagString.toString());
	}

	/**
	 * Based on the durationFormat given it will return one of the following Tags:"NoEndDateRecurrence, EndDateRecurrence, NumberedRecurrence" for set property.
	 * 
	 * @param struct
	 * @param durationFormat
	 * @return DurationTag which will give an actual Tag information for SOAP templates.
	 */
	private String getDurationTag(cfStructData struct, String durationFormat) {
		StringBuilder tagString = new StringBuilder("");
		if ("NoEndDateRecurrence".equals(durationFormat)) {
			tagString.append("<t:NoEndRecurrence><t:StartDate>").append(ExchangeUtility.parseDate(struct.get("StartDate"), "StartDate", false)).append("</t:StartDate></t:NoEndRecurrence></t:Recurrence>");
		} else if ("EndDateRecurrence".equals(durationFormat)) {
			tagString.append("<t:EndDateRecurrence><t:StartDate>").append(ExchangeUtility.parseDate(struct.get("StartDate"), "StartDate", false)).append("</t:StartDate><t:EndDate>").append(ExchangeUtility.parseDate(struct.get("EndDate"), "EndDate", false)).append("</t:EndDate></t:EndDateRecurrence></t:Recurrence>");
		} else {
			tagString.append("<t:NumberedRecurrence><t:StartDate>").append(ExchangeUtility.parseDate(struct.get("StartDate"), "StartDate", false)).append("</t:StartDate><t:NumberOfOccurrences>").append((Integer) struct.get("NumberOfOccurrences")).append("</t:NumberOfOccurrences></t:NumberedRecurrence></t:Recurrence>");
		}
		return (tagString.toString());

	}

	@Override
	public String getSoapPacket() throws IOException {
		return getSoapTemplate("/net/aw20/msexchange/soap/templates/CreateTaskItem.soap", params);
	}

	/**
	 * This returns back the SOAP-Action
	 * 
	 * @return String(SOAP-Action url)
	 */
	@Override
	public String getSoapAction() {
		return "http://schemas.microsoft.com/exchange/services/2006/messages/CreateItem";
	}

	/**
	 * Upon a successful 200 status code; this represents the server response raw XML packet
	 * 
	 * @param xmlResponse
	 * @return parsed xmlResponse to List object
	 * @throws MSExchangeException
	 * @throws ParserConfigurationException
	 * @throws SAXException
	 * @throws IOException
	 */
	@Override
	public List<Map<String, Object>> onResponse(String xmlResponse) throws MSExchangeException {
		List<Map<String, Object>> tasks = new ArrayList<Map<String, Object>>();
		tasks = processRequest(xmlResponse, ROOT_TAG);
		if (tasks.isEmpty()) {
			tasks = processError(xmlResponse);
		}
		return tasks;
	}
}

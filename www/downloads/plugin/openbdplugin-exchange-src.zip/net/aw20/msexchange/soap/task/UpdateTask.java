/* 
 *  Copyright (C) 2000 - 2011 aw2.0 Ltd
 *
 *  This file is part of Open BlueDragon (OpenBD) CFML Server Engine.
 *  
 *  OpenBD is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  Free Software Foundation,version 3.
 *  
 *  OpenBD is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  
 *  You should have received a copy of the GNU General Public License
 *  along with OpenBD.  If not, see http://www.gnu.org/licenses/
 *  
 *  Additional permission under GNU GPL version 3 section 7
 *  
 *  If you modify this Program, or any covered work, by linking or combining 
 *  it with any of the JARS listed in the README.txt (or a modified version of 
 *  (that library), containing parts covered by the terms of that JAR, the 
 *  licensors of this Program grant you additional permission to convey the 
 *  resulting work. 
 *  README.txt @ http://www.openbluedragon.org/license/README.txt
 *  
 *  http://www.openbluedragon.org/
 */

package net.aw20.msexchange.soap.task;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.aw20.msexchange.MSExchangeException;
import net.aw20.msexchange.soap.SOAPActionBase;
import net.aw20.msexchange.soap.calendar.CreateCalendarItem;
import net.aw20.msexchange.soap.items.FindItem;
import net.aw20.openbd.plugins.exchange.helpers.ExchangeRecurrenceUtility;
import net.aw20.openbd.plugins.exchange.helpers.ExchangeUtility;

import org.apache.commons.lang.StringEscapeUtils;

import com.naryx.tagfusion.cfm.engine.cfArrayData;
import com.naryx.tagfusion.cfm.engine.cfStructData;
import com.naryx.tagfusion.cfm.engine.cfmRunTimeException;

public class UpdateTask extends FindItem {

	public static final String UPDATE_FIELD_START_DATE = "$(START_DATE)";

	public static final String UPDATE_FIELD_DUE_DATE = "$(DUE_DATE)";

	public static final String UPDATE_FIELD_PERCENT_COMPLETE = "$(PERCENT_COMPLETE)";

	public static final String UPDATE_FIELD_STATUS = "$(STATUS)";

	public static final String UPDATE_FIELD_SUBJECT = "$(SUBJECT)";

	public static final String UPDATE_FIELD_BODY = "$(BODY)";

	public static final String UPDATE_FIELD_IMPORTANCE = "$(IMPORTANCE)";

	public static final String UPDATE_FIELD_REMINDER_DUE_BY = "$(REMINDER_DUE_BY)";

	public static final String UPDATE_FIELD_REMINDER_IS_SET = "$(REMINDER_IS_SET)";

	public static final String UPDATE_FIELD_REMINDER_MINUTES_BEFORE_START = "$(REMINDER_MINUTES_BEFORE_START)";

	public static final String UPDATE_FIELD_TOTAL_WORK = "$(TOTAL_WORK)";

	public static final String UPDATE_FIELD_MILEAGE = "$(MILEAGE)";

	public static final String UPDATE_FIELD_CHANGE_KEY = "$(CHANGE_KEY)";

	public static final String UPDATE_FIELD_CONTACTS = "$(CONTACTS)";

	public static final String UPDATE_FIELD_COMPANIES = "$(COMPANIES)";

	public static final String UPDATE_FIELD_COMPLETE_DATE = "$(COMPLETE_DATE)";

	public static final String UPDATE_FIELD_BILLING_INFORMATION = "$(BILLING_INFORMATION)";

	public static final String UPDATE_FIELD_ACTUAL_WORK = "$(ACTUAL_WORK)";

	private final String ROOT_ELEMENT = "t:Task";

	private String id = "";

	private String changeKey = "";

	public UpdateTask() {
		// String _id, String _changeKey
		params = new HashMap<String, String>();
	}

	/**
	 * Sets the <b>ID</b> of the Item for Update Operation.
	 * 
	 * @param _Id
	 */
	public void setId(String _Id) {
		this.id = _Id;
		params.put(SOAPActionBase.ID, _Id);
	}

	/**
	 * Updates the <b>Recurrence</b> of the Task or Calendar.Gets recurrenceType form parseRecurrenceInput function of ExchangeRecurrenceUtility. recurrenceType is an array of String which contains two strings. First string will give repeatpattern value and second will give one these values:"NoEndDateRecurrence,EndDateRecurrence,NumberedRecurrence". Based on recurrenceType the Recurrence is
	 * selected.
	 * 
	 * @param struct
	 * @param itemType
	 */
	public void setRecurrence(cfStructData struct, String itemType) {
		// parseRecurrenceInput validates the input.Returns a sting containing two space separated sub strings.By splitting that we can choose the proper Recurrence.
		if (struct != null) {
			String recurrenceType[] = ExchangeRecurrenceUtility.parseRecurrenceInput(struct, itemType).split(" ");
			if ("Daily".equalsIgnoreCase(recurrenceType[0])) {
				setDailyRecurrence(struct, recurrenceType[1], itemType);
			} else if ("DailyRegeneration".equalsIgnoreCase(recurrenceType[0]) || "WeeklyRegeneration".equalsIgnoreCase(recurrenceType[0]) || "MonthlyRegeneration".equalsIgnoreCase(recurrenceType[0]) || "YearlyRegeneration".equalsIgnoreCase(recurrenceType[0])) {
				setRegeneration(struct, recurrenceType[1], recurrenceType[0], itemType);
			} else if ("Weekly".equalsIgnoreCase(recurrenceType[0])) {
				setWeeklyRecurrence(struct, recurrenceType[1], itemType);
			} else if ("AbsoluteMonthlyRecurrence".equals(recurrenceType[0])) {
				setAbsoluteMonthlyRecurrence(struct, recurrenceType[1], itemType);
			} else if ("RelativeMonthlyRecurrence".equals(recurrenceType[0])) {
				setRelativeMonthlyRecurrence(struct, recurrenceType[1], itemType);
			} else if ("AbsoluteYearlyRecurrence".equals(recurrenceType[0])) {
				setAbsoluteYearlyRecurrence(struct, recurrenceType[1], itemType);
			} else if ("RelativeYearlyRecurrence".equals(recurrenceType[0])) {
				setRelativeYearlyRecurrence(struct, recurrenceType[1], itemType);
			}
		} else {
			params.put(CreateCalendarItem.UPDATE_FIELD_RECURRENCE, "");
		}

	}

	/**
	 * Updates the <b>Regeneration</b> of the Task.Based on the regenerationType provided it will set appropriate Regeneration.
	 * 
	 * @param struct
	 * @param durationFormat
	 * @param regenerationType
	 * @param itemType
	 */
	public void setRegeneration(cfStructData struct, String durationFormat, String regenerationType, String itemType) {
		StringBuilder tagString = new StringBuilder("");
		Integer interval = (Integer) struct.get("Interval");
		if (interval == null) {
			interval = 1;
		}
		tagString.append("<t:SetItemField><t:FieldURI FieldURI=\"").append(itemType).append(":Recurrence\"/><t:").append(getTag(itemType)).append("><t:Recurrence>");
		if ("DailyRegeneration".equals(regenerationType)) {
			tagString.append("<t:DailyRegeneration><t:Interval>").append(interval).append("</t:Interval></t:DailyRegeneration>");
		} else if ("WeeklyRegeneration".equals(regenerationType)) {
			tagString.append("<t:WeeklyRegeneration><t:Interval>").append(interval).append("</t:Interval></t:WeeklyRegeneration>");
		} else if ("MonthlyRegeneration".equals(regenerationType)) {
			tagString.append("<t:MonthlyRegeneration><t:Interval>").append(interval).append("</t:Interval></t:MonthlyRegeneration>");
		} else if ("YearlyRegeneration".equals(regenerationType)) {
			tagString.append("<t:YearlyRegeneration><t:Interval>").append(interval).append("</t:Interval></t:YearlyRegeneration>");
		}
		tagString.append(getDurationTag(struct, durationFormat));
		tagString.append("</t:").append(getTag(itemType)).append("></t:SetItemField>");
		params.put(CreateCalendarItem.UPDATE_FIELD_RECURRENCE, tagString.toString());
	}

	/**
	 * Provides the tags <b>"Task, CalendarItem"</b> based on given itemType.
	 * 
	 * @param itemType
	 * @return String ("Task" or "CalendarItem")
	 */
	private String getTag(String itemType) {
		String tag;
		if ("task".equals(itemType)) {
			tag = "Task";
		} else {
			tag = "CalendarItem";
		}
		return (tag);
	}

	/**
	 * Updates the <b>RelativeYearlyRecurrence</b> of the Task or Calendar.
	 * 
	 * @param struct
	 * @param durationFormat
	 * @param itemType
	 */
	private void setRelativeYearlyRecurrence(cfStructData struct, String durationFormat, String itemType) {
		StringBuilder tagString = new StringBuilder("");
		Integer interval = (Integer) struct.get("Interval");
		if (interval == null) {
			interval = 1;
		}
		tagString.append("<t:SetItemField><t:FieldURI FieldURI=\"").append(itemType).append(":Recurrence\"/><t:").append(getTag(itemType)).append("><t:Recurrence><t:RelativeYearlyRecurrence><t:DaysOfWeek>").append((String) struct.get("DaysOfWeek")).append("</t:DaysOfWeek><t:DayOfWeekIndex>").append((String) struct.get("DayOfWeekIndex")).append("</t:DayOfWeekIndex><t:Month>").append(
				(String) struct.get("Month")).append("</t:Month></t:RelativeYearlyRecurrence>");
		tagString.append(getDurationTag(struct, durationFormat));
		tagString.append("</t:").append(getTag(itemType)).append("></t:SetItemField>");
		params.put(CreateCalendarItem.UPDATE_FIELD_RECURRENCE, tagString.toString());
	}

	/**
	 * Updates the <b>AbsoluteYearlyRecurrence</b> of the Task or Calendar.
	 * 
	 * @param struct
	 * @param durationFormat
	 * @param itemType
	 */
	private void setAbsoluteYearlyRecurrence(cfStructData struct, String durationFormat, String itemType) {
		StringBuilder tagString = new StringBuilder("");
		Integer interval = (Integer) struct.get("Interval");
		if (interval == null) {
			interval = 1;
		}
		tagString.append("<t:SetItemField><t:FieldURI FieldURI=\"").append(itemType).append(":Recurrence\"/><t:").append(getTag(itemType)).append("><t:Recurrence><t:AbsoluteYearlyRecurrence><t:DayOfMonth>").append((Integer) struct.get("DayOfMonth")).append("</t:DayOfMonth><t:Month>").append((String) struct.get("Month")).append("</t:Month></t:AbsoluteYearlyRecurrence>");
		tagString.append(getDurationTag(struct, durationFormat));
		tagString.append("</t:").append(getTag(itemType)).append("></t:SetItemField>");
		params.put(CreateCalendarItem.UPDATE_FIELD_RECURRENCE, tagString.toString());

	}

	/**
	 * Updates the <b>RelativeMonthlyRecurrence</b> of the Task or Calendar.
	 * 
	 * @param struct
	 * @param durationFormat
	 * @param itemType
	 */
	private void setRelativeMonthlyRecurrence(cfStructData struct, String durationFormat, String itemType) {
		StringBuilder tagString = new StringBuilder("");
		Integer interval = (Integer) struct.get("Interval");
		if (interval == null) {
			interval = 1;
		}
		tagString.append("<t:SetItemField><t:FieldURI FieldURI=\"").append(itemType).append(":Recurrence\"/><t:").append(getTag(itemType)).append("><t:Recurrence><t:RelativeMonthlyRecurrence><t:Interval>").append(interval).append("</t:Interval><t:DaysOfWeek>").append((String) struct.get("DaysOfWeek")).append("</t:DaysOfWeek><t:DayOfWeekIndex>").append((String) struct.get("DayOfWeekIndex")).append(
				"</t:DayOfWeekIndex></t:RelativeMonthlyRecurrence>");
		tagString.append(getDurationTag(struct, durationFormat));
		tagString.append("</t:").append(getTag(itemType)).append("></t:SetItemField>");
		params.put(CreateCalendarItem.UPDATE_FIELD_RECURRENCE, tagString.toString());
	}

	/**
	 * Updates the <b>AbsoluteMonthlyRecurrence</b> of the Task or Calendar.
	 * 
	 * @param struct
	 * @param durationFormat
	 * @param itemType
	 */
	private void setAbsoluteMonthlyRecurrence(cfStructData struct, String durationFormat, String itemType) {
		StringBuilder tagString = new StringBuilder("");
		Integer interval = (Integer) struct.get("Interval");
		if (interval == null) {
			interval = 1;
		}
		tagString.append("<t:SetItemField><t:FieldURI FieldURI=\"").append(itemType).append(":Recurrence\"/><t:").append(getTag(itemType)).append("><t:Recurrence><t:AbsoluteMonthlyRecurrence><t:Interval>").append(interval).append("</t:Interval><t:DayOfMonth>").append((Integer) struct.get("DayOfMonth")).append("</t:DayOfMonth></t:AbsoluteMonthlyRecurrence>");
		tagString.append(getDurationTag(struct, durationFormat));
		tagString.append("</t:").append(getTag(itemType)).append("></t:SetItemField>");
		params.put(CreateCalendarItem.UPDATE_FIELD_RECURRENCE, tagString.toString());

	}

	/**
	 * Updates the <b>WeeklyRecurrence</b> of the Task or Calendar.
	 * 
	 * @param struct
	 * @param durationFormat
	 * @param itemType
	 */
	private void setWeeklyRecurrence(cfStructData struct, String durationFormat, String itemType) {
		StringBuilder tagString = new StringBuilder("");
		Integer interval = (Integer) struct.get("Interval");
		if (interval == null) {
			interval = 1;
		}
		tagString.append("<t:SetItemField><t:FieldURI FieldURI=\"").append(itemType).append(":Recurrence\"/><t:").append(getTag(itemType)).append("><t:Recurrence><t:WeeklyRecurrence><t:Interval>").append(interval).append("</t:Interval><t:DaysOfWeek>").append((String) struct.get("DaysOfWeek")).append("</t:DaysOfWeek></t:WeeklyRecurrence>");
		tagString.append(getDurationTag(struct, durationFormat));
		tagString.append("</t:").append(getTag(itemType)).append("></t:SetItemField>");
		params.put(CreateCalendarItem.UPDATE_FIELD_RECURRENCE, tagString.toString());

	}

	/**
	 * Updates the <b>DailyRecurrence</b> of the Task or Calendar.
	 * 
	 * @param struct
	 * @param durationFormat
	 * @param itemType
	 */
	private void setDailyRecurrence(cfStructData struct, String durationFormat, String itemType) {
		StringBuilder tagString = new StringBuilder("");
		Integer interval = (Integer) struct.get("Interval");
		if (interval == null) {
			interval = 1;
		}
		tagString.append("<t:SetItemField><t:FieldURI FieldURI=\"").append(itemType).append(":Recurrence\"/><t:").append(getTag(itemType)).append("><t:Recurrence><t:DailyRecurrence><t:Interval>").append(interval).append("</t:Interval></t:DailyRecurrence>");
		tagString.append(getDurationTag(struct, durationFormat));
		tagString.append("</t:").append(getTag(itemType)).append("></t:SetItemField>");
		params.put(CreateCalendarItem.UPDATE_FIELD_RECURRENCE, tagString.toString());
	}

	/**
	 * Based on the durationFormat given it will return one of the following Tags:"NoEndDateRecurrence, EndDateRecurrence, NumberedRecurrence" for set property.
	 * 
	 * @param struct
	 * @param durationFormat
	 * @return DurationTag which will give an actual Tag information for SOAP templates.
	 */
	private String getDurationTag(cfStructData struct, String durationFormat) {
		StringBuilder tagString = new StringBuilder("");
		if ("NoEndDateRecurrence".equals(durationFormat)) {
			tagString.append("<t:NoEndRecurrence><t:StartDate>").append(ExchangeUtility.parseDate(struct.get("StartDate"), "StartDate", false)).append("</t:StartDate></t:NoEndRecurrence></t:Recurrence>");
		} else if ("EndDateRecurrence".equals(durationFormat)) {
			tagString.append("<t:EndDateRecurrence><t:StartDate>").append(ExchangeUtility.parseDate(struct.get("StartDate"), "StartDate", false)).append("</t:StartDate><t:EndDate>").append(ExchangeUtility.parseDate(struct.get("EndDate"), "EndDate", false)).append("</t:EndDate></t:EndDateRecurrence></t:Recurrence>");
		} else {
			tagString.append("<t:NumberedRecurrence><t:StartDate>").append(ExchangeUtility.parseDate(struct.get("StartDate"), "StartDate", false)).append("</t:StartDate><t:NumberOfOccurrences>").append((Integer) struct.get("NumberOfOccurrences")).append("</t:NumberOfOccurrences></t:NumberedRecurrence></t:Recurrence>");
		}
		return tagString.toString();

	}

	/**
	 * Updates the <b>Categories</b> of the Item.
	 * 
	 * @param _var
	 */
	public void setCategories(String _var) {
		StringBuilder tagString = new StringBuilder("");
		if (_var != null) {
			tagString.append("<t:SetItemField><t:FieldURI FieldURI=\"item:Categories\"/><t:Item><t:Categories><t:String>").append(_var).append("</t:String></t:Categories></t:Item></t:SetItemField>");
		}
		params.put(CreateCalendarItem.UPDATE_FIELD_CATEGORIES, tagString.toString());
	}

	/**
	 * Updates the <b>Sensitivity</b> of the Item.
	 * 
	 * @param _var
	 */
	public void setSensitivity(String _var) {
		StringBuilder tagString = new StringBuilder("");
		if (_var != null) {
			tagString.append("<t:SetItemField><t:FieldURI FieldURI=\"item:Sensitivity\"/><t:Item><t:Sensitivity>").append(_var).append("</t:Sensitivity></t:Item></t:SetItemField>");
		}
		params.put(CreateCalendarItem.UPDATE_FIELD_SENSITIVITY, tagString.toString());
	}

	/**
	 * Updates the <b>InReplyTo</b> of the Item.
	 * 
	 * @param _var
	 */
	public void setInReplyTo(String _var) {
		StringBuilder tagString = new StringBuilder("");
		if (_var != null) {
			tagString.append("<t:SetItemField><t:FieldURI FieldURI=\"item:InReplyTo\"/><t:Item><t:InReplyTo>").append(_var).append("</t:InReplyTo></t:Item></t:SetItemField>");
		}
		params.put(CreateCalendarItem.UPDATE_FIELD_INREPLYTO, tagString.toString());
	}

	/**
	 * Updates the <b>Mileage</b> of the Task.
	 * 
	 * @param _var
	 */
	public void setMileage(String _var) {
		StringBuilder tagString = new StringBuilder("");
		if (_var != null) {
			tagString.append("<t:SetItemField><t:FieldURI FieldURI=\"task:Mileage\"/><t:Task><t:Mileage>").append(StringEscapeUtils.escapeXml(_var)).append("</t:Mileage></t:Task></t:SetItemField>");
		}
		params.put(UPDATE_FIELD_MILEAGE, tagString.toString());
	}

	/**
	 * Updates the <b>TotalWork</b> of the Task.
	 * 
	 * @param _var
	 */
	public void setTotalWork(Integer _var) {
		StringBuilder tagString = new StringBuilder("");
		if (_var != null) {
			tagString.append("<t:SetItemField><t:FieldURI FieldURI=\"task:TotalWork\"/><t:Task><t:TotalWork>").append(_var).append("</t:TotalWork></t:Task></t:SetItemField>");
		}
		params.put(UPDATE_FIELD_TOTAL_WORK, tagString.toString());
	}

	/**
	 * Updates the <b>CompleteDate</b> of the Task.
	 * 
	 * @param _var
	 */
	public void setCompleteDate(String _var) {
		StringBuilder tagString = new StringBuilder("");
		if (_var != null) {
			tagString.append("<t:SetItemField><t:FieldURI FieldURI=\"task:CompleteDate\"/><t:Task><t:CompleteDate>").append(_var).append("</t:CompleteDate></t:Task></t:SetItemField>");
		}
		params.put(UPDATE_FIELD_COMPLETE_DATE, tagString.toString());
	}

	/**
	 * Updates the <b>BillingInformation</b> of the Task.
	 * 
	 * @param _var
	 */
	public void setBillingInformation(String _var) {
		StringBuilder tagString = new StringBuilder("");
		if (_var != null) {
			tagString.append("<t:SetItemField><t:FieldURI FieldURI=\"task:BillingInformation\"/><t:Task><t:BillingInformation>").append(StringEscapeUtils.escapeXml(_var)).append("</t:BillingInformation></t:Task></t:SetItemField>");
		}
		params.put(UPDATE_FIELD_BILLING_INFORMATION, tagString.toString());
	}

	/**
	 * Updates the <b>ActualWork</b> of the Task.
	 * 
	 * @param _var
	 */
	public void setActualWork(Integer _var) {
		StringBuilder tagString = new StringBuilder("");
		if (_var != null) {
			tagString.append("<t:SetItemField><t:FieldURI FieldURI=\"task:ActualWork\"/><t:Task><t:ActualWork>").append(_var).append("</t:ActualWork></t:Task></t:SetItemField>");
		}
		params.put(UPDATE_FIELD_ACTUAL_WORK, tagString.toString());
	}

	/**
	 * Updates the <b>Contacts</b> of the Task.The Contacts are provided as array of String in the Input.
	 * 
	 * @param _var
	 * @throws cfmRunTimeException
	 */
	public void setContacts(cfArrayData _var) throws cfmRunTimeException {
		StringBuilder tagString = new StringBuilder("");
		if (_var != null) {
			tagString.append("<t:SetItemField><t:FieldURI FieldURI=\"task:Contacts\"/><t:Task><t:Contacts>");
			for (int counter = 0; counter < _var.size(); counter++)
				tagString.append("<t:String>").append(StringEscapeUtils.escapeXml(_var.getData(counter + 1).getString())).append("</t:String>");
			tagString.append("</t:Contacts></t:Task></t:SetItemField>");
		}
		params.put(UPDATE_FIELD_CONTACTS, tagString.toString());
	}

	/**
	 * Updates the <b>Companies</b> of the Task.The Companies are provided as array of String in the Input.
	 * 
	 * @param _var
	 * @throws cfmRunTimeException
	 */
	public void setCompanies(cfArrayData _var) throws cfmRunTimeException {

		StringBuilder tagString = new StringBuilder("");
		if (_var != null) {
			tagString.append("<t:SetItemField><t:FieldURI FieldURI=\"task:Companies\"/><t:Task><t:Companies>");
			for (int counter = 0; counter < _var.size(); counter++) {
				tagString.append("<t:String>").append(StringEscapeUtils.escapeXml(_var.getData(counter + 1).getString())).append("</t:String>");
			}
			tagString.append("</t:Companies></t:Task></t:SetItemField>");
		}
		params.put(UPDATE_FIELD_COMPANIES, tagString.toString());
	}

	/**
	 * Updates the <b>Subject</b> of the Item.
	 * 
	 * @param _Subject
	 */
	public void setSubject(String _Subject) {
		if (_Subject != null) {
			_Subject = "<t:SetItemField>" + "<t:FieldURI FieldURI=\"item:Subject\"/>" + "<t:Item>" + "<t:Subject>" + StringEscapeUtils.escapeXml(_Subject) + "</t:Subject>" + "</t:Item>" + "</t:SetItemField>";
		} else {
			_Subject = "";
		}
		params.put(UPDATE_FIELD_SUBJECT, _Subject);
	}

	/**
	 * Updates the <b>Body</b> and <b>BodyType</b> of the Item.
	 * 
	 * @param _Body
	 * @param _bodyType
	 */
	public void setBody(String _Body, String _bodyType) {
		if (_Body != null) {
			_Body = "<t:SetItemField>" + "<t:FieldURI FieldURI=\"item:Body\"/>" + "<t:Item>" + "<t:Body BodyType=\"" + _bodyType + "\">" + StringEscapeUtils.escapeXml(_Body) + "</t:Body>" + "</t:Item>" + "</t:SetItemField>";
		} else {
			_Body = "";
		}
		params.put(UPDATE_FIELD_BODY, _Body);
	}

	/**
	 * Updates the <b>Importance</b> of the Item.
	 * 
	 * @param _Importance
	 */
	public void setImportance(String _Importance) {
		if (_Importance != null) {
			_Importance = "<t:SetItemField>" + "<t:FieldURI FieldURI=\"item:Importance\"/> " + "<t:Item>" + "<t:Importance>" + _Importance + "</t:Importance>" + "</t:Item>" + "</t:SetItemField>";
		} else {
			_Importance = "";
		}

		params.put(UPDATE_FIELD_IMPORTANCE, _Importance);
	}

	/**
	 * Updates the <b>ReminderDueBy</b> of the Item.
	 * 
	 * @param _ReminderDueBy
	 */
	public void setReminderDueBy(String _ReminderDueBy) {
		if (_ReminderDueBy != null) {
			_ReminderDueBy = "<t:SetItemField>" + "<t:FieldURI FieldURI=\"item:ReminderDueBy\"/>" + "<t:Item>" + "<t:ReminderDueBy>" + _ReminderDueBy + "</t:ReminderDueBy>" + "</t:Item>" + "</t:SetItemField>";
		} else {
			_ReminderDueBy = "";
		}

		params.put(UPDATE_FIELD_REMINDER_DUE_BY, _ReminderDueBy);
	}

	/**
	 * Updates the <b>ReminderIsSet</b> of the Item.
	 * 
	 * @param _ReminderIsSet
	 */
	public void setReminderIsSet(Boolean _ReminderIsSet) {
		String _value = null;
		params.put(UPDATE_FIELD_REMINDER_IS_SET, "");
		if (_ReminderIsSet != null) {
			_value = "<t:SetItemField> <t:FieldURI FieldURI=\"item:ReminderIsSet\"/> <t:Item> <t:ReminderIsSet>" + _ReminderIsSet + "</t:ReminderIsSet> </t:Item> </t:SetItemField>";
			params.put(UPDATE_FIELD_REMINDER_IS_SET, _value);
		}
	}

	/**
	 * Updates the <b>ReminderMinutesBeforeStart</b> of the Item.
	 * 
	 * @param _ReminderMinutesBeforeStart
	 */
	public void setReminderMinutesBeforeStart(Integer _ReminderMinutesBeforeStart) {
		String _val;
		if (_ReminderMinutesBeforeStart != null) {
			_val = "<t:SetItemField> <t:FieldURI FieldURI=\"item:ReminderMinutesBeforeStart\"/> <t:Item> <t:ReminderMinutesBeforeStart>" + _ReminderMinutesBeforeStart + "</t:ReminderMinutesBeforeStart> </t:Item> </t:SetItemField>";
		} else {
			_val = "";
		}

		params.put(UPDATE_FIELD_REMINDER_MINUTES_BEFORE_START, _val);
	}

	/**
	 * Updates the <b>StartDate</b> of the Task.
	 * 
	 * @param _StartDate
	 */
	public void setStartDate(String _StartDate) {
		if (_StartDate != null) {
			_StartDate = "<t:SetItemField>" + "<t:FieldURI FieldURI=\"task:StartDate\"/>" + "<t:Task>" + "<t:StartDate>" + _StartDate + "</t:StartDate>" + "</t:Task>" + "</t:SetItemField>";
		} else {
			_StartDate = "";
		}

		params.put(UPDATE_FIELD_START_DATE, _StartDate);
	}

	/**
	 * Updates the <b>DueDate</b> of the Task.
	 * 
	 * @param _DueDate
	 */
	public void setDueDate(String _DueDate) {
		if (_DueDate != null) {
			_DueDate = "<t:SetItemField>" + "<t:FieldURI FieldURI=\"task:DueDate\"/>" + "<t:Task>" + "<t:DueDate>" + _DueDate + "</t:DueDate>" + "</t:Task>" + "</t:SetItemField>";
		} else {
			_DueDate = "";
		}

		params.put(UPDATE_FIELD_DUE_DATE, _DueDate);
	}

	/**
	 * Updates the <b>PercentComplete</b> of the Task.
	 * 
	 * @param _setPercentComplete
	 */
	public void setPercentComplete(String _setPercentComplete) {
		if (_setPercentComplete != null) {
			_setPercentComplete = "<t:SetItemField>" + "<t:FieldURI FieldURI=\"task:PercentComplete\"/>" + "<t:Task>" + "<t:PercentComplete>" + _setPercentComplete + "</t:PercentComplete>" + "</t:Task>" + "</t:SetItemField>";
		} else {
			_setPercentComplete = "";
		}

		params.put(UPDATE_FIELD_PERCENT_COMPLETE, _setPercentComplete);
	}

	/**
	 * Updates the <b>Status</b> of the Task.
	 * 
	 * @param _Status
	 */
	public void setStatus(String _Status) {
		if (_Status != null) {
			_Status = "<t:SetItemField>" + "<t:FieldURI FieldURI=\"task:Status\"/>" + "<t:Task>" + "<t:Status>" + _Status + "</t:Status>" + "</t:Task>" + "</t:SetItemField>";
		} else {
			_Status = "";
		}
		params.put(UPDATE_FIELD_STATUS, _Status);

	}

	/**
	 * Sets the ChangeKey for Update Operation.
	 * 
	 * @param _val
	 */
	public void setChangeKey(String _val) {
		this.changeKey = _val;
		if (_val != null) {
			params.put(UPDATE_FIELD_CHANGE_KEY, _val);
		}
	}

	/**
	 * Provides the <b>ChangeKey</b> of an Item.
	 * 
	 * @return ChangeKey
	 */
	public String getChangeKey() {
		return this.changeKey;
	}

	/**
	 * Provides the <b>ID</b> of an Item.
	 * 
	 * @return Id
	 */
	public String getId() {
		return this.id;
	}

	/**
	 * This returns back the SOAP-Action
	 * 
	 * @return String(SOAP-Action url)
	 */
	@Override
	public String getSoapAction() {
		return "http://schemas.microsoft.com/exchange/services/2006/messages/UpdateItem";
	}

	@Override
	public String getSoapPacket() throws IOException {
		return getSoapTemplate("/net/aw20/msexchange/soap/templates/UpdateTaskItem.soap", params);
	}

	/**
	 * Upon a successful 200 status code; this represents the server response raw XML packet
	 * 
	 * @param xmlResponse
	 * @return parsed xmlResponse to List object
	 * @throws MSExchangeException
	 */
	@Override
	public List<Map<String, Object>> onResponse(String xmlResponse) throws MSExchangeException {
		List<Map<String, Object>> tasks = new ArrayList<Map<String, Object>>();
		tasks = processRequest(xmlResponse, ROOT_ELEMENT);
		if (tasks.isEmpty()) {
			tasks = processError(xmlResponse);
		}
		return tasks;
	}
}
/* 
 *  Copyright (C) 2000 - 2011 aw2.0 Ltd
 *
 *  This file is part of Open BlueDragon (OpenBD) CFML Server Engine.
 *  
 *  OpenBD is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  Free Software Foundation,version 3.
 *  
 *  OpenBD is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  
 *  You should have received a copy of the GNU General Public License
 *  along with OpenBD.  If not, see http://www.gnu.org/licenses/
 *  
 *  Additional permission under GNU GPL version 3 section 7
 *  
 *  If you modify this Program, or any covered work, by linking or combining 
 *  it with any of the JARS listed in the README.txt (or a modified version of 
 *  (that library), containing parts covered by the terms of that JAR, the 
 *  licensors of this Program grant you additional permission to convey the 
 *  resulting work. 
 *  README.txt @ http://www.openbluedragon.org/license/README.txt
 *  
 *  http://www.openbluedragon.org/
 */

package net.aw20.msexchange;

import org.apache.http.auth.Credentials;
import org.apache.http.auth.NTCredentials;

public class MSExchangeConnector extends Object {

	private String hostUrl = null, host = null;

	private String username = null, password = null, domain = null;

	/**
	 * Creates MSExchangeConnector object for the user credentials and host url
	 * 
	 * @param _hostUrl
	 * @param _username
	 * @param _password
	 */
	public MSExchangeConnector(String _hostUrl, String _username, String _password) {
		this(_hostUrl, _username, _password, "");
	}

	/**
	 * Creates MSExchangeConnector object for the user credentials, domain and host url
	 * 
	 * @param _hostUrl
	 * @param _username
	 * @param _password
	 * @param _domain
	 */
	public MSExchangeConnector(String _hostUrl, String _username, String _password, String _domain) {
		this.hostUrl = _hostUrl;
		this.username = _username;
		this.password = _password;
		this.domain = _domain;

		int c1 = this.hostUrl.indexOf("://") + 3;
		int c2 = this.hostUrl.indexOf("/", c1 + 1);
		this.host = this.hostUrl.substring(c1, c2);
	}

	/**
	 * This returns the NTLM Credentials that will be used to make the request
	 * 
	 * @return NTLM credentials for the user
	 */
	public Credentials getCredentials() {
		return new NTCredentials(username, password, host, domain);
	}

	/**
	 * Gets the full end point for which this host will talk to
	 * 
	 * @return
	 */
	public String getHostUrl() {
		return hostUrl;
	}
}

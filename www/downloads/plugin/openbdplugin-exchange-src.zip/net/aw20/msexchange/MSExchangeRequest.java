/* 
 *  Copyright (C) 2000 - 2011 aw2.0 Ltd
 *
 *  This file is part of Open BlueDragon (OpenBD) CFML Server Engine.
 *  
 *  OpenBD is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  Free Software Foundation,version 3.
 *  
 *  OpenBD is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  
 *  You should have received a copy of the GNU General Public License
 *  along with OpenBD.  If not, see http://www.gnu.org/licenses/
 *  
 *  Additional permission under GNU GPL version 3 section 7
 *  
 *  If you modify this Program, or any covered work, by linking or combining 
 *  it with any of the JARS listed in the README.txt (or a modified version of 
 *  (that library), containing parts covered by the terms of that JAR, the 
 *  licensors of this Program grant you additional permission to convey the 
 *  resulting work. 
 *  README.txt @ http://www.openbluedragon.org/license/README.txt
 *  
 *  http://www.openbluedragon.org/
 */

package net.aw20.msexchange;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.ParserConfigurationException;

import net.aw20.msexchange.ntlm.NTLMSchemeFactory;
import net.aw20.msexchange.soap.SOAPRequestInterface;

import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.auth.AuthScope;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.xml.sax.SAXException;

public class MSExchangeRequest extends Object {

	private SOAPRequestInterface soapIn;

	public MSExchangeRequest(SOAPRequestInterface soapIn) {
		this.soapIn = soapIn;
	}

	/**
	 * This method is called when we are ready to make the call to the Exchange server. It connects to the Exchange EWS interface and transmits the SOAP request and returns the processed request
	 * 
	 * @param connector
	 * @return processed request
	 * @throws MSExchangeException
	 */
	public List<Map<String, Object>> call(MSExchangeConnector connector) throws MSExchangeException {

		HttpPost post = null;

		try {
			post = new HttpPost(connector.getHostUrl());

			// Create StringEntity to contain the SOAP request
			StringEntity sentity = new StringEntity(soapIn.getSoapPacket(), "UTF-8");
			sentity.setContentType("text/xml");
			sentity.setChunked(true);

			post.setEntity(sentity);

			post.setHeader("SOAPAction", soapIn.getSoapAction());

			// Get HTTP client
			DefaultHttpClient httpclient = new DefaultHttpClient();

			// Setting to use NTLM Authentication
			httpclient.getAuthSchemes().register("NTLM", new NTLMSchemeFactory());

			// Setup the authentication credentials
			httpclient.getCredentialsProvider().setCredentials(AuthScope.ANY, connector.getCredentials());

			// get HttpResponse object
			HttpResponse response = httpclient.execute(post);
			int responsecode = response.getStatusLine().getStatusCode();
			String reasonPhrase = response.getStatusLine().getReasonPhrase();

			HttpEntity entity = response.getEntity();
			if (entity != null) {

				// By consuming the content of the response, we will release the connection
				String responseContent = getResponseContent(entity);

				if (responsecode == 200) {
					return soapIn.onResponse(responseContent);
				} else {
					throw new MSExchangeException("StatusCode=" + responsecode + ", Message=" + reasonPhrase);
				}
			} else {
				throw new MSExchangeException("Response Entity is null. StatusCode=" + responsecode + ", Message=" + reasonPhrase);
			}

		} catch (UnsupportedEncodingException e) {
			throw new MSExchangeException(e);
		} catch (IOException e) {
			throw new MSExchangeException(e);
		} catch (ParserConfigurationException e) {
			throw new MSExchangeException(e);
		} catch (SAXException e) {
			throw new MSExchangeException(e);
		} finally {
			// Abort HttpPost
			if (post != null)
				post.abort();
		}
	}

	/**
	 * This method is called to retrieve the response content from http entity
	 * 
	 * @param _entity
	 * @return String (Full list of returned SOAP-XML packet)
	 * @throws IOException
	 * @throws NullPointerException
	 */
	private String getResponseContent(HttpEntity _entity) throws IOException {

		Header headerContentType = _entity.getContentType();
		if (headerContentType == null) {
			throw new NullPointerException("Response from the server is Null. Please try with different options.");
		}
		String contentTypeStr = headerContentType.getValue();

		// defaulting to UTF-8
		String contentType = "UTF-8";

		// parse out charset=utf-8
		int index = contentTypeStr.toLowerCase().indexOf("charset");
		if (index != -1) {
			// contentType contains charset=xxxx
			// get the trailing charset by removing charset=
			contentType = contentTypeStr.substring(index + 8).toUpperCase();
		}

		// Stream content out
		InputStream in = _entity.getContent();
		BufferedReader reader = null;
		InputStreamReader inreader = null;
		StringBuilder sb = new StringBuilder();

		try {
			inreader = new InputStreamReader(in, contentType);

			reader = new BufferedReader(inreader);

			char[] chars = new char[2048];

			int read;
			while ((read = reader.read(chars, 0, chars.length)) != -1) {
				sb.append(chars, 0, read);
			}

		} finally {
			if (reader != null) {
				try {
					reader.close();
				} catch (IOException ignored) {
				}
			}

			if (inreader != null) {
				try {
					inreader.close();
				} catch (IOException ignored) {
				}
			}
			if (in != null) {
				try {
					in.close();
				} catch (IOException ignored) {
				}
			}
		}

		return sb.toString();
	}

}
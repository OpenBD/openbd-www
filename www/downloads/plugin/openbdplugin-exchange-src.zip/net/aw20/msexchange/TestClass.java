/* 
 *  Copyright (C) 2000 - 2011 aw2.0 Ltd
 *
 *  This file is part of Open BlueDragon (OpenBD) CFML Server Engine.
 *  
 *  OpenBD is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  Free Software Foundation,version 3.
 *  
 *  OpenBD is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  
 *  You should have received a copy of the GNU General Public License
 *  along with OpenBD.  If not, see http://www.gnu.org/licenses/
 *  
 *  Additional permission under GNU GPL version 3 section 7
 *  
 *  If you modify this Program, or any covered work, by linking or combining 
 *  it with any of the JARS listed in the README.txt (or a modified version of 
 *  (that library), containing parts covered by the terms of that JAR, the 
 *  licensors of this Program grant you additional permission to convey the 
 *  resulting work. 
 *  README.txt @ http://www.openbluedragon.org/license/README.txt
 *  
 *  http://www.openbluedragon.org/
 */

package net.aw20.msexchange;

import java.util.List;
import java.util.Map;

import net.aw20.msexchange.soap.task.CreateTask;
import net.aw20.msexchange.soap.task.FindAllTasks;

public class TestClass {

	public static void main(String[] args) throws Exception {// bluedragon.bd.com
		// System.setProperty("javax.net.ssl.trustStore", "C:\\Dev\\Workspaces\\BlueDragon\\bin\\jssecacerts");
		MSExchangeConnector conShravan = new MSExchangeConnector("https://58.68.119.45/EWS/exchange.asmx", "shravan.t", "Pass*2010", "bd");
		// FindAllContacts allContacts = new FindAllContacts();

		// String id = "AAMkADNjOTQ1YWQxLThmNGMtNDE4Yy04NmQ4LWQyZDEwYzdjYzMxNwBGAAAAAABJs2SOPLi6S6PCqbi62houBwCZIxxLqvnYTIqv4aMyBgBPAAAAAAAiAACZIxxLqvnYTIqv4aMyBgBPAAABYMtTAAA=";
		// CreateCalendarItem cal = new CreateCalendarItem("New Task by Shravan", "2010-12-07T13:30:00", "2010-12-07T14:30:00");

		// GetContact getContact = new GetContact(id);

		// GetContact contact = new GetContact( id );
		/*
		 * UpdateContact contact = new UpdateContact(); contact.setJobTitle("Proect Manager"); contact.setAssistantName("Some Assistant Name"); contact.setBusinessHomePage("www.tshravan.co.cc"); contact.setBusinessPhone1("02038524358"); contact.setBusinessPhone2("08702437631"); contact.setDisplayName("Shravan"); contact.setGivenName("Shravan"); contact.setSurName("Thummalapelly");
		 * contact.setMiddleName("Kumar"); contact.setMobilePhone("9763314993"); contact.setBusinessFax("02015859635"); contact.setHomePhone1("08702437631"); contact.setHomePhone2("7709525965"); contact.setHomePhoneFax("08701234567"); contact.setAssistantPhone("9886472269"); contact.setEmailAndDisplayName("me@tshravan.co.cc","" ); contact.setEmailAndDisplayName2("email2@snstech.com", "");
		 * contact.setEmailAndDisplayName3("email3@snstech.com", ""); contact.setDepartment("Development Department"); contact.setBusinessStreet("Koregaon Park"); contact.setBusinessCity("Pune"); contact.setBusinessState("Maharashtra"); contact.setBusinessCountry("India"); contact.setBusinessPostalCode("411001"); contact.setHomeStreet("Koregaon Park"); contact.setHomeCity("Pune");
		 * contact.setHomeState("Maharashtra"); contact.setHomeCountry("India"); contact.setHomePostalCode("411001"); contact.setOtherStreet("Koregaon Park"); contact.setOtherCity("Pune"); contact.setOtherState("Maharashtra"); contact.setOtherCountry("India"); contact.setOtherPostalCode("411001"); contact.setCallback("123"); contact.setCarPhone("456"); contact.setOtherTelephone("778");
		 * contact.setPager("1445"); contact.setPrimaryPhone("159"); contact.setCompany("My Own Company"); contact.setCompanyMainPhone("1455"); contact.setIsdn("0448"); contact.setRadioPhone("1258"); contact.setTelex("456"); contact.setTtyTddPhone("158"); contact.setImAddress("urshravankumar"); contact.setImAddress2("baskumar_tt"); contact.setImAddress3("me"); contact.setManager("Pankaj Batra");
		 * contact.setOfficeLocation("Pune, Maharashtra"); contact.setNotes("This is NOOOOOOOOOOOOOOOOOOOOTEEEEEEEEEEEEEESSSSSSSSSSSSSSSSSSSSSSS");
		 */

		// FindFolder folder = new FindFolder("AllProperties", "tasks");

		// MSExchangeRequest req = new MSExchangeRequest( getContact );
		CreateTask task = new CreateTask();
		task.setSubject("Is this new taskssssssssssssss && TTTTTTTTTT?");
		task.setBody(null, null);
		task.setTaskDueDate(null);
		task.setImportance(null);
		task.setPercentComplete(null);
		task.setReminderDueBy(null);
		task.setReminderIsSet(null);
		task.setReminderMinutesBeforeStart(null);
		task.setTaskStartDate(null);
		task.setStatus(null);

		FindAllTasks allTasks = new FindAllTasks();
		// GetTask getTask = new GetTask("AAMkADNjOTQ1YWQxLThmNGMtNDE4Yy04NmQ4LWQyZDEwYzdjYzMxNwBGAAAAAABJs2SOPLi6S6PCqbi62houBwCZIxxLqvnYTIqv4aMyBgBPAAAAAAAiAACZIxxLqvnYTIqv4aMyBgBPAAABYMtpAAA=");

		MSExchangeRequest req = new MSExchangeRequest(allTasks);

		// req.call( conAlan );
		//
		// req.call now returns an ArrayList<HashMap<String, ArrayList<HashMap....
		@SuppressWarnings("unused")
		List<Map<String, Object>> contacts = (List<Map<String, Object>>) req.call(conShravan);
		/*
		 * if(contacts.size() > 0){ HashMap h = contacts.get(0); ArrayList a = (ArrayList)h.get("contact");
		 * 
		 * HashMap m = (HashMap)a.get(0); HashMap attributes = (HashMap)m.get("attributes"); Iterator<String> i = attributes.keySet().iterator();
		 * 
		 * 
		 * while(i.hasNext()){ String key = i.next(); Object o = attributes.get(key);
		 * 
		 * //newmap.put( key, new cfStringData( o.toString() ) ); } }
		 */
		// ExchangeGetContact e = new ExchangeGetContact();

		// ExchangeCreateCalendarItem e = new ExchangeCreateCalendarItem();

		// HashMap h = contacts.get( 0 );

		// boolean d = e.getBoolean();
		// cfStructData d = e.createContact( h );
	}
}

/* 
 *  Copyright (C) 2000 - 2011 aw2.0 Ltd
 *
 *  This file is part of Open BlueDragon (OpenBD) CFML Server Engine.
 *  
 *  OpenBD is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  Free Software Foundation,version 3.
 *  
 *  OpenBD is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  
 *  You should have received a copy of the GNU General Public License
 *  along with OpenBD.  If not, see http://www.gnu.org/licenses/
 *  
 *  Additional permission under GNU GPL version 3 section 7
 *  
 *  If you modify this Program, or any covered work, by linking or combining 
 *  it with any of the JARS listed in the README.txt (or a modified version of 
 *  (that library), containing parts covered by the terms of that JAR, the 
 *  licensors of this Program grant you additional permission to convey the 
 *  resulting work. 
 *  README.txt @ http://www.openbluedragon.org/license/README.txt
 *  
 *  http://www.openbluedragon.org/
 */

package net.aw20.openbd.plugins.exchange.helpers;

import java.text.DateFormatSymbols;
import java.util.HashMap;
import java.util.Map;

import com.naryx.tagfusion.cfm.engine.cfStructData;

public class ExchangeRecurrenceUtility {

	private static final String DAY_VALUES = "Sunday, Monday, Tuesday, Wednesday, Thursday, Friday, Saturday";

	private static final String MONTH_VALUES = "January, February, March, April, May, June, July, August, September, October, November, December";

	private static final String DAYOFWEEK_INDEX_VALUES = "First, Second, Third, Fourth, Last";

	private static final String REPEAT_PATTERN_VALUES = "Daily, Weekly, Monthly, Yearly ";

	private static final Map<String, Integer> weeks = new HashMap<String, Integer>();

	private static final Map<String, Integer> days = new HashMap<String, Integer>();

	private static final Map<String, Integer> months = new HashMap<String, Integer>();

	private static final Map<String, Integer> repeatPattern = new HashMap<String, Integer>();

	static {
		weeks.put("First", 1);
		weeks.put("Second", 2);
		weeks.put("Third", 3);
		weeks.put("Fourth", 4);
		weeks.put("Last", 5);

		DateFormatSymbols dfs = new DateFormatSymbols();
		// fill months map with Month name and Month number values
		String[] monthNames = dfs.getMonths();
		int count = 1;
		for (String month : monthNames) {
			months.put(month, count++);
		}

		// fill days map with day name and day number values
		String[] dayNames = dfs.getWeekdays();
		count = 0;
		for (String day : dayNames) {
			days.put(day, count++);
		}

		repeatPattern.put("daily", 1);
		repeatPattern.put("weekly", 2);
		repeatPattern.put("monthly", 3);
		repeatPattern.put("yearly", 4);
	}

	/**
	 * Validates the <b>Repeat Pattern</b> and accordingly checks the parameters of the respective <b>Recurrence/Regeneration</b> type. In case of <b>Task</b> Item the <b>regeneration</b> field of the input is checked and if it is <b>TRUE</b> the <b>"Regeneration"</b> keyword is appended to the repeat Pattern.Throws IllegalArgumentException when the Repeat Pattern or its input is not valid.
	 * 
	 * @param recurrenceObj
	 * @param itemType
	 * @return space separated String(i.e. combination of regeneration, daily, weekly, monthly,yearly recurrence and the duration format for recurrence) which will give an appropriate Recurrence to be implemented.
	 */
	public static String parseRecurrenceInput(cfStructData recurrenceObj, String itemType) {
		String _pattern;
		Boolean _regenerationValue = null;
		_pattern = parseRepeatPattern((String) recurrenceObj.get("RepeatPattern"), itemType);

		// Checks for the regeneration field(Boolean) value of the recurrenceObj(Input).If it is "true" then the keyword "Regeneration" is appended to the Repeat pattern.
		if (ExchangeUtility.parseBoolean(recurrenceObj.get("regeneration"), "regeneration") != null && "task".equals(itemType)) {
			_regenerationValue = (Boolean) recurrenceObj.get("regeneration");
			if (_regenerationValue) {
				_pattern = _pattern + "Regeneration";
			}
		}
		String recurrenceType = "";
		if ("Daily".equalsIgnoreCase(_pattern)) {
			parseRecurrenceInterval(recurrenceObj, _regenerationValue);
			recurrenceType = "Daily";
		} else if ("Weekly".equalsIgnoreCase(_pattern)) {
			parseRecurrenceInterval(recurrenceObj, _regenerationValue);
			parseDaysOfWeek((String) recurrenceObj.get("DaysOfWeek"));
			// parseDay((String)recurrenceObj.get("FirstDayOfWeek"));
			recurrenceType = "Weekly";
		} else if ("Monthly".equalsIgnoreCase(_pattern)) {
			parseRecurrenceInterval(recurrenceObj, _regenerationValue);
			if ((((Integer) recurrenceObj.get("DayOfMonth")) != null)) {
				parseDayOfMonth(recurrenceObj);
				recurrenceType = "AbsoluteMonthlyRecurrence";
			} else if (((String) recurrenceObj.get("DaysOfWeek") != null) & ((String) recurrenceObj.get("DayOfWeekIndex") != null)) {
				parseDay((String) recurrenceObj.get("DaysOfWeek"));
				parseDayOfWeekIndex((String) recurrenceObj.get("DayOfWeekIndex"));
				recurrenceType = "RelativeMonthlyRecurrence";
			} else {
				throw new IllegalArgumentException("Invalid Input for MonthlyRecurrence");
			}
		} else if ("Yearly".equalsIgnoreCase(_pattern)) {
			parseMonth((String) recurrenceObj.get("Month"));
			if ((Integer) recurrenceObj.get("DayOfMonth") != null) {
				parseDayOfMonth(recurrenceObj);
				recurrenceType = "AbsoluteYearlyRecurrence";
			} else if (((String) recurrenceObj.get("DaysOfWeek") != null) & ((String) recurrenceObj.get("DayOfWeekIndex") != null)) {
				parseDay((String) recurrenceObj.get("DaysOfWeek"));
				parseDayOfWeekIndex((String) recurrenceObj.get("DayOfWeekIndex"));
				recurrenceType = "RelativeYearlyRecurrence";
			} else {
				throw new IllegalArgumentException("Invalid Input for YearlyRecurrence");
			}
		} else if ("task".equals(itemType)) {
			if ("DailyRegeneration".equalsIgnoreCase(_pattern)) {
				parseRecurrenceInterval(recurrenceObj, _regenerationValue);
				recurrenceType = "DailyRegeneration";
			} else if ("WeeklyRegeneration".equalsIgnoreCase(_pattern)) {
				parseRecurrenceInterval(recurrenceObj, _regenerationValue);
				recurrenceType = "WeeklyRegeneration";
			} else if ("MonthlyRegeneration".equalsIgnoreCase(_pattern)) {
				parseRecurrenceInterval(recurrenceObj, _regenerationValue);
				recurrenceType = "MonthlyRegeneration";
			} else if ("YearlyRegeneration".equalsIgnoreCase(_pattern)) {
				parseRecurrenceInterval(recurrenceObj, _regenerationValue);
				recurrenceType = "YearlyRegeneration";
			}
		}

		if ("".equals(recurrenceType)) {
			throw new IllegalArgumentException("Invalid Input for Recurrence");
		}
		recurrenceType = recurrenceType + " " + parseRecurrenceDuration(recurrenceObj);
		return recurrenceType;
	}

	/***
	 * Validates the <b>repeatpattern</b> value. If input is not one of these values: <b>"daily, weekly, monthly, yearly"</b> throws IllegalArgumentException.
	 * 
	 * @param _pattern
	 * @param itemType
	 * @return repeatpattern value after validation.
	 */
	public static String parseRepeatPattern(String _pattern, String itemType) {
		if (_pattern == null) {
			throw new IllegalArgumentException("RepeatPattern value is required.");
		}
		Integer index = repeatPattern.get(_pattern.toLowerCase());
		if (index == null) {
			throw new IllegalArgumentException("RepeatPattern value should be one of these: " + REPEAT_PATTERN_VALUES);
		} else {
			return _pattern;
		}
	}

	/**
	 * Validates the <b>DayOfWeekIndex</b> value. If input is not one of these values (case sensitive): <b>"First, Second, Third, Fourth, Last"</b> throws IllegalArgumentException.
	 * 
	 * @param _index
	 */
	public static void parseDayOfWeekIndex(String _index) {
		Integer index = weeks.get(_index);
		if (index == null) {
			throw new IllegalArgumentException("DayOfWeekIndex value should be one of these (case sensitive): " + DAYOFWEEK_INDEX_VALUES);
		}
	}

	/**
	 * Validates the <b>Day</b> value. If input is not one of these values (case sensitive): <b>"Sunday, Monday, Tuesday, Wednesday, Thursday, Friday, Saturday"</b> throws IllegalArgumentException.
	 * 
	 * @param _day
	 */
	public static void parseDay(String _day) {
		Integer index = days.get(_day);
		if (index == null) {
			throw new IllegalArgumentException("Day value should be one of these (case sensitive): " + DAY_VALUES);
		}
	}

	/**
	 * Validates the <b>Month</b> value. If input is not one of these values (case sensitive): <b>"January, February, March, April, May, June, July, August, September, October, November, December"</b> throws IllegalArgumentException.
	 * 
	 * @param _month
	 */
	public static void parseMonth(String _month) {
		Integer index = months.get(_month);
		if (index == null) {
			throw new IllegalArgumentException("Month value is required and should be one of these (case sensitive): " + MONTH_VALUES);
		}
	}

	/**
	 * Validates the <b>DaysOfWeek</b> value for <b>weekly recurrence</b>. A weekly recurrence pattern can contain multiple Days values. Values are separated by a space character.
	 * 
	 * @param _daysOfWeek
	 */
	public static void parseDaysOfWeek(String _daysOfWeek) {
		if (_daysOfWeek == null) {
			throw new IllegalArgumentException("DaysOfWeek value can not be null.Please specify space seprated day values.Day value should be one of these (case sensitive): " + DAY_VALUES);
		} else {
			if ("".equals(_daysOfWeek))
				throw new IllegalArgumentException("DaysOfWeek value can not be blank.Please specify space seprated day values.Day value should be one of these (case sensitive): " + DAY_VALUES);
			else {
				// Validates the space separated String of days.
				String days[] = _daysOfWeek.split(" ");
				for (int counter = 0; counter < days.length; counter++) {
					parseDay(days[counter]);
				}
			}
		}
	}

	/**
	 * Validates the <b>DayOfMonth</b> value.DayOfMonth should be valid integer in the range 1 to 31 both inclusive.
	 * 
	 * @param recurrenceObj
	 */
	public static void parseDayOfMonth(cfStructData recurrenceObj) {
		Integer i;
		if (recurrenceObj.get("DayOfMonth") == null) {
			throw new IllegalArgumentException("DayOfMonth is required and should be valid integer in the range 1 to 31.");
		}
		i = Integer.parseInt(recurrenceObj.get("DayOfMonth").toString().trim());
		if (i > 31) {
			throw new IllegalArgumentException("DayOfMonth is required and should be valid integer in the range 1 to 31.");
		}
	}

	/**
	 * Validates the <b>RecurrenceInterval</b> value. For <b>DailyRecurrence and DailyRegeneration</b>, the RecurrenceInterval should be in the range 1 to 999. For <b>MonthlyRecurrence and WeeklyRecurrence</b>,the RecurrenceInterval should be in the range 1 to 99.
	 * 
	 * @param recurrenceObj
	 * @param regenerationValue
	 */
	public static void parseRecurrenceInterval(cfStructData recurrenceObj, Boolean regenerationValue) {
		Integer i;
		if (recurrenceObj.get("Interval") != null) {
			i = Integer.parseInt(recurrenceObj.get("Interval").toString().trim());
			if ("Daily".equalsIgnoreCase(((String) recurrenceObj.get("RepeatPattern")))) {
				if (i > 999) {
					throw new IllegalArgumentException("Recurrence Interval should be valid integer in the range 1 to 999.");
				}
			} else if ("Monthly".equalsIgnoreCase(((String) recurrenceObj.get("RepeatPattern"))) || ("Weekly".equalsIgnoreCase((String) recurrenceObj.get("RepeatPattern")))) {

				// If the regenerationValue is null or false then it is Recurrence and not Regeneration and hence the Interval needs to be validated Otherwise it need not be validated for Regeneration.
				if ((regenerationValue) == null || "false".equals(regenerationValue)) {
					if (i > 99) {
						throw new IllegalArgumentException("Recurrence Interval should be valid integer in the range 1 to 99.");
					}
				}
			}
		}
	}

	/**
	 * Based on the Input provided selects one of these : <b>"NoEndRecurrence, EndDateRecurrence, NumberedRecurrence"</b>. Only StartDate in the input, it's NoEndRecurrence.If there is an EndDate along with StartDate, it's EndDateRecurrence. If there is NumberOfOccurrences along with StartDate, it's NumberedRecurrence. The StartDate is required for all the Recurrence patterns mentioned above.
	 * 
	 * @param recurrenceObj
	 * @return One of these strings "NoEndRecurrence", "EndDateRecurrence", "NumberedRecurrence"
	 */
	public static String parseRecurrenceDuration(cfStructData recurrenceObj) {
		String format = null;
		// StartDate is required for all recurrence.
		if (recurrenceObj.get("StartDate") == null) {
			throw new IllegalArgumentException("Recurrence StartDate is required and should be valid value.");
		}
		if (recurrenceObj.get("EndDate") != null) {
			format = "EndDateRecurrence";
		} else if (recurrenceObj.get("NumberOfOccurrences") != null) {
			if (Integer.parseInt(recurrenceObj.get("NumberOfOccurrences").toString().trim()) > 999) {
				throw new IllegalArgumentException("Recurrence Interval should be valid Integer in the range 1 to 999.");
			} else {
				format = "NumberedRecurrence";
			}
		} else {
			format = "NoEndDateRecurrence";
		}
		return format;
	}

}

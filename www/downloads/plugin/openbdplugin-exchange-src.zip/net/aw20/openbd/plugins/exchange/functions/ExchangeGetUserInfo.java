/* 
 *  Copyright (C) 2000 - 2011 aw2.0 Ltd
 *
 *  This file is part of Open BlueDragon (OpenBD) CFML Server Engine.
 *  
 *  OpenBD is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  Free Software Foundation,version 3.
 *  
 *  OpenBD is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  
 *  You should have received a copy of the GNU General Public License
 *  along with OpenBD.  If not, see http://www.gnu.org/licenses/
 *  
 *  Additional permission under GNU GPL version 3 section 7
 *  
 *  If you modify this Program, or any covered work, by linking or combining 
 *  it with any of the JARS listed in the README.txt (or a modified version of 
 *  (that library), containing parts covered by the terms of that JAR, the 
 *  licensors of this Program grant you additional permission to convey the 
 *  resulting work. 
 *  README.txt @ http://www.openbluedragon.org/license/README.txt
 *  
 *  http://www.openbluedragon.org/
 */

package net.aw20.openbd.plugins.exchange.functions;

import java.util.List;
import java.util.Map;

import net.aw20.msexchange.MSExchangeConnector;
import net.aw20.msexchange.MSExchangeException;
import net.aw20.msexchange.MSExchangeRequest;
import net.aw20.msexchange.soap.items.GetUserInfo;
import net.aw20.openbd.plugins.exchange.helpers.ExchangeConnectionFactory;
import net.aw20.openbd.plugins.exchange.helpers.ExchangeItemUtility;
import net.aw20.openbd.plugins.exchange.helpers.ExchangeUtility;

import com.naryx.tagfusion.cfm.engine.cfArgStructData;
import com.naryx.tagfusion.cfm.engine.cfData;
import com.naryx.tagfusion.cfm.engine.cfSession;
import com.naryx.tagfusion.cfm.engine.cfStructData;
import com.naryx.tagfusion.cfm.engine.cfmRunTimeException;
import com.naryx.tagfusion.expression.function.functionBase;

public class ExchangeGetUserInfo extends functionBase {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ExchangeGetUserInfo() {
		min = max = 2;
		setNamedParams(new String[] { "connection", "username" });
	}

	/**
	 * This method gives openbd plug-in parameter information to CFM
	 * 
	 * @return String[] (Description about all parameters)
	 */
	public String[] getParamInfo() {
		return new String[] { "connection - Provide proper connection object to communate with Exchange server", "username - Provide valid username as input to get information" };
	}

	/**
	 * This method gives openbd plug-in functionality information to CFM
	 * 
	 * @return Map (Containing CFM output)
	 */
	@SuppressWarnings("unchecked")
	public java.util.Map getInfo() {
		return makeInfo("ms-exchange", "Gets the user information.", ReturnType.STRUCTURE);
	}

	/**
	 * Makes request to the Exchange Server, receives the parsed SOAP response and accordingly display it in the CFML Output.
	 * 
	 * @param _session
	 * @param argStruct
	 * @return cfData containing either the user information or the Error Message Text
	 * @throws cfmRunTimeException
	 */
	public cfData execute(cfSession _session, cfArgStructData argStruct) throws cfmRunTimeException {

		String connection = getNamedStringParam(argStruct, "connection", "");
		MSExchangeConnector conn = ExchangeConnectionFactory.getConnection(connection);
		cfData userInfoStruct = null;
		String username = getNamedStringParam(argStruct, "username", null);

		if (username == null) {
			throw new IllegalArgumentException("username is required.");
		}

		if (conn != null) {
			try {

				GetUserInfo userInfo = new GetUserInfo(username);
				MSExchangeRequest req = new MSExchangeRequest(userInfo);
				List<Map<String, Object>> tasks = (List<Map<String, Object>>) req.call(conn);
				Map<String, Object> o = tasks.get(0);
				if (tasks.size() == 1 && o.get("messagetext") == null) {
					userInfoStruct = ExchangeItemUtility.fillUserInformation(o);
				} else {
					cfData errorMessage = new cfStructData();

					// getErrorMessage() handles the Error response from the server and retrieves the Error Message text
					errorMessage = ExchangeUtility.getErrorMessage(tasks);
					return errorMessage;
				}

			} catch (MSExchangeException exception) {
				throw new cfmRunTimeException(_session, exception);
			}
		}

		return userInfoStruct;
	}

}

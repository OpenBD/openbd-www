/* 
 *  Copyright (C) 2000 - 2011 aw2.0 Ltd
 *
 *  This file is part of Open BlueDragon (OpenBD) CFML Server Engine.
 *  
 *  OpenBD is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  Free Software Foundation,version 3.
 *  
 *  OpenBD is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  
 *  You should have received a copy of the GNU General Public License
 *  along with OpenBD.  If not, see http://www.gnu.org/licenses/
 *  
 *  Additional permission under GNU GPL version 3 section 7
 *  
 *  If you modify this Program, or any covered work, by linking or combining 
 *  it with any of the JARS listed in the README.txt (or a modified version of 
 *  (that library), containing parts covered by the terms of that JAR, the 
 *  licensors of this Program grant you additional permission to convey the 
 *  resulting work. 
 *  README.txt @ http://www.openbluedragon.org/license/README.txt
 *  
 *  http://www.openbluedragon.org/
 */

package net.aw20.openbd.plugins.exchange.functions;

import java.util.List;
import java.util.Map;

import net.aw20.msexchange.MSExchangeConnector;
import net.aw20.msexchange.MSExchangeException;
import net.aw20.msexchange.MSExchangeRequest;
import net.aw20.msexchange.soap.SOAPActionBase;
import net.aw20.msexchange.soap.folders.FindFolder;
import net.aw20.openbd.plugins.exchange.helpers.ExchangeConnectionFactory;
import net.aw20.openbd.plugins.exchange.helpers.ExchangeItemUtility;

import com.naryx.tagfusion.cfm.engine.cfArgStructData;
import com.naryx.tagfusion.cfm.engine.cfArrayData;
import com.naryx.tagfusion.cfm.engine.cfData;
import com.naryx.tagfusion.cfm.engine.cfSession;
import com.naryx.tagfusion.cfm.engine.cfStringData;
import com.naryx.tagfusion.cfm.engine.cfStructData;
import com.naryx.tagfusion.cfm.engine.cfmRunTimeException;
import com.naryx.tagfusion.cfm.engine.dataNotSupportedException;

public class ExchangeFindFolders extends ExchangeGetContact {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ExchangeFindFolders() {
		min = max = 2;

		setNamedParams(new String[] { "connection", "parentfolder" });
	}

	/**
	 * This method gives openbd plug-in parameter information to CFM
	 * 
	 * @return String[] (Description about all parameters)
	 */
	public String[] getParamInfo() {
		return new String[] { "connection - Provide proper connection object to communate with Exchange server", "parentfolder - Provide parent folder name of which all folder tobe retrieved" };
	}

	/**
	 * This method gives openbd plug-in functionality information to CFM
	 * 
	 * @return Map (Containing CFM output)
	 */
	@SuppressWarnings("unchecked")
	public java.util.Map getInfo() {
		return makeInfo("ms-exchange", "Retrieves list of folders", ReturnType.ARRAY);
	}

	/**
	 * Makes request to the Exchange Server, receives the parsed SOAP response and accordingly display it in the CFML Output.
	 * 
	 * @return cfData(i.e. an Array of Id's)
	 * @throws cfmRunTimeException
	 */
	public cfData execute(cfSession _session, cfArgStructData argStruct) throws cfmRunTimeException {

		String connection = getNamedStringParam(argStruct, "connection", "");
		String parentfolder = getNamedStringParam(argStruct, "parentfolder", "");

		// check that parentfolder is valid
		parentfolder = getValidParentFolder(parentfolder);
		if (parentfolder == null) {
			throw new IllegalArgumentException("\"parentfolder\" must be one of the following: calendar, contacts, deleteditems, drafts, inbox, journal, notes, outbox, sentitems, tasks, msgfolderroot, root, junkemail, searchfolders, voicemail");
		}

		MSExchangeConnector conn = ExchangeConnectionFactory.getConnection(connection);

		cfArrayData arr = cfArrayData.createArray(1);

		if (conn != null) {

			FindFolder findFolder = new FindFolder(SOAPActionBase.BASE_SHAPE_IDS_ONLY, parentfolder);

			MSExchangeRequest req = new MSExchangeRequest(findFolder);
			try {

				List<Map<String, Object>> folders = (List<Map<String, Object>>) req.call(conn);

				for (Map<String, Object> h : folders) {
					cfStructData parsedStruct = ExchangeItemUtility.parse(h);
					cfStringData s = getFolderId(parsedStruct, FindFolder.responseTagValues.get(parentfolder).toLowerCase());
					if (s != null) {
						arr.addElement(s);
					}
				}

			} catch (MSExchangeException exception) {
				throw new cfmRunTimeException(_session, exception);
			}
		}

		return arr;
	}

	/**
	 * Parses the cfStructData provided in the input and returns an ID present in the cfStructData.
	 * 
	 * @param folderStruct
	 * @param parentFolderTag
	 * @return String(FolderId)
	 * @throws dataNotSupportedException
	 */
	private cfStringData getFolderId(cfStructData folderStruct, String parentFolderTag) throws dataNotSupportedException {

		cfArrayData a1 = (cfArrayData) folderStruct.getData(parentFolderTag);

		cfStructData s1 = (cfStructData) a1.getElement(1);

		cfStructData s2 = (cfStructData) s1.getData("attributes");

		cfStringData s = null;
		cfData id = s2.getData("id");
		if (id != null) {
			s = new cfStringData(id.getString());
		}

		return s;
	}

	/**
	 * Validates the ParentFolder provided in the input.
	 * 
	 * @param _parentFolder
	 * @return String(ParentFolder name)
	 */
	private String getValidParentFolder(String _parentFolder) {

		if (FindFolder.FOLDER_CALENDAR.equalsIgnoreCase(_parentFolder)) {

			return FindFolder.FOLDER_CALENDAR;

		} else if (FindFolder.FOLDER_CONTACTS.equalsIgnoreCase(_parentFolder)) {

			return FindFolder.FOLDER_CONTACTS;

		} else if (FindFolder.FOLDER_DRAFTS.equalsIgnoreCase(_parentFolder)) {

			return FindFolder.FOLDER_DRAFTS;

		} else if (FindFolder.FOLDER_INBOX.equalsIgnoreCase(_parentFolder)) {

			return FindFolder.FOLDER_INBOX;

		} else if (FindFolder.FOLDER_JOURNAL.equalsIgnoreCase(_parentFolder)) {

			return FindFolder.FOLDER_JOURNAL;

		} else if (FindFolder.FOLDER_JUNKEMAIL.equalsIgnoreCase(_parentFolder)) {

			return FindFolder.FOLDER_JUNKEMAIL;

		} else if (FindFolder.FOLDER_MSGFOLDERROOT.equalsIgnoreCase(_parentFolder)) {

			return FindFolder.FOLDER_MSGFOLDERROOT;

		} else if (FindFolder.FOLDER_NOTES.equalsIgnoreCase(_parentFolder)) {

			return FindFolder.FOLDER_NOTES;

		} else if (FindFolder.FOLDER_OUTBOX.equalsIgnoreCase(_parentFolder)) {

			return FindFolder.FOLDER_OUTBOX;

		} else if (FindFolder.FOLDER_ROOT.equalsIgnoreCase(_parentFolder)) {

			return FindFolder.FOLDER_ROOT;

		} else if (FindFolder.FOLDER_SEARCHFOLDERS.equalsIgnoreCase(_parentFolder)) {

			return FindFolder.FOLDER_SEARCHFOLDERS;

		} else if (FindFolder.FOLDER_SENTITEMS.equalsIgnoreCase(_parentFolder)) {

			return FindFolder.FOLDER_SENTITEMS;

		} else if (FindFolder.FOLDER_TASKS.equalsIgnoreCase(_parentFolder)) {

			return FindFolder.FOLDER_TASKS;

		} else if (FindFolder.FOLDER_VOICEMAIL.equalsIgnoreCase(_parentFolder)) {

			return FindFolder.FOLDER_VOICEMAIL;

		} else if (FindFolder.FOLDER_DELETEDITEMS.equalsIgnoreCase(_parentFolder)) {

			return FindFolder.FOLDER_DELETEDITEMS;

		}

		return null;
	}

}

/* 
 *  Copyright (C) 2000 - 2011 aw2.0 Ltd
 *
 *  This file is part of Open BlueDragon (OpenBD) CFML Server Engine.
 *  
 *  OpenBD is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  Free Software Foundation,version 3.
 *  
 *  OpenBD is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  
 *  You should have received a copy of the GNU General Public License
 *  along with OpenBD.  If not, see http://www.gnu.org/licenses/
 *  
 *  Additional permission under GNU GPL version 3 section 7
 *  
 *  If you modify this Program, or any covered work, by linking or combining 
 *  it with any of the JARS listed in the README.txt (or a modified version of 
 *  (that library), containing parts covered by the terms of that JAR, the 
 *  licensors of this Program grant you additional permission to convey the 
 *  resulting work. 
 *  README.txt @ http://www.openbluedragon.org/license/README.txt
 *  
 *  http://www.openbluedragon.org/
 */

package net.aw20.openbd.plugins.exchange.helpers;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import net.aw20.msexchange.MSExchangeException;

import com.naryx.tagfusion.cfm.engine.cfArrayData;
import com.naryx.tagfusion.cfm.engine.cfData;
import com.naryx.tagfusion.cfm.engine.cfStringData;
import com.naryx.tagfusion.cfm.engine.cfStructData;
import com.naryx.tagfusion.cfm.engine.dataNotSupportedException;

public class ExchangeUtility {

	private static final String STATUS_VALUES = "NotStarted, InProgress, Completed, WaitingOnOthers, Deferred";

	private static final String IMPORTANCE_VALUES = "Low, Normal, High";

	private static final String OPERATOR_VALUES = "And, Or";

	private static final String FREE_BUSY_STATUS_VALUES = "Free, Tentative, Busy, OOF, NoData";

	private static final String SENSITIVITY_VALUES = "Normal, Personal, Private, Confidential";

	private static final String BODYTYPE_VALUES = "HTML, Text";

	private static final String SEARCHMODE_VALUES = "FullString, Prefixed, Substring, PrefixOnWords, ExactPhrase";

	private static final String BASEPOINT_VALUES = "Beginning, End";

	private static final SimpleDateFormat sdfDateTime = new SimpleDateFormat("yyyy-MM-dd'T'hh:mm:ss");

	private static final SimpleDateFormat sdfDate = new SimpleDateFormat("yyyy-MM-dd");

	private static final Map<String, Boolean> BOOLEAN_VALUES = new HashMap<String, Boolean>();

	private static final Map<String, String> searchModeValues = new HashMap<String, String>();

	private static final Map<String, Integer> statusValues = new HashMap<String, Integer>();

	private static final Map<String, Integer> freeBusyStatusValues = new HashMap<String, Integer>();

	static {
		BOOLEAN_VALUES.put("true", true);
		BOOLEAN_VALUES.put("false", false);
		BOOLEAN_VALUES.put("yes", true);
		BOOLEAN_VALUES.put("no", false);
		statusValues.put("NotStarted", 0);
		statusValues.put("InProgress", 1);
		statusValues.put("Completed", 2);
		statusValues.put("WaitingOnOthers", 3);
		statusValues.put("Deferred", 4);
		freeBusyStatusValues.put("Free", 0);
		freeBusyStatusValues.put("Tentative", 1);
		freeBusyStatusValues.put("Busy", 2);
		freeBusyStatusValues.put("OOF", 3);
		freeBusyStatusValues.put("NoData", 4);
		searchModeValues.put("fullstring", "FullString");
		searchModeValues.put("prefixed", "Prefixed");
		searchModeValues.put("substring", "Substring");
		searchModeValues.put("prefixonwords", "PrefixOnWords");
		searchModeValues.put("exactphrase", "ExactPhrase");
	}

	/**
	 * Validating the <b>inputData</b> struct. If it is null then it throws an IllegalArgumentException
	 * 
	 * @param inputData
	 * @return cfStructData (i.e. inputData)
	 */
	public static cfStructData parseInputData(cfStructData inputData) {
		if (inputData == null) {
			throw new IllegalArgumentException("inputData should not be null / blank.");
		}

		return inputData;
	}

	/**
	 * Checks whether both <b>spanStartDate</b> and <b>spanEndDate</b> is present for <b>CalendarItem</b> and both <b>BeginStartDate</b> and <b>EndStartDate</b> is present for <b>Task</b> in the Input Data.
	 * 
	 * @param inputData
	 * @param itemType
	 */
	public static void validateSpanDates(cfStructData inputData, String itemType) {
		if ("CalendarItem".equalsIgnoreCase(itemType)) {
			if (inputData.get("spanStartDate") != null && inputData.get("spanEndDate") == null) {
				throw new IllegalArgumentException("inputData should have both spanStartDate and spanEndDate.");
			} else if (inputData.get("spanStartDate") == null && inputData.get("spanEndDate") != null) {
				throw new IllegalArgumentException("inputData should have both spanStartDate and spanEndDate.");
			}
		} else if ("Task".equalsIgnoreCase(itemType)) {
			if (inputData.get("BeginStartDate") != null && inputData.get("EndStartDate") == null) {
				throw new IllegalArgumentException("inputData should have both BeginStartDate and EndStartDate.");
			} else if (inputData.get("BeginStartDate") == null && inputData.get("EndStartDate") != null) {
				throw new IllegalArgumentException("inputData should have both BeginStartDate and EndStartDate.");
			}
		}
	}

	/**
	 * Validating the <b>Id</b> value.If it's null,throws IllegalArgumentException.
	 * 
	 * @param id
	 * @return String containing Id.
	 */
	public static String parseId(Object id) {
		if (id == null) {
			throw new IllegalArgumentException("ID is required.");
		}

		return id.toString();
	}

	/**
	 * Validates the status value. If input is not one of these values (case sensitive): <b>"NotStarted, InProgress, Completed, WaitingOnOthers, Deferred"</b> throws IllegalArgumentException.
	 * 
	 * @param _status
	 * @return String(status value)
	 */
	public static String parseStatus(String _status) {
		if (_status != null) {
			Integer position = statusValues.get(_status);
			if (position == null) {
				throw new IllegalArgumentException("Status value should be one of these (case sensitive): " + STATUS_VALUES);
			}
		}
		return _status;
	}

	/**
	 * Validates the Operator value. Returns null if input is null. If input is not one of these values (case sensitive): <b>"And, Or"</b> throws IllegalArgumentException.
	 * 
	 * @param _operator
	 * @return String(Operator value)
	 */
	public static String parseOperator(String _operator) {
		String o = null;
		if (_operator != null) {
			if ("And".equalsIgnoreCase(_operator)) {
				o = "And";
			} else if ("Or".equalsIgnoreCase(_operator)) {
				o = "Or";
			} else {
				throw new IllegalArgumentException("Operator value should be one of these: " + OPERATOR_VALUES);
			}
		}
		return o;
	}

	/**
	 * Validates the Importance value. If input is not one of these values (case sensitive): <b>"Low, Normal, High"</b> throws IllegalArgumentException.
	 * 
	 * @param _importance
	 * @return String(Importance value)
	 */
	public static String parseImportance(String _importance) {
		String i = null;
		if (_importance != null) {
			if ("Low".equalsIgnoreCase(_importance)) {
				i = "Low";
			} else if ("Normal".equalsIgnoreCase(_importance)) {
				i = "Normal";
			} else if ("High".equalsIgnoreCase(_importance)) {
				i = "High";
			} else {
				throw new IllegalArgumentException("Importance value should be one of these: " + IMPORTANCE_VALUES);
			}
		}
		return i;
	}

	/**
	 * Validates the Status value. Returns the corresponding Integer value(Position) for the Status given.
	 * 
	 * @param _status
	 * @return Integer(Value corresponding to the Status given)
	 * 
	 */

	public static Integer getStatusValue(String _status) {
		_status = parseStatus(_status);
		Integer position = statusValues.get(_status);
		return position;
	}

	/**
	 * Converts the Date Object into it's equivalent string if the input is valid Date Object, else throws IllegalArgumentException.
	 * 
	 * @param _date
	 * @param _fieldName
	 * @param isDateAndTime
	 *          (True / False values as to return date time values or only date values)
	 * @return frmDate in String format either in yyyy-MM-dd'T'hh:mm:ss or in yyyy-MM-dd based on isDateAndTime param
	 */
	public static String parseDate(Object _date, String _fieldName, boolean isDateAndTime) {
		String frmDate = null;
		// if _date is not null and instance of Date; then format according to dateTime or date
		if (_date != null && _date instanceof Date) {
			if (isDateAndTime) {
				frmDate = sdfDateTime.format((Date) _date);
			} else {
				frmDate = sdfDate.format((Date) _date);
			}
		} else if (_date != null && !(_date instanceof Date)) {
			// if date is not null and not instance of date; throw exception
			throw new IllegalArgumentException(_fieldName + " should be Date value.");
		}
		return frmDate;
	}

	/**
	 * Converts the date string into it's equivalent <b>SimpleDateFormat</b> (i.e. Date Object) if the input is valid, else throws java.text.ParseException.
	 * 
	 * @param _dateString
	 * @return Date in SimpleDateFormat
	 * @throws java.text.ParseException
	 */
	public static Date parseToDate(String _dateString) throws MSExchangeException {
		Date _date = null;
		try {
			if ((_dateString != null) && (_dateString != "")) {
				_date = sdfDateTime.parse(_dateString);
			}
		} catch (ParseException e) {
			throw new MSExchangeException(e);
		}

		return _date;
	}

	/**
	 * Validates the Boolean value. If the input Object is instance of Boolean then it's valid. If the input Object is instance of String having one of these values: <b>"true, false, yes, no"</b> then it's valid,else throws IllegalArgumentException.
	 * 
	 * @param _bool
	 * @param _fieldName
	 * @return Boolean value
	 */
	public static Boolean parseBoolean(Object _bool, String _fieldName) {
		Boolean b = null;
		// _bool can be Instance of Boolean or String.String input with specific values is valid.
		if (_bool != null) {
			if (_bool instanceof String) {
				b = BOOLEAN_VALUES.get(_bool.toString().toLowerCase());
				if (b == null) {
					throw new IllegalArgumentException(_fieldName + " should be boolean value");
				}
			} else if (_bool instanceof Boolean) {
				b = (Boolean) _bool;
			} else {
				throw new IllegalArgumentException(_fieldName + " should be boolean value");
			}
		}
		return b;
	}

	/**
	 * Validates the Integer value. If the input Object is instance of Integer then it's valid. If the input Object is instance of String representing valid Integer then it's valid, else throws IllegalArgumentException.
	 * 
	 * @param _value
	 * @param _fieldName
	 * @return Integer value.
	 */
	public static Integer parseInt(Object _value, String _fieldName) {
		Integer i = null;
		// _value can be Instance of Integer or String (i.e. String input representing valid integer.)
		if (_value != null) {
			if (_value instanceof Integer) {
				i = (Integer) _value;
			} else if (_value instanceof String) {
				try {
					i = Integer.parseInt(_value.toString());
				} catch (NumberFormatException e) {
					throw new IllegalArgumentException(_fieldName + " should be valid integer");
				}
			} else {
				throw new IllegalArgumentException(_fieldName + " should be valid integer");
			}
		}
		return i;
	}

	/**
	 * Validates the cfArrayData value. If the input Object is instance of cfArrayData then it's valid else throws IllegalArgumentException.
	 * 
	 * @param _value
	 * @param _fieldName
	 * @return cfData value.
	 */
	public static cfData parseCfArrayData(Object _value, String _fieldName) {
		cfArrayData i = null;
		if (_value != null) {
			if (_value instanceof cfArrayData) {
				i = (cfArrayData) _value;
			} else {
				throw new IllegalArgumentException(_fieldName + " should be valid cfArrayData");
			}
		}
		return i;
	}

	/**
	 * Validates the PercentComplete value. Input Object is instance of Double or Integer in between 0 and 100 both inclusive,it's valid. If the input Object is instance of String representing valid Integer or Double in between 0 and 100 both inclusive,it's valid. else throws IllegalArgumentException.
	 * 
	 * @param percentComplete
	 * @return String(PercentComplete value)
	 */

	public static String parsePercentComplete(Object percentComplete) {
		String i = null;
		if (percentComplete != null) {
			// percentComplete can be of Double or String (i.e. String input representing valid Double.)
			if (percentComplete instanceof String) {
				try {
					percentComplete = Double.parseDouble(percentComplete.toString());
				} catch (NumberFormatException e) {
					throw new IllegalArgumentException("PercentComplete must be an integer between 0 and 100.");
				}
			}

			if (percentComplete instanceof Double || percentComplete instanceof Integer) {
				double val = Double.parseDouble(percentComplete + "");
				if (val >= 0 && val <= 100) {
					i = percentComplete.toString();
				} else {
					throw new IllegalArgumentException("PercentComplete must be an integer between 0 and 100.");
				}
			} else {
				throw new IllegalArgumentException("PercentComplete must be an integer between 0 and 100.");
			}
		}
		return i;
	}

	/**
	 * Validating the <b>Attendees</b> array.If array is blank, throws IllegalArgumentException.
	 * 
	 * @param _attendees
	 * @param _fieldName
	 */
	public static void parseAttendees(cfArrayData _attendees, String _fieldName) {
		if (_attendees.size() == 0) {
			throw new IllegalArgumentException(_fieldName + " Array should not be blank.");
		}
	}

	/**
	 * Validates the FreeBusyStatus value. If input is not one of these values (case sensitive): <b>"Free, Tentative, Busy, OOF, NoData"</b> throws IllegalArgumentException.
	 * 
	 * @param _status
	 * @return String(FreeBusyStatus value)
	 */
	public static String parseFreeBusyStatus(String _status) {
		if (_status != null) {
			Integer position = freeBusyStatusValues.get(_status);
			if (position == null) {
				throw new IllegalArgumentException("Status Value should be one of these: " + FREE_BUSY_STATUS_VALUES);
			}
		}
		return _status;
	}

	/**
	 * Validates the Sensitivity value. If input is not one of these values (case sensitive): <b>"Normal, Personal, Private, Confidential"</b> throws IllegalArgumentException.
	 * 
	 * @param _val
	 * @return String(Sensitivity value)
	 */
	public static String parseSensitivity(String _val) {
		String s = null;
		if (_val != null) {
			if ("Normal".equalsIgnoreCase(_val)) {
				s = "Normal";
			} else if ("Personal".equalsIgnoreCase(_val)) {
				s = "Personal";
			} else if ("Private".equalsIgnoreCase(_val)) {
				s = "Private";
			} else if ("Confidential".equalsIgnoreCase(_val)) {
				s = "Confidential";
			} else {
				throw new IllegalArgumentException("Sensitivity value should be one of these: " + SENSITIVITY_VALUES);
			}
		}
		return s;
	}

	/**
	 * Validates the BodyType value. Default BodyType value "HTML" if input is null. If input is not one of these values (case sensitive): <b>"HTML, Text"</b> throws IllegalArgumentException.
	 * 
	 * @param _val
	 * @return String(BodyType value i.e. "HTML", "Text")
	 */
	public static String parseBodyType(String _val) {
		String s = "HTML";
		// Default value of BodyType "HTML"
		if (_val != null) {
			if ("HTML".equals(_val) || "Text".equals(_val)) {
				s = _val;
			} else {
				throw new IllegalArgumentException("BodyType value should be one of these (case sensitive): " + BODYTYPE_VALUES);
			}
		}
		return s;
	}

	/**
	 * Validates the SendMeetingCancellations value. Returns null,If input is null, If input is not one of these values (case sensitive): <b>"SendToNone, SendOnlyToAll, SendToAllAndSaveCopy"</b> throws IllegalArgumentException.
	 * 
	 * @param _val
	 * @return String(SendMeetingCancellations value)
	 */
	public static String parseSendMeetingCancellations(String _val) {
		String type = null;
		if (_val != null) {
			if ("SendToNone".equals(_val) || "SendOnlyToAll".equals(_val) || "SendToAllAndSaveCopy".equals(_val)) {
				type = _val;
			} else {
				throw new IllegalArgumentException("SendMeetingCancellations value should be one of these (case sensitive): SendToNone,SendOnlyToAll,SendToAllAndSaveCopy");
			}
		}
		return type;
	}

	/**
	 * Validates the AffectedTaskOccurrences value. Returns null,If input is null, If input is not one of these values (case sensitive): <b>"AllOccurrences, SpecifiedOccurrenceOnly"</b> throws IllegalArgumentException.
	 * 
	 * @param _val
	 * @return String(AffectedTaskOccurrences value)
	 */
	public static String parseAffectedTaskOccurrences(String _val) {
		String type = null;

		if (_val != null) {
			if ("AllOccurrences".equals(_val) || "SpecifiedOccurrenceOnly".equals(_val)) {
				type = _val;
			} else {
				throw new IllegalArgumentException("AffectedTaskOccurrences value should be one of these (case sensitive): AllOccurrences,SpecifiedOccurrenceOnly.");
			}
		}
		return type;
	}

	/**
	 * Validates the Conference Type value. Returns null,If input is null, If input is not one of these values (case sensitive): <b>"NetMeeting, NetShow, Chat"</b> throws IllegalArgumentException.
	 * 
	 * @param confType
	 * @return Integer(Value corresponding to the Conference Type)
	 */

	public static Integer parseConferenceType(String confType) {
		Integer type = null;
		if (confType != null) {
			if ("NetMeeting".equals(confType)) {
				type = 0;
			} else if ("NetShow".equals(confType)) {
				type = 1;
			} else if ("Chat".equals(confType)) {
				type = 2;
			} else {
				throw new IllegalArgumentException("ConferenceType value should be one of these (case sensitive): NetMeeting, NetShow, Chat");
			}
		}
		return type;
	}

	/**
	 * Returns the Conference Type for the corresponding Integer value given in the input. Returns null, If input is null.
	 * 
	 * @param confTypeIndex
	 * @return String(Conference Type)
	 */

	public static String parseConferenceType(Integer confTypeIndex) {
		String type = null;
		if (confTypeIndex != null) {
			if ("0".equals(confTypeIndex.toString())) {
				type = "NetMeeting";
			} else if ("1".equals(confTypeIndex.toString())) {
				type = "NetShow";
			} else if ("2".equals(confTypeIndex.toString())) {
				type = "Chat";
			}
		}
		return type;
	}

	/**
	 * Validates the DisplayName of email. Returns blank string, if name is not provided in the input. If name provided in the input is not the in String format,throws exception.
	 * 
	 * @param attendees
	 * @param _fieldName
	 * @return String(DisplayName in the input)
	 * @throws dataNotSupportedException
	 */
	public static String parseDisplayName(cfStructData attendees, String _fieldName) throws dataNotSupportedException {
		String displayName;
		// displayName is Blank if input not provided.
		if ((attendees.getData("name") == null)) {
			displayName = "";
		}
		// Should be provided as the String.
		else if (!(attendees.getData("name") instanceof cfStringData)) {
			throw new IllegalArgumentException(_fieldName + " should be String value.");
		} else {
			displayName = attendees.getData("name").getString();
		}

		return displayName;
	}

	/**
	 * Validates the Email value. If the input is null or not in the string format or not in a valid email format throws IllegalArgumentException
	 * 
	 * @param attendees
	 * @param _fieldName
	 * @return String(Email value)
	 */
	public static String parseEmail(cfStructData attendees, String _fieldName) {
		Object _email = attendees.getData("email");
		// Should be provided as the String.
		if ((_email != null) && (_email instanceof cfStringData)) {
			if (!validateEmail(_email.toString())) {
				throw new IllegalArgumentException(_fieldName + " should be in valid format.");
			}
		} else {
			throw new IllegalArgumentException(_fieldName + " should not be null / blank");
		}
		return _email.toString();
	}

	/**
	 * Validates Email String. If the string satisfies following conditions 1.String should not contain A whitespace characters: [ \t\n\x0B\f\r] 2.@ symbol is required in the input string , It's valid, else throws exception.
	 * 
	 * @param _email
	 * @return Boolean value.
	 */
	public static Boolean validateEmail(String _email) {
		String expression = "\\S+@\\S+";
		Pattern pattern = Pattern.compile(expression, Pattern.CASE_INSENSITIVE);
		Matcher matcher = pattern.matcher(_email);

		return matcher.matches();
	}

	/**
	 * Parses the Soap response from the Server to get the Error message text in case the Operation on the Items fails.
	 * 
	 * @param _respObj
	 * @return cfData containing the Error Message Text.
	 */
	@SuppressWarnings("unchecked")
	public static cfData getErrorMessage(List<Map<String, Object>> _respObj) {
		Map<String, cfData> newmap = new HashMap<String, cfData>();
		Object messageText = null;
		Map<String, Object> h = _respObj.get(0);
		List<Map<String, Object>> a = (List<Map<String, Object>>) h.get("messagetext");

		// Parses the Error response properly in case of deletion of the Item
		if (a == null) {
			a = (List<Map<String, Object>>) h.get("deleteitemresponsemessage");
			Map<String, Object> m = (Map<String, Object>) a.get(0);
			List<Map<String, Object>> b = (List<Map<String, Object>>) m.get("messagetext");
			Map<String, Object> n = (Map<String, Object>) b.get(0);
			messageText = n.get("value");
		} else {
			Map<String, Object> m = (Map<String, Object>) a.get(0);
			messageText = m.get("value");
		}
		newmap.put("messagetext", new cfStringData(messageText.toString()));
		return new cfStructData(newmap);
	}

	/**
	 * Validates the Search Mode value. Returns null If input is null . If input is not one of these values (case sensitive): <b>"Fullstring, Prefixed, Substring, PrefixOnWords, ExactPhrase"</b> throws IllegalArgumentException.
	 * 
	 * @param _searchmode
	 * @return String(Search Mode value)
	 */
	public static String parseSearchMode(String _searchmode) {
		String i = null;

		if (_searchmode != null) {
			i = searchModeValues.get(_searchmode.toLowerCase());
			if (i == null) {
				throw new IllegalArgumentException("SearchMode value should be one of these: " + SEARCHMODE_VALUES);
			}
		}
		return i;
	}

	/**
	 * Validates the Base Point value. Returns null If input is null . If input is not one of these values (case sensitive): <b>"Beginning, End"</b> throws IllegalArgumentException.
	 * 
	 * @param _basepoint
	 * @return String(Base Point value)
	 */
	public static String parseBasePoint(String _basepoint) {
		String i = null;
		if (_basepoint != null) {
			if ("Beginning".equalsIgnoreCase(_basepoint)) {
				i = "Beginning";
			} else if ("End".equalsIgnoreCase(_basepoint)) {
				i = "End";
			} else {
				throw new IllegalArgumentException("BasePoint value should be one of these: " + BASEPOINT_VALUES);
			}
		}
		return i;
	}

	/**
	 * Validates the Limit for the number of Items to be displayed in the output. If input is less than or equal to zero it throws IllegalArgumentException.
	 * 
	 * @param _value
	 * @param _fieldName
	 * @return Integer(EntriesLimit value)
	 */

	public static Integer parseEntriesLimit(Object _value, String _fieldName) {
		Integer i = null;
		if (_value != null) {
			if (_value instanceof Integer) {
				i = (Integer) _value;
				if (i <= 0) {
					throw new IllegalArgumentException(_fieldName + " should be valid integer greater or equal to 1");
				}
			} else if (_value instanceof String) {
				try {
					i = Integer.parseInt(_value.toString());
				} catch (NumberFormatException e) {
					throw new IllegalArgumentException(_fieldName + " should be valid integer greater or equal to 1");
				}
			} else {
				throw new IllegalArgumentException(_fieldName + " should be valid integer greater or equal to 1");
			}
		}
		return i;
	}

	/**
	 * Parses the XML response from the Exchange Server into cfData
	 * 
	 * @param contacts
	 * @param _responseType
	 * @return cfData containing the parsed response.
	 */
	@SuppressWarnings("unchecked")
	public static cfData parseResponse(List<Map<String, Object>> contacts, String _responseType) {
		Map<String, cfData> newmap = new HashMap<String, cfData>();

		if (contacts.size() > 0 && contacts.get(0).get("messagetext") == null) {
			Map<String, Object> h = contacts.get(0);
			List<Map<String, Map<String, String>>> a = (List<Map<String, Map<String, String>>>) h.get(_responseType);

			Map<String, Map<String, String>> m = (Map<String, Map<String, String>>) a.get(0);
			Map<String, String> attributes = (Map<String, String>) m.get("attributes");

			for (Entry<String, String> entry : attributes.entrySet()) {
				newmap.put(entry.getKey(), new cfStringData(entry.getValue().toString()));
			}

		} else {
			cfData errorMessage = new cfStructData();

			// getErrorMessage() handles the Error response from the server and retrieves the Error Message text.
			errorMessage = ExchangeUtility.getErrorMessage(contacts);
			return errorMessage;
		}

		return new cfStructData(newmap);
	}

	/**
	 * Validates the Offset for the Search Soap Template. If _value is less than zero it throws IllegalArgumentException.
	 * 
	 * @param _value
	 * @param _fieldName
	 * @return Integer(Offset value)
	 */
	public static Integer parseOffset(Object _value, String _fieldName) {
		Integer i = null;
		if (_value != null) {
			if (_value instanceof Integer) {
				i = (Integer) _value;
				if (i < 0) {
					throw new IllegalArgumentException(_fieldName + " should be valid integer greater than or equal to 0");
				}
			} else if (_value instanceof String) {
				try {
					i = Integer.parseInt(_value.toString());
				} catch (NumberFormatException e) {
					throw new IllegalArgumentException(_fieldName + " should be valid integer greater than or equal to 0");
				}
			} else {
				throw new IllegalArgumentException(_fieldName + " should be valid integer greater than or equal to 0");
			}
		}
		return i;
	}
}

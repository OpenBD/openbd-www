/* 
 *  Copyright (C) 2000 - 2011 aw2.0 Ltd
 *
 *  This file is part of Open BlueDragon (OpenBD) CFML Server Engine.
 *  
 *  OpenBD is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  Free Software Foundation,version 3.
 *  
 *  OpenBD is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  
 *  You should have received a copy of the GNU General Public License
 *  along with OpenBD.  If not, see http://www.gnu.org/licenses/
 *  
 *  Additional permission under GNU GPL version 3 section 7
 *  
 *  If you modify this Program, or any covered work, by linking or combining 
 *  it with any of the JARS listed in the README.txt (or a modified version of 
 *  (that library), containing parts covered by the terms of that JAR, the 
 *  licensors of this Program grant you additional permission to convey the 
 *  resulting work. 
 *  README.txt @ http://www.openbluedragon.org/license/README.txt
 *  
 *  http://www.openbluedragon.org/
 */

package net.aw20.openbd.plugins.exchange.functions;

import java.util.List;
import java.util.Map;

import net.aw20.msexchange.MSExchangeConnector;
import net.aw20.msexchange.MSExchangeException;
import net.aw20.msexchange.MSExchangeRequest;
import net.aw20.msexchange.soap.calendar.DeleteCalendarItem;
import net.aw20.openbd.plugins.exchange.helpers.ExchangeConnectionFactory;
import net.aw20.openbd.plugins.exchange.helpers.ExchangeItemUtility;
import net.aw20.openbd.plugins.exchange.helpers.ExchangeUtility;

import com.naryx.tagfusion.cfm.engine.cfArgStructData;
import com.naryx.tagfusion.cfm.engine.cfArrayData;
import com.naryx.tagfusion.cfm.engine.cfBooleanData;
import com.naryx.tagfusion.cfm.engine.cfData;
import com.naryx.tagfusion.cfm.engine.cfSession;
import com.naryx.tagfusion.cfm.engine.cfStructData;
import com.naryx.tagfusion.cfm.engine.cfmRunTimeException;

public class ExchangeDeleteCalendarItem extends ExchangeDeleteTask {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ExchangeDeleteCalendarItem() {
		min = max = 2;

		setNamedParams(new String[] { "connection", "inputData" });
	}

	/**
	 * This method gives openbd plug-in parameter information to CFM
	 * 
	 * @return String[] (Description about all parameters)
	 */
	public String[] getParamInfo() {
		return new String[] { "connection - Provide proper connection object to communate with Exchange server", "inputData structure contains Different Id's and SendMeetingCancellations (which is optional)." };
	}

	/**
	 * This method gives openbd plug-in functionality information to CFM
	 * 
	 * @return Map (Containing CFM output)
	 */
	@SuppressWarnings("unchecked")
	public java.util.Map getInfo() {
		return makeInfo("ms-exchange", "Deletes Calendar item", ReturnType.STRUCTURE);
	}

	/**
	 * Converts the XML Response to the CFML Output. It gives output <b>TRUE</b> in case the deletion is successful else it returns the <b>Error Message Text</b>
	 * 
	 * @param _session
	 * @param argStruct
	 * @return TRUE(cfBooleanData) in case the deletion is successful else the Error Message Text(cfData)
	 * @throws cfmRunTimeException
	 */
	public cfData execute(cfSession _session, cfArgStructData argStruct) throws cfmRunTimeException {

		String connection = getNamedStringParam(argStruct, "connection", "");
		MSExchangeConnector conn = ExchangeConnectionFactory.getConnection(connection);

		if (conn != null) {

			try {
				cfStructData _condition = ExchangeUtility.parseInputData((cfStructData) getNamedParam(argStruct, "inputData"));
				DeleteCalendarItem deleteCalendarItem = new DeleteCalendarItem();
				deleteCalendarItem.setDeletePattern(_condition);
				MSExchangeRequest req = new MSExchangeRequest(deleteCalendarItem);
				List<Map<String, Object>> task = (List<Map<String, Object>>) req.call(conn);
				cfArrayData parsedArray = ExchangeItemUtility.parse(task);
				String result = parsedArray.getData(1).getData("attributes").getData("responseclass").getString();
				if ("Error".equals(result)) {

					cfData errorMessage = new cfStructData();

					// getErrorMessage() handles the Error response from the server and retrieves the Error Message text.
					errorMessage = ExchangeUtility.getErrorMessage(task);
					return errorMessage;
				} else {
					return cfBooleanData.TRUE;
				}
			} catch (MSExchangeException exception) {
				throw new cfmRunTimeException(_session, exception);
			}
		}
		return cfBooleanData.FALSE;
	}
}
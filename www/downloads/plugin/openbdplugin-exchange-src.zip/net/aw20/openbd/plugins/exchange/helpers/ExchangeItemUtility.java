/* 
 *  Copyright (C) 2000 - 2011 aw2.0 Ltd
 *
 *  This file is part of Open BlueDragon (OpenBD) CFML Server Engine.
 *  
 *  OpenBD is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  Free Software Foundation,version 3.
 *  
 *  OpenBD is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  
 *  You should have received a copy of the GNU General Public License
 *  along with OpenBD.  If not, see http://www.gnu.org/licenses/
 *  
 *  Additional permission under GNU GPL version 3 section 7
 *  
 *  If you modify this Program, or any covered work, by linking or combining 
 *  it with any of the JARS listed in the README.txt (or a modified version of 
 *  (that library), containing parts covered by the terms of that JAR, the 
 *  licensors of this Program grant you additional permission to convey the 
 *  resulting work. 
 *  README.txt @ http://www.openbluedragon.org/license/README.txt
 *  
 *  http://www.openbluedragon.org/
 */

package net.aw20.openbd.plugins.exchange.helpers;

import java.text.ParseException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import net.aw20.msexchange.MSExchangeException;

import org.apache.commons.lang.StringEscapeUtils;

import com.naryx.tagfusion.cfm.engine.cfArrayData;
import com.naryx.tagfusion.cfm.engine.cfArrayListData;
import com.naryx.tagfusion.cfm.engine.cfData;
import com.naryx.tagfusion.cfm.engine.cfStringData;
import com.naryx.tagfusion.cfm.engine.cfStructData;
import com.naryx.tagfusion.cfm.engine.cfmRunTimeException;
import com.naryx.tagfusion.cfm.engine.dataNotSupportedException;

public class ExchangeItemUtility {

	/**
	 * Depending on the Item Type <b>(Contact, AllContacts, Task, AllTasks, Calendar, AllCalendars)</b>, the input is parsed to retrieve the fields and its value of the respective Item.
	 * 
	 * @param h
	 * @param _itemType
	 * @return cfStructData(Containing the fields and its value of the Item)
	 * @throws cfmRunTimeException
	 * @throws ParseException
	 */
	public static cfStructData createItem(Map<String, Object> h, String _itemType) throws cfmRunTimeException, MSExchangeException {
		cfStructData parsedStruct = parse(h);

		cfStructData item = new cfStructData();

		cfArrayData itemArray = null;

		if ("Contact".equalsIgnoreCase(_itemType)) {
			itemArray = ((cfArrayData) parsedStruct.getData("contact"));
			fillContactItem(item, itemArray);

		} else if ("AllContacts".equalsIgnoreCase(_itemType)) {
			itemArray = ((cfArrayData) parsedStruct.getData("contact"));
			fillContactItem(item, itemArray);

		} else if ("Task".equalsIgnoreCase(_itemType)) {
			itemArray = ((cfArrayData) parsedStruct.getData("task"));
			fillTaskItem(item, itemArray);

		} else if ("AllTasks".equalsIgnoreCase(_itemType)) {
			itemArray = ((cfArrayData) parsedStruct.getData("task"));
			fillTaskItem(item, itemArray);

		} else if ("Calendar".equalsIgnoreCase(_itemType)) {
			itemArray = ((cfArrayData) parsedStruct.getData("calendaritem"));
			fillCalendarItem(item, itemArray);

		} else if ("AllCalendars".equalsIgnoreCase(_itemType)) {
			itemArray = ((cfArrayData) parsedStruct.getData("calendaritem"));
			fillCalendarItem(item, itemArray);

			// Removes the fields from the item Struct which does not appear in the Response of the List/Search Operation on the CalendarItem
			item.remove("requiredattendees");
			item.remove("optionalattendees");
			item.remove("resources");
			item.remove("conflictingmeetingcount");
		} else {
			throw new IllegalArgumentException("createItem expects only AllTasks, Task, AllCalendars, Calendar, Contact or AllContacts options");
		}

		Object o = getRowObject(itemArray, "attributes");
		if (o != null) {
			item.put("id", parseProperty("id", o));
			item.put("changekey", parseProperty("changekey", o));
		}

		item.put("subject", StringEscapeUtils.unescapeXml(parseProperty("subject", itemArray)));
		item.put("sensitivity", parseProperty("sensitivity", itemArray));
		item.put("importance", parseProperty("importance", itemArray));
		item.put("issubmitted", parseProperty("issubmitted", itemArray));
		item.put("isdraft", parseProperty("isdraft", itemArray));
		item.put("isfromme", parseProperty("isfromme", itemArray));
		item.put("isresend", parseProperty("isresend", itemArray));
		item.put("isunmodified", parseProperty("isunmodified", itemArray));
		item.put("displaycc", parseProperty("displaycc", itemArray));
		item.put("displayto", parseProperty("displayto", itemArray));
		item.put("culture", parseProperty("culture", itemArray));
		item.put("lastmodifiedname", parseProperty("lastmodifiedname", itemArray));
		item.put("isassociated", parseProperty("isassociated", itemArray));
		item.put("datetimecreated", ExchangeUtility.parseToDate(parseProperty("datetimecreated", itemArray)));
		item.put("datetimesent", ExchangeUtility.parseToDate(parseProperty("datetimesent", itemArray)));
		item.put("hasattachments", parseProperty("hasattachments", itemArray));
		item.put("size", parseProperty("size", itemArray));
		item.put("itemclass", parseProperty("itemclass", itemArray));
		item.put("webclienteditformquerystring", parseProperty("webclienteditformquerystring", itemArray));
		item.put("webclientreadformquerystring", parseProperty("webclientreadformquerystring", itemArray));
		item.put("lastmodifiedtime", ExchangeUtility.parseToDate(parseProperty("lastmodifiedtime", itemArray)));
		item.put("conversationid", itemArray.getElement(getRowPosition(itemArray, "conversationid")).getData("attributes").getData("id").getString());

		Integer position = getRowPosition(itemArray, "body");
		if (position != null) {
			item.put("body", StringEscapeUtils.unescapeXml(parseProperty("body", itemArray)));
			item.put("bodytype", itemArray.getElement(position).getData("attributes").getData("bodytype").getString());
		}

		// parsing effectiverights elements into struct
		cfArrayListData o1 = (cfArrayListData) getRowObject(itemArray, "effectiverights");
		cfStructData effectiveStruct = new cfStructData();

		for (int i = 1; i <= o1.size(); i++) {
			cfStructData o2 = (cfStructData) o1.getElement(i);
			effectiveStruct.put(o2.getKeyList(""), parseProperty(o2.getKeyList(""), o2));
		}

		item.put("effectiverights", effectiveStruct);

		return item;
	}

	/**
	 * This method is called when the ItemType is <b>"Contact,AllContacts"</b> . It is concerned with the retrieving of the fields specific to the Contact Item.
	 * 
	 * @param item
	 * @param itemArray
	 * @throws ParseException
	 * @throws cfmRunTimeException
	 */
	private static void fillContactItem(cfStructData item, cfArrayData itemArray) throws MSExchangeException, cfmRunTimeException {

		item.put("name", StringEscapeUtils.unescapeXml(parseProperty("subject", itemArray)));

		item.put("displayname", StringEscapeUtils.unescapeXml(parseProperty("displayname", itemArray)));

		item.put("givenname", StringEscapeUtils.unescapeXml(parseProperty("givenname", itemArray)));

		item.put("middlename", StringEscapeUtils.unescapeXml(parseProperty("middlename", itemArray)));

		item.put("companyname", StringEscapeUtils.unescapeXml(parseProperty("companyname", itemArray)));

		item.put("jobtitle", StringEscapeUtils.unescapeXml(parseProperty("jobtitle", itemArray)));

		item.put("notes", StringEscapeUtils.unescapeXml(parseProperty("body", itemArray)));

		item.put("datetimereceived", ExchangeUtility.parseToDate(parseProperty("datetimereceived", itemArray)));

		// Emails
		Object o1 = getRowObject(itemArray, "emailaddresses");

		if (o1 != null && o1 instanceof cfArrayData) {
			cfArrayData emails = (cfArrayData) o1;
			item.put("emailaddresses", parseEmails(emails));
		}

		// Addresses
		o1 = getRowObject(itemArray, "physicaladdresses");

		if (o1 != null && o1 instanceof cfArrayData) {

			cfArrayData addresses = (cfArrayData) o1;

			for (int i = 1; i <= addresses.size(); i++) {

				Object o2 = addresses.getElement(i);
				if (o2 != null && o2 instanceof cfStructData) {

					cfStructData attr = (cfStructData) o2;
					String key = attr.getData("attributes").getData("key").getString();

					item.put(key.toLowerCase(), parsePhysicalAddress(attr));
				}

			}
		}

		// phone numbers
		o1 = getRowObject(itemArray, "phonenumbers");

		if (o1 != null && o1 instanceof cfArrayData) {
			cfArrayData phonenumbers = (cfArrayData) o1;

			for (int i = 1; i <= phonenumbers.size(); i++) {

				Object o2 = phonenumbers.getElement(i);

				if (o2 != null && o2 instanceof cfStructData) {

					cfStructData str = (cfStructData) o2;

					Object o3 = str.getData("attributes");

					String key = "";
					String value = "";
					if (o3 != null && o3 instanceof cfStructData) {
						cfStructData attr = (cfStructData) o3;
						key = parseProperty("key", attr);
					}

					o3 = str.getData("entry");
					if (o3 != null && o3 instanceof cfArrayData) {
						value = parseProperty("value", o3);
					}

					if (!"".equals(key)) {
						item.put(key.toLowerCase(), StringEscapeUtils.unescapeXml(value));
					}

				}

			}

		}

		item.put("assistantname", StringEscapeUtils.unescapeXml(parseProperty("assistantname", itemArray)));

		item.put("businesshomepage", StringEscapeUtils.unescapeXml(parseProperty("businesshomepage", itemArray)));

		item.put("department", StringEscapeUtils.unescapeXml(parseProperty("department", itemArray)));

		// imaddresses
		o1 = getRowObject(itemArray, "imaddresses");

		String imaddress = "";

		if (o1 != null & o1 instanceof cfArrayData) {
			Object o2 = parseProperty("entry", (cfArrayData) o1);

			if (o2 != null) {
				if (o2 instanceof cfArrayData) {
					imaddress = parseProperty("value", (cfArrayData) o2);
				} else if (o2 instanceof String) {
					imaddress = (String) o2;
				}
			}
		}
		item.put("imaddress", StringEscapeUtils.unescapeXml(imaddress));

		item.put("jobtitle", StringEscapeUtils.unescapeXml(parseProperty("jobtitle", itemArray)));

		item.put("manager", StringEscapeUtils.unescapeXml(parseProperty("manager", itemArray)));

		item.put("officelocation", StringEscapeUtils.unescapeXml(parseProperty("officelocation", itemArray)));

		item.put("postaladdressindex", parseProperty("postaladdressindex", itemArray));

		item.put("surname", StringEscapeUtils.unescapeXml(parseProperty("surname", itemArray)));

		cfArrayData o = (cfArrayData) getRowObject(itemArray, "categories");

		if (o != null) {
			item.put("categories", parseProperty("string", o));
		}

		item.put("reminderisset", parseProperty("reminderisset", itemArray));

		item.put("reminderminutesbeforestart", parseProperty("reminderminutesbeforestart", itemArray));

		item.put("reminderdueby", ExchangeUtility.parseToDate(parseProperty("reminderdueby", itemArray)));

		item.put("fileas", StringEscapeUtils.unescapeXml(parseProperty("fileas", itemArray)));

	}

	/**
	 * This method is called when the ItemType is <b>"Task,AllTasks"</b>. It is concerned with the retrieving of the fields specific to the Task Item.
	 * 
	 * @param item
	 * @param itemArray
	 * @throws dataNotSupportedException
	 * @throws ParseException
	 */
	private static void fillTaskItem(cfStructData item, cfArrayData itemArray) throws dataNotSupportedException, MSExchangeException {
		item.put("changecount", parseProperty("changecount", itemArray));
		item.put("iscomplete", parseProperty("iscomplete", itemArray));
		item.put("percentcomplete", parseProperty("percentcomplete", itemArray));
		item.put("status", parseProperty("status", itemArray));
		item.put("statusdescription", parseProperty("statusdescription", itemArray));
		item.put("startdate", ExchangeUtility.parseToDate(parseProperty("startdate", itemArray)));
		item.put("duedate", ExchangeUtility.parseToDate(parseProperty("duedate", itemArray)));
		item.put("mileage", StringEscapeUtils.unescapeXml(parseProperty("mileage", itemArray)));
		item.put("totalwork", parseProperty("totalwork", itemArray));
		item.put("billinginformation", StringEscapeUtils.unescapeXml(parseProperty("billinginformation", itemArray)));
		item.put("actualwork", parseProperty("actualwork", itemArray));
		item.put("companies", retrieveTaskFields(itemArray, "companies"));
		item.put("contacts", retrieveTaskFields(itemArray, "contacts"));
		item.put("reminderisset", parseProperty("reminderisset", itemArray)); // NC
		item.put("reminderminutesbeforestart", parseProperty("reminderminutesbeforestart", itemArray)); // NC
		item.put("reminderdueby", ExchangeUtility.parseToDate(parseProperty("reminderdueby", itemArray))); // NC
		item.put("isrecurring", parseProperty("isrecurring", itemArray)); // NC
		if ((cfArrayData) getRowObject(itemArray, "recurrence") != null) {
			item.put("recurrence", retrieveRecurrenceField(itemArray, "task"));
		}
		if ("true".equals(parseProperty("iscomplete", itemArray))) {
			item.put("completedate", parseProperty("completedate", itemArray));
		}
	}

	/**
	 * This method is called when the ItemType is <b>"Calendar,AllCalendars"</b>. It is concerned with the retrieving of the fields specific to the Calendar Item.
	 * 
	 * @param item
	 * @param itemArray
	 * @throws ParseException
	 * @throws dataNotSupportedException
	 */
	private static void fillCalendarItem(cfStructData item, cfArrayData itemArray) throws dataNotSupportedException, MSExchangeException {
		item.put("legacyfreebusystatus", parseProperty("legacyfreebusystatus", itemArray));
		item.put("startdate", ExchangeUtility.parseToDate(parseProperty("start", itemArray)));
		item.put("enddate", ExchangeUtility.parseToDate(parseProperty("end", itemArray)));
		item.put("location", StringEscapeUtils.unescapeXml(parseProperty("location", itemArray)));
		item.put("isAllDayEvent", parseProperty("isalldayevent", itemArray));
		item.put("appointmentSequenceNumber", parseProperty("appointmentsequencenumber", itemArray));
		item.put("appointmentState", parseProperty("appointmentstate", itemArray));
		item.put("isMeeting", parseProperty("ismeeting", itemArray));
		item.put("isCancelled", parseProperty("iscancelled", itemArray));
		item.put("requiredattendees", retrieveFieldData(item, itemArray, "requiredattendees"));
		item.put("optionalattendees", retrieveFieldData(item, itemArray, "optionalattendees"));
		item.put("resources", retrieveFieldData(item, itemArray, "resources"));
		item.put("timezone", parseProperty("timezone", itemArray));
		item.put("organizer", retrieveFieldData(item, itemArray, "organizer"));
		item.put("calendaritemtype", parseProperty("calendaritemtype", itemArray));
		item.put("meetingrequestwassent", parseProperty("meetingrequestwassent", itemArray));
		item.put("when", StringEscapeUtils.unescapeXml(parseProperty("when", itemArray)));
		item.put("isresponserequested", parseProperty("isresponserequested", itemArray));
		item.put("datetimestamp", ExchangeUtility.parseToDate(parseProperty("datetimestamp", itemArray)));
		item.put("conflictingmeetingcount", parseProperty("conflictingmeetingcount", itemArray));
		item.put("uid", parseProperty("uid", itemArray));
		item.put("myresponsetype", parseProperty("myresponsetype", itemArray));
		item.put("reminderisset", parseProperty("reminderisset", itemArray)); // NC
		item.put("reminderminutesbeforestart", parseProperty("reminderminutesbeforestart", itemArray)); // NC
		item.put("reminderdueby", ExchangeUtility.parseToDate(parseProperty("reminderdueby", itemArray))); // NC
		item.put("isrecurring", parseProperty("isrecurring", itemArray)); // NC

		if ("".equals(parseProperty("conferencetype", itemArray))) {
			item.put("conferencetype", "");
		} else {
			item.put("conferencetype", ExchangeUtility.parseConferenceType(Integer.parseInt(parseProperty("conferencetype", itemArray))));
		}

		item.put("meetingworkspaceurl", StringEscapeUtils.unescapeXml(parseProperty("meetingworkspaceurl", itemArray)));
		item.put("netshowurl", StringEscapeUtils.unescapeXml(parseProperty("netshowurl", itemArray)));
		item.put("allownewtimeproposal", parseProperty("allownewtimeproposal", itemArray));
		item.put("duration", parseProperty("duration", itemArray));
		cfArrayData o = (cfArrayData) getRowObject(itemArray, "categories");
		if (o != null) {
			item.put("categories", parseProperty("string", o));
		}
		if ("RecurringMaster".equals(parseProperty("calendaritemtype", itemArray)) && getRowObject(itemArray, "recurrence") != null) {
			item.put("recurrence", retrieveRecurrenceField(itemArray, "calendar"));
			item.put("firstoccurrence", retrieveOccurrenceField(itemArray, "firstoccurrence"));
			item.put("lastoccurrence", retrieveOccurrenceField(itemArray, "lastoccurrence"));
			item.put("modifiedoccurrences", retrieveOccurrenceField(itemArray, "modifiedoccurrences"));
			item.put("deletedoccurrences", retrieveOccurrenceField(itemArray, "deletedoccurrences"));
		}

		item.put("StartTimeZone", retrieveZoneField(itemArray, "starttimezone"));
		item.put("EndTimeZone", retrieveZoneField(itemArray, "endtimezone"));

	}

	/**
	 * The method is called when the fieldType is one of the following <b>"requiredattendees,optionalattendees,resources,organizer"</b> for Calendar Item.
	 * 
	 * @param item
	 * @param itemArray
	 * @param fieldType
	 * @return cfStructData containing information about the respective Fields
	 * @throws dataNotSupportedException
	 */

	private static cfStructData retrieveFieldData(cfStructData item, cfArrayData itemArray, String fieldType) throws dataNotSupportedException {
		cfArrayListData fieldList = (cfArrayListData) getRowObject(itemArray, fieldType);

		if (fieldList != null) {
			cfStructData attendeesList = new cfStructData();
			for (int i = 1; i <= fieldList.size(); i++) {
				if ("organizer".equals(fieldType)) {
					cfArrayData o2 = (cfArrayData) fieldList.getElement(i).getData("mailbox");
					attendeesList.put(fieldType + i, parseProperty("name", o2));
				} else {
					cfArrayData o1 = (cfArrayData) fieldList.getElement(i).getData("attendee");
					cfArrayData o2 = (cfArrayData) o1.getElement(1).getData("mailbox");
					attendeesList.put(fieldType + i, StringEscapeUtils.unescapeXml(parseProperty("name", o2)));
				}
			}
			return attendeesList;
		}
		return null;
	}

	/**
	 * Traverses the itemArray and locates the position of the field given in the input.
	 * 
	 * @param itemArray
	 * @param fieldType
	 * @return Integer(position of fieldType in the itemArray)
	 */
	public static Integer getRowPosition(cfArrayData itemArray, String fieldType) {
		if (itemArray != null) {
			for (int i = 1; i <= itemArray.size(); i++) {
				Object o = itemArray.getElement(i);
				if (o != null && o instanceof cfStructData) {

					Object o1 = ((cfStructData) o).get(fieldType);

					if (o1 != null) {
						return (i);
					}
				}
			}
		}
		return null;
	}

	/**
	 * The method is concerned with the retrieval of <b>Recurrence</b> field for both Calendar and Task Item.
	 * 
	 * @param itemArray
	 * @param itemType
	 * @return cfStructData containing information about the Recurrence Field.
	 * @throws dataNotSupportedException
	 */
	private static cfStructData retrieveRecurrenceField(cfArrayData itemArray, String itemType) throws dataNotSupportedException {
		cfArrayData o1 = (cfArrayData) getRowObject(itemArray, "recurrence");
		cfArrayData o2 = null;
		cfStructData recurrenceStruct = new cfStructData();
		String recurrenceName = null;

		// Checks if the Recurrence type in the Output Response is a valid one and accordingly evaluates the recurrence name.
		for (int i = 1; i <= o1.size(); i++) {
			if (getRowPosition(o1, "weeklyrecurrence") != null && getRowPosition(o1, "weeklyrecurrence") == i) {
				o2 = (cfArrayData) o1.getElement(getRowPosition(o1, "weeklyrecurrence")).getData("weeklyrecurrence");
				recurrenceName = "Weekly";
			} else if (getRowPosition(o1, "numberedrecurrence") != null && getRowPosition(o1, "numberedrecurrence") == i) {
				o2 = (cfArrayData) o1.getElement(getRowPosition(o1, "numberedrecurrence")).getData("numberedrecurrence");
			} else if (getRowPosition(o1, "noendrecurrence") != null && getRowPosition(o1, "noendrecurrence") == i) {
				o2 = (cfArrayData) o1.getElement(getRowPosition(o1, "noendrecurrence")).getData("noendrecurrence");
			} else if (getRowPosition(o1, "enddaterecurrence") != null && getRowPosition(o1, "enddaterecurrence") == i) {
				o2 = (cfArrayData) o1.getElement(getRowPosition(o1, "enddaterecurrence")).getData("enddaterecurrence");
			} else if (getRowPosition(o1, "dailyrecurrence") != null && getRowPosition(o1, "dailyrecurrence") == i) {
				o2 = (cfArrayData) o1.getElement(getRowPosition(o1, "dailyrecurrence")).getData("dailyrecurrence");
				recurrenceName = "Daily";
			} else if (getRowPosition(o1, "absolutemonthlyrecurrence") != null && getRowPosition(o1, "absolutemonthlyrecurrence") == i) {
				o2 = (cfArrayData) o1.getElement(getRowPosition(o1, "absolutemonthlyrecurrence")).getData("absolutemonthlyrecurrence");
				recurrenceName = "Monthly";
			} else if (getRowPosition(o1, "relativemonthlyrecurrence") != null && getRowPosition(o1, "relativemonthlyrecurrence") == i) {
				o2 = (cfArrayData) o1.getElement(getRowPosition(o1, "relativemonthlyrecurrence")).getData("relativemonthlyrecurrence");
				recurrenceName = "Monthly";
			} else if (getRowPosition(o1, "absoluteyearlyrecurrence") != null && getRowPosition(o1, "absoluteyearlyrecurrence") == i) {
				o2 = (cfArrayData) o1.getElement(getRowPosition(o1, "absoluteyearlyrecurrence")).getData("absoluteyearlyrecurrence");
				recurrenceName = "Yearly";
			} else if (getRowPosition(o1, "relativeyearlyrecurrence") != null && getRowPosition(o1, "relativeyearlyrecurrence") == i) {
				o2 = (cfArrayData) o1.getElement(getRowPosition(o1, "relativeyearlyrecurrence")).getData("relativeyearlyrecurrence");
				recurrenceName = "Yearly";
			} else if ("task".equals(itemType)) {
				if (getRowPosition(o1, "dailyregeneration") != null && getRowPosition(o1, "dailyregeneration") == i) {
					o2 = (cfArrayData) o1.getElement(getRowPosition(o1, "dailyregeneration")).getData("dailyregeneration");
					recurrenceName = "DailyRegeneration";
				} else if (getRowPosition(o1, "weeklyregeneration") != null && getRowPosition(o1, "weeklyregeneration") == i) {
					o2 = (cfArrayData) o1.getElement(getRowPosition(o1, "weeklyregeneration")).getData("weeklyregeneration");
					recurrenceName = "WeeklyRegeneration";
				} else if (getRowPosition(o1, "monthlyregeneration") != null && getRowPosition(o1, "monthlyregeneration") == i) {
					o2 = (cfArrayData) o1.getElement(getRowPosition(o1, "monthlyregeneration")).getData("monthlyregeneration");
					recurrenceName = "MonthlyRegeneration";
				} else if (getRowPosition(o1, "yearlyregeneration") != null && getRowPosition(o1, "yearlyregeneration") == i) {
					o2 = (cfArrayData) o1.getElement(getRowPosition(o1, "yearlyregeneration")).getData("yearlyregeneration");
					recurrenceName = "YearlyRegeneration";
				}
			}
			for (int j = 1; j <= o2.size(); j++) {
				cfStructData o4 = (cfStructData) o2.getElement(j);
				recurrenceStruct.put(o4.getKeyList(""), parseProperty(o4.getKeyList(""), o4));
			}
		}
		recurrenceStruct.put("RecurrenceType", recurrenceName);
		return recurrenceStruct;
	}

	/**
	 * The method is concerned with the retrieval of <b>Occurrence</b> field for Calendar Item. The occurenceType is one of the following <b>"firstoccurrence,lastoccurrence,modifiedoccurrences,deletedoccurrences"</b>
	 * 
	 * @param itemArray
	 * @param occurenceType
	 * @return cfStructData containing information about the Occurrence Field
	 * @throws dataNotSupportedException
	 */
	private static cfStructData retrieveOccurrenceField(cfArrayData itemArray, String occurenceType) throws dataNotSupportedException {
		cfStructData occurrenceStruct = new cfStructData();
		cfArrayListData o1 = (cfArrayListData) getRowObject(itemArray, occurenceType);
		if (o1 != null) {
			int size = o1.size();
			if ("modifiedoccurrences".equals(occurenceType)) {
				cfStructData occurrenceFinalStruct = new cfStructData();
				for (int i = 1; i <= size; i++) {
					cfArrayListData o4 = (cfArrayListData) o1.getElement(i).getData("occurrence");
					occurrenceStruct = getOccurrenceStruct(o4);
					occurrenceFinalStruct.put("ModifiedRecurrenceItem" + i, occurrenceStruct);
					cfStructData occurrenceStruct1 = new cfStructData();
					occurrenceStruct = occurrenceStruct1;
				}
				return occurrenceFinalStruct;
			} else if ("deletedoccurrences".equals(occurenceType)) {
				for (int i = 1; i <= size; i++) {
					cfArrayListData o3 = (cfArrayListData) o1.getElement(i).getData("deletedoccurrence");
					occurrenceStruct.put("DeletedRecurrenceItem" + i, parseProperty("start", o3));
				}
				return occurrenceStruct;
			}
			return getOccurrenceStruct(o1);
		}
		return null;
	}

	/**
	 * Returns the cfStructData containing properties of the Occurrence field
	 * 
	 * @param o1
	 * @return cfStructData containing properties of the Occurrence field.
	 * @throws dataNotSupportedException
	 */
	private static cfStructData getOccurrenceStruct(cfArrayListData o1) throws dataNotSupportedException {
		cfStructData occurrenceStruct = new cfStructData();
		Object o3 = getRowObject(o1, "attributes");
		if (o3 != null) {
			occurrenceStruct.put("id", parseProperty("id", o3));
			occurrenceStruct.put("changekey", parseProperty("changekey", o3));
		}
		for (int i = 2; i <= o1.size(); i++) {
			cfStructData o2 = (cfStructData) o1.getElement(i);
			occurrenceStruct.put(o2.getKeyList(""), parseProperty(o2.getKeyList(""), o2));
		}
		return occurrenceStruct;
	}

	/**
	 * The method is concerned with the retrieval of <b>StartTimeZone</b> and <b>EndTimeZone</b> field for Calendar Item. The zoneType is one of the following <b>"starttimezone,endtimezone"</b>
	 * 
	 * @param itemArray
	 * @param zoneType
	 * @return cfStructData containing information about the Zone Field
	 */
	private static cfStructData retrieveZoneField(cfArrayData itemArray, String zoneType) {
		cfStructData zoneStruct = new cfStructData();
		if (getRowPosition(itemArray, zoneType) != null) {
			cfStructData o1 = (cfStructData) itemArray.getElement(getRowPosition(itemArray, zoneType)).getData("attributes");
			Object name = o1.getData("name");
			Object id = o1.getData("id");
			zoneStruct.put("id", id);
			zoneStruct.put("name", name);
			return zoneStruct;
		}
		return null;
	}

	/**
	 * The method is concerned with the retrieval of <b>contacts</b> and <b>companies</b> field for Task Item.
	 * 
	 * @param itemArray
	 * @param fieldType
	 * @return cfStructData containing information about contacts and companies field
	 */
	private static cfStructData retrieveTaskFields(cfArrayData itemArray, String fieldType) {
		cfStructData fieldList = new cfStructData();
		if (getRowPosition(itemArray, fieldType) != null) {
			cfStructData o1 = (cfStructData) itemArray.getElement(getRowPosition(itemArray, fieldType));
			cfArrayData o2 = ((cfArrayData) o1.getData(fieldType));
			for (int i = 1; i <= o2.size(); i++) {
				cfData o3 = o2.getElement(i).getData("string");
				cfData o4 = ((cfArrayData) o3).getElement(1).getData("value");
				fieldList.put(fieldType + i, StringEscapeUtils.unescapeXml(o4.toString()));
			}
			return fieldList;
		}
		return null;
	}

	/**
	 * Returns object from cfStructData contained in cfArrayData
	 * 
	 * @param _arr
	 * @param _property
	 * @return object or null if property not found
	 */
	public static Object getRowObject(cfArrayData _arr, String _property) {
		if (_arr != null) {
			for (int i = 1; i <= _arr.size(); i++) {
				Object o = _arr.getElement(i);

				if (o != null && o instanceof cfStructData) {

					Object o1 = ((cfStructData) o).get(_property);

					if (o1 != null) {
						return o1;
					}
				}
			}
		}
		return null;
	}

	/**
	 * Returns string value of property from cfStructData object.
	 * 
	 * @param _property
	 * @param _struct
	 * @return value if found, blank string if cannot be found
	 * @throws dataNotSupportedException
	 */
	public static String parseProperty(String _property, cfStructData _struct) throws dataNotSupportedException {

		Object o = _struct.get(_property);

		return parseProperty(_property, o);
	}

	/**
	 * Returns string value of property from cfArrayData object. If row object is a cfArrayData object, it tries to retrieve the value object from that array
	 * 
	 * @param _property
	 * @param _arr
	 * @return value if found, blank string if cannot be found
	 * @throws dataNotSupportedException
	 */
	public static String parseProperty(String _property, cfArrayData _arr) throws dataNotSupportedException {

		// Need to work out which row this property is at
		// because the Exchange API doesn't return field if null their end....

		Object o = getRowObject(_arr, _property);

		return parseProperty(_property, o);

	}

	/**
	 * Returns string value of property from Object.
	 * 
	 * @param _property
	 * @param _o
	 * @return String value of property
	 * @throws dataNotSupportedException
	 */
	public static String parseProperty(String _property, Object _o) throws dataNotSupportedException {
		if (_o != null) {

			if (_o instanceof String) {
				return (String) _o;
			} else if (_o instanceof cfStringData) {
				return ((cfStringData) _o).getString();
			} else if (_o instanceof cfArrayData) {
				cfArrayData a = (cfArrayData) _o;

				return parseProperty("value", a);
			} else if (_o instanceof cfStructData) {
				cfStructData s = (cfStructData) _o;
				return s.getData(_property).getString();
			}

		}
		return "";
	}

	/**
	 * Return email struct containing emailaddresses and properties from emails cfArrayData object
	 * 
	 * @param emails
	 * @return cfStructData containing emailaddresses and properties from emails
	 * @throws cfmRunTimeException
	 */
	public static cfStructData parseEmails(cfArrayData emails) throws cfmRunTimeException {
		cfStructData email = new cfStructData();

		if (emails != null) {

			for (int i = 1; i <= emails.size(); i++) {

				Object o = emails.getElement(i);

				if (o != null) {

					cfStructData emailStruct = new cfStructData();

					// email objects have an attributes map, and then an entry map for the actual email address

					Object o1 = ((cfStructData) o).getData("attributes");

					String key = "";

					if (o1 != null && o1 instanceof cfStructData) {
						cfStructData attr = (cfStructData) o1;

						key = parseProperty("key", attr);
						emailStruct.put("name", parseProperty("name", attr));
						emailStruct.put("mailboxtype", parseProperty("mailboxtype", attr));
						emailStruct.put("routingtype", parseProperty("routingtype", attr));
					}

					o1 = ((cfStructData) o).getData("entry");
					if (o1 != null && o1 instanceof cfArrayData) {
						o1 = ((cfArrayData) o1).getElement(1);
					}

					if (o1 != null && o1 instanceof cfStructData) {
						cfStructData attr = (cfStructData) o1;
						emailStruct.put("emailaddress", StringEscapeUtils.unescapeXml(parseProperty("value", attr)));
					}

					email.put(key.toLowerCase(), emailStruct);

				}

			}

		}

		return email;
	}

	/**
	 * Adds a field to the passed in cfStructData object from the address array object
	 * 
	 * @param _addField
	 * @param _newAddressStruct
	 * @param _addressArray
	 */
	public static void processAddressLine(String _addField, cfStructData _newAddressStruct, cfArrayData _addressArray) {

		String field = "";
		Object o1 = getRowObject(_addressArray, _addField);

		if (o1 != null && o1 instanceof cfArrayData) {
			Object o2 = getRowObject((cfArrayData) o1, "value");
			if (o2 != null) {
				if (o2 instanceof cfStringData) {
					field = StringEscapeUtils.unescapeXml(((cfStringData) o2).getString());
				} else if (o2 instanceof String) {
					field = StringEscapeUtils.unescapeXml((String) o2);
				}
			}
		}
		_newAddressStruct.put(_addField, field);

	}

	/**
	 * Parses the address from the address array and returns an address struct
	 * 
	 * @param _addressStruct
	 * @return processed address structure
	 * @throws cfmRunTimeException
	 */
	public static cfStructData parsePhysicalAddress(cfStructData _addressStruct) throws cfmRunTimeException {
		cfStructData address = new cfStructData();

		Object o = _addressStruct.getData("entry");

		if (o != null && o instanceof cfArrayData) {

			cfArrayData a = (cfArrayData) o;

			processAddressLine("street", address, a);
			processAddressLine("city", address, a);
			processAddressLine("state", address, a);
			processAddressLine("countryorregion", address, a);
			processAddressLine("postalcode", address, a);

		}

		return address;
	}

	/**
	 * Converts Map object to a cfStructData Object
	 * 
	 * @param h
	 * @return converted cfStructData object
	 * @throws cfmRunTimeException
	 */
	@SuppressWarnings("unchecked")
	public static cfStructData parse(Map<String, Object> h) throws cfmRunTimeException {
		Map<String, cfData> newmap = new HashMap<String, cfData>();
		for (Entry<String, Object> entry : ((Map<String, Object>) h).entrySet()) {
			if (entry.getValue() instanceof List) {
				newmap.put(entry.getKey(), parse((List) entry.getValue()));
			} else if (entry.getValue() instanceof Map) {
				newmap.put(entry.getKey(), parse((Map) entry.getValue()));
			} else {
				newmap.put(entry.getKey(), new cfStringData(entry.getValue().toString()));
			}
		}

		return new cfStructData(newmap);
	}

	/**
	 * Converts an ArrayList object to a cfArrayData Object
	 * 
	 * @param a
	 * @return converted cfArrayData object
	 * @throws cfmRunTimeException
	 */
	@SuppressWarnings("unchecked")
	public static cfArrayData parse(List a) throws cfmRunTimeException {
		cfArrayData arr = cfArrayData.createArray(1);

		for (int i = 0; i < a.size(); i++) {
			Object o = a.get(i);
			if (o instanceof Map) {
				arr.addElement(parse((Map) o));
			} else if (o instanceof List) {
				arr.addElement(parse((List) o));
			} else {
				arr.addElement(new cfStringData(o.toString()));
			}
		}

		return arr;
	}

	/**
	 * Creates a struct containing User information (i.e. Name, Email, culture, displayname, surname, givenname)
	 * 
	 * @param h
	 * @return cfStructData(containing User information)
	 * @throws cfmRunTimeException
	 */
	public static cfStructData fillUserInformation(Map<String, Object> h) throws cfmRunTimeException {
		cfStructData parsedStruct = parse(h);
		cfStructData userInfoStruct = new cfStructData();
		cfArrayData userInfoArray = null;

		userInfoArray = ((cfArrayData) parsedStruct.getData("resolution"));
		cfArrayListData o = (cfArrayListData) ExchangeItemUtility.getRowObject(userInfoArray, "mailbox");
		userInfoStruct.put("name", StringEscapeUtils.unescapeXml(parseProperty("name", o)));
		userInfoStruct.put("email", StringEscapeUtils.unescapeXml(parseProperty("emailaddress", o)));

		cfArrayListData o1 = (cfArrayListData) getRowObject(userInfoArray, "contact");
		userInfoStruct.put("culture", parseProperty("culture", o1));
		userInfoStruct.put("displayname", StringEscapeUtils.unescapeXml(parseProperty("displayname", o1)));
		userInfoStruct.put("surname", StringEscapeUtils.unescapeXml(parseProperty("surname", o1)));
		userInfoStruct.put("givenname", StringEscapeUtils.unescapeXml(parseProperty("givenname", o1)));

		return userInfoStruct;
	}

}

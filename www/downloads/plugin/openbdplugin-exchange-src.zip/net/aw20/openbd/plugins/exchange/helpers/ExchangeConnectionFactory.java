/* 
 *  Copyright (C) 2000 - 2011 aw2.0 Ltd
 *
 *  This file is part of Open BlueDragon (OpenBD) CFML Server Engine.
 *  
 *  OpenBD is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  Free Software Foundation,version 3.
 *  
 *  OpenBD is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  
 *  You should have received a copy of the GNU General Public License
 *  along with OpenBD.  If not, see http://www.gnu.org/licenses/
 *  
 *  Additional permission under GNU GPL version 3 section 7
 *  
 *  If you modify this Program, or any covered work, by linking or combining 
 *  it with any of the JARS listed in the README.txt (or a modified version of 
 *  (that library), containing parts covered by the terms of that JAR, the 
 *  licensors of this Program grant you additional permission to convey the 
 *  resulting work. 
 *  README.txt @ http://www.openbluedragon.org/license/README.txt
 *  
 *  http://www.openbluedragon.org/
 */

package net.aw20.openbd.plugins.exchange.helpers;

import java.util.HashMap;
import java.util.Map;

import net.aw20.msexchange.MSExchangeConnector;

public class ExchangeConnectionFactory {

	private static Map<String, MSExchangeConnector> connections = new HashMap<String, MSExchangeConnector>();

	/**
	 * Registers a MSExchangeConnector connection
	 * 
	 * @param _name
	 * @param _conn
	 */
	public static synchronized void registerConnection(String _name, MSExchangeConnector _conn) {
		connections.put(_name.toLowerCase(), _conn);
	}

	/**
	 * Returns a MSExchangeConnector object which has been previously registered
	 * 
	 * @param _name
	 * @return MSExchangeConnector connection object
	 */
	public static synchronized MSExchangeConnector getConnection(String name) {
		return connections.get(name.toLowerCase());
	}

	/**
	 * Removes a connection from the list of registered connections
	 * 
	 * @param _name
	 */
	public static synchronized void removeConnection(String name) {
		connections.remove(name);
	}
}

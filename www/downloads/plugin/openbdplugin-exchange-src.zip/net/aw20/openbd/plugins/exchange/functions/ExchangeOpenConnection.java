/* 
 *  Copyright (C) 2000 - 2011 aw2.0 Ltd
 *
 *  This file is part of Open BlueDragon (OpenBD) CFML Server Engine.
 *  
 *  OpenBD is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  Free Software Foundation,version 3.
 *  
 *  OpenBD is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  
 *  You should have received a copy of the GNU General Public License
 *  along with OpenBD.  If not, see http://www.gnu.org/licenses/
 *  
 *  Additional permission under GNU GPL version 3 section 7
 *  
 *  If you modify this Program, or any covered work, by linking or combining 
 *  it with any of the JARS listed in the README.txt (or a modified version of 
 *  (that library), containing parts covered by the terms of that JAR, the 
 *  licensors of this Program grant you additional permission to convey the 
 *  resulting work. 
 *  README.txt @ http://www.openbluedragon.org/license/README.txt
 *  
 *  http://www.openbluedragon.org/
 */

package net.aw20.openbd.plugins.exchange.functions;

import net.aw20.msexchange.MSExchangeConnector;
import net.aw20.openbd.plugins.exchange.helpers.ExchangeConnectionFactory;

import com.naryx.tagfusion.cfm.engine.cfArgStructData;
import com.naryx.tagfusion.cfm.engine.cfData;
import com.naryx.tagfusion.cfm.engine.cfSession;
import com.naryx.tagfusion.cfm.engine.cfStringData;
import com.naryx.tagfusion.cfm.engine.cfmRunTimeException;
import com.naryx.tagfusion.expression.function.functionBase;

public class ExchangeOpenConnection extends functionBase {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ExchangeOpenConnection() {
		min = max = 5;
		setNamedParams(new String[] { "connection", "url", "domain", "username", "password" });
	}

	/**
	 * This method gives openbd plug-in parameter information to CFM
	 * 
	 * @return String[] (Description about all parameters)
	 */
	public String[] getParamInfo() {
		return new String[] { "connection - Provide proper connection object to communate with Exchange server", "connection, url, domain, username, password" };
	}

	/**
	 * This method gives openbd plug-in functionality information to CFM
	 * 
	 * @return Map (Containing CFM output)
	 */
	@SuppressWarnings("unchecked")
	public java.util.Map getInfo() {
		return makeInfo("ms-exchange", "Open the conection with EWS", ReturnType.STRUCTURE);
	}

	/**
	 * Makes request to the Exchange Server to open the connection with EWS
	 * 
	 * @param _session
	 * @param argStruct
	 * @return cfData contains connection configuration details
	 * @throws cfmRunTimeException
	 */
	public cfData execute(cfSession _session, cfArgStructData argStruct) throws cfmRunTimeException {

		String connection = getNamedStringParam(argStruct, "connection", null);
		String url = getNamedStringParam(argStruct, "url", null);
		String domain = getNamedStringParam(argStruct, "domain", null);
		String username = getNamedStringParam(argStruct, "username", null);
		String password = getNamedStringParam(argStruct, "password", null);

		if (connection == null) {
			throwException(_session, "You must specify a name for this connection.");
		}

		// Validate url
		validateUrl(_session, url);

		MSExchangeConnector conn = new MSExchangeConnector(url, username, password, domain);

		ExchangeConnectionFactory.registerConnection(connection, conn);

		return getNamedParam(argStruct, "connection", new cfStringData(""));

	}

	/**
	 * Validates the url to make sure it starts with http(s):// and contains a / so the hostname can be extracted.
	 * 
	 * @param _session
	 * @param _url
	 * @throws cfmRunTimeException
	 */
	private void validateUrl(cfSession _session, String _url) throws cfmRunTimeException {

		if (_url == null) {
			throwException(_session, "You must specify a valid url for this connection e.g. https://owa.myserver.com/ews/exchange.asmx");
		} else {

			boolean valid = false;
			int index = _url.indexOf("://");
			if (index != -1) {
				// removing the http(s):// from beginning of url
				String s = _url.substring(index + 3);
				index = s.indexOf("/");
				if (index != -1) {
					// url is valid as we are able to extract hostname from url e.g. owa.myserver.com from
					// https://owa.myserver.com/ews/exchange.asmx
					valid = true;
				}
			}

			if (!valid) {
				throwException(_session, "You must specify a valid url for this connection e.g. https://owa.myserver.com/ews/exchange.asmx");
			}
		}
	}

}

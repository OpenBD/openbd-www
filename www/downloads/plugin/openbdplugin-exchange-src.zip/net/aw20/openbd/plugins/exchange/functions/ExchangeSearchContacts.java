/* 
 *  Copyright (C) 2000 - 2011 aw2.0 Ltd
 *
 *  This file is part of Open BlueDragon (OpenBD) CFML Server Engine.
 *  
 *  OpenBD is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  Free Software Foundation,version 3.
 *  
 *  OpenBD is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  
 *  You should have received a copy of the GNU General Public License
 *  along with OpenBD.  If not, see http://www.gnu.org/licenses/
 *  
 *  Additional permission under GNU GPL version 3 section 7
 *  
 *  If you modify this Program, or any covered work, by linking or combining 
 *  it with any of the JARS listed in the README.txt (or a modified version of 
 *  (that library), containing parts covered by the terms of that JAR, the 
 *  licensors of this Program grant you additional permission to convey the 
 *  resulting work. 
 *  README.txt @ http://www.openbluedragon.org/license/README.txt
 *  
 *  http://www.openbluedragon.org/
 */

package net.aw20.openbd.plugins.exchange.functions;

import java.util.List;
import java.util.Map;

import net.aw20.msexchange.MSExchangeConnector;
import net.aw20.msexchange.MSExchangeException;
import net.aw20.msexchange.MSExchangeRequest;
import net.aw20.msexchange.soap.contacts.SearchContacts;
import net.aw20.openbd.plugins.exchange.helpers.ExchangeConnectionFactory;
import net.aw20.openbd.plugins.exchange.helpers.ExchangeItemUtility;
import net.aw20.openbd.plugins.exchange.helpers.ExchangeUtility;

import org.apache.commons.lang.StringEscapeUtils;

import com.naryx.tagfusion.cfm.engine.cfArgStructData;
import com.naryx.tagfusion.cfm.engine.cfArrayData;
import com.naryx.tagfusion.cfm.engine.cfData;
import com.naryx.tagfusion.cfm.engine.cfSession;
import com.naryx.tagfusion.cfm.engine.cfStructData;
import com.naryx.tagfusion.cfm.engine.cfmRunTimeException;
import com.naryx.tagfusion.cfm.engine.dataNotSupportedException;

public class ExchangeSearchContacts extends ExchangeGetContact {

	private static final long serialVersionUID = 1L;

	public static final int SEARCH = 0;

	public static final int LIST = 1;

	public ExchangeSearchContacts() {
		min = max = 2;

		setNamedParams(new String[] { "connection", "inputData" });
	}

	/**
	 * This method gives openbd plug-in parameter information to CFM
	 * 
	 * @return String[] (Description about all parameters)
	 */
	public String[] getParamInfo() {
		return new String[] { "connection - Provide proper connection object to communate with Exchange server", "inputData - structure contains fields of Contacts to be searched on" };
	}

	/**
	 * This method gives openbd plug-in functionality information to CFM
	 * 
	 * @return Map (Containing CFM output)
	 */
	@SuppressWarnings("unchecked")
	public java.util.Map getInfo() {
		return makeInfo("ms-exchange", "Search contact based on fields", ReturnType.ARRAY);
	}

	/**
	 * Makes request to the Exchange Server, receives the parsed SOAP response and accordingly display it in the CFML Output.
	 * 
	 * @param _session
	 * @param argStruct
	 * @return cfData containing Information about the instances of ContactItem satisfying the search conditions.
	 * @throws cfmRunTimeException
	 */
	public cfData execute(cfSession _session, cfArgStructData argStruct) throws cfmRunTimeException {

		String connection = getNamedStringParam(argStruct, "connection", "");

		MSExchangeConnector conn = ExchangeConnectionFactory.getConnection(connection);

		cfArrayData arr = cfArrayData.createArray(1);

		if (conn != null) {

			try {
				cfStructData _condition = ExchangeUtility.parseInputData((cfStructData) getNamedParam(argStruct, "inputData"));
				SearchContacts allContacts = new SearchContacts();
				setParams(_condition, allContacts);

				MSExchangeRequest req = new MSExchangeRequest(allContacts);
				List<Map<String, Object>> contacts = (List<Map<String, Object>>) req.call(conn);
				if (contacts.size() == 0) {
					for (Map<String, Object> h : contacts) {
						arr.addElement(ExchangeItemUtility.createItem(h, "AllContacts"));
					}
				} else if (contacts.size() > 0 && contacts.get(0).get("messagetext") == null) {
					for (Map<String, Object> h : contacts) {
						arr.addElement(ExchangeItemUtility.createItem(h, "AllContacts"));
					}
				} else {
					cfData errorMessage = new cfStructData();
					errorMessage = ExchangeUtility.getErrorMessage(contacts);
					return errorMessage;
				}
			} catch (MSExchangeException exception) {
				throw new cfmRunTimeException(_session, exception);
			}
		}

		return arr;
	}

	/**
	 * Provides proper input to SearchContacts web service.Thus helps in forming the valid SOAP request template.
	 * 
	 * @param _condition
	 * @param contact
	 * @throws dataNotSupportedException
	 */
	private void setParams(cfStructData _condition, SearchContacts contact) throws dataNotSupportedException {
		contact.initializeConditions(SEARCH);
		contact.setOperator(ExchangeUtility.parseOperator((String) _condition.get("operator")));
		contact.setSearchMode(ExchangeUtility.parseSearchMode((String) _condition.get("searchmode")));
		contact.setEntriesLimit(ExchangeUtility.parseEntriesLimit(_condition.get("limit"), "limit"));
		contact.setOffset(ExchangeUtility.parseOffset(_condition.get("offset"), "offset"));
		contact.setBasePoint(ExchangeUtility.parseBasePoint((String) _condition.get("basepoint")));
		contact.setImportance(ExchangeUtility.parseImportance((String) _condition.get("Importance")));
		contact.setSensitivity(ExchangeUtility.parseSensitivity((String) _condition.get("Sensitivity")));
		contact.setField((String) _condition.get("field"), StringEscapeUtils.escapeXml((String) _condition.get("searchkeyword")));
		contact.setAdditionalFolders(ExchangeUtility.parseCfArrayData(_condition.get("additionalfolders"), "additionalfolders"));
	}

}

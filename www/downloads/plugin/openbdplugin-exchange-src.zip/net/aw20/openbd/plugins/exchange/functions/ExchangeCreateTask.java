/* 
 *  Copyright (C) 2000 - 2011 aw2.0 Ltd
 *
 *  This file is part of Open BlueDragon (OpenBD) CFML Server Engine.
 *  
 *  OpenBD is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  Free Software Foundation,version 3.
 *  
 *  OpenBD is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  
 *  You should have received a copy of the GNU General Public License
 *  along with OpenBD.  If not, see http://www.gnu.org/licenses/
 *  
 *  Additional permission under GNU GPL version 3 section 7
 *  
 *  If you modify this Program, or any covered work, by linking or combining 
 *  it with any of the JARS listed in the README.txt (or a modified version of 
 *  (that library), containing parts covered by the terms of that JAR, the 
 *  licensors of this Program grant you additional permission to convey the 
 *  resulting work. 
 *  README.txt @ http://www.openbluedragon.org/license/README.txt
 *  
 *  http://www.openbluedragon.org/
 */

package net.aw20.openbd.plugins.exchange.functions;

import java.util.List;
import java.util.Map;

import net.aw20.msexchange.MSExchangeConnector;
import net.aw20.msexchange.MSExchangeException;
import net.aw20.msexchange.MSExchangeRequest;
import net.aw20.msexchange.soap.task.CreateTask;
import net.aw20.openbd.plugins.exchange.helpers.ExchangeConnectionFactory;
import net.aw20.openbd.plugins.exchange.helpers.ExchangeUtility;

import com.naryx.tagfusion.cfm.engine.cfArgStructData;
import com.naryx.tagfusion.cfm.engine.cfArrayData;
import com.naryx.tagfusion.cfm.engine.cfData;
import com.naryx.tagfusion.cfm.engine.cfSession;
import com.naryx.tagfusion.cfm.engine.cfStructData;
import com.naryx.tagfusion.cfm.engine.cfmRunTimeException;
import com.naryx.tagfusion.expression.function.functionBase;

public class ExchangeCreateTask extends functionBase {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ExchangeCreateTask() {
		min = max = 2;
		setNamedParams(new String[] { "connection", "inputData" });
	}

	/**
	 * This method gives openbd plug-in parameter information to CFM
	 * 
	 * @return String[] (Description about all parameters)
	 */
	public String[] getParamInfo() {
		return new String[] { "connection - Provide proper connection object to communate with Exchange server", "inputData structure contains list of all Task field elements." };
	}

	/**
	 * This method gives openbd plug-in functionality information to CFM
	 * 
	 * @return Map (Containing CFM output)
	 */
	@SuppressWarnings("unchecked")
	public java.util.Map getInfo() {
		return makeInfo("ms-exchange", "Create new Task item", ReturnType.STRUCTURE);
	}

	/**
	 * Makes request to the Exchange Server, receives the parsed SOAP response and accordingly display it in the CFML Output.
	 * 
	 * @param _session
	 * @param argStruct
	 * @return cfData containing either both the Id and the changekey for the newly created TaskItem or the Error Message Text
	 * @throws cfmRunTimeException
	 */
	public cfData execute(cfSession _session, cfArgStructData argStruct) throws cfmRunTimeException {

		String connection = getNamedStringParam(argStruct, "connection", "");
		MSExchangeConnector conn = ExchangeConnectionFactory.getConnection(connection);
		cfData responseData = null;

		if (conn != null) {
			try {
				cfStructData inputData = ExchangeUtility.parseInputData((cfStructData) getNamedParam(argStruct, "inputData"));
				CreateTask task = new CreateTask();
				setParams(inputData, task);
				MSExchangeRequest req = new MSExchangeRequest(task);
				List<Map<String, Object>> tasks = (List<Map<String, Object>>) req.call(conn);

				responseData = ExchangeUtility.parseResponse(tasks, "task");

			} catch (MSExchangeException exception) {
				throw new cfmRunTimeException(_session, exception);
			}
		}

		return responseData;
	}

	/**
	 * Provides proper input to CreateTask web service.Thus helps in forming the valid SOAP request template.
	 * 
	 * @param inputData
	 * @param task
	 * @throws cfmRunTimeException
	 */
	private void setParams(cfStructData inputData, CreateTask task) throws cfmRunTimeException {
		task.setSubject((String) inputData.get("Subject"));
		task.setBody((String) inputData.get("Body"), ExchangeUtility.parseBodyType((String) inputData.get("BodyType")));
		task.setTaskDueDate(ExchangeUtility.parseDate(inputData.get("DueDate"), "DueDate", true));
		task.setImportance(ExchangeUtility.parseImportance((String) inputData.get("Importance")));
		task.setPercentComplete(ExchangeUtility.parsePercentComplete(inputData.get("PercentComplete")));
		task.setReminderDueBy(ExchangeUtility.parseDate(inputData.get("ReminderDueBy"), "ReminderDueBy", true));
		task.setReminderIsSet(ExchangeUtility.parseBoolean(inputData.get("ReminderIsSet"), "ReminderIsSet"));
		task.setReminderMinutesBeforeStart(ExchangeUtility.parseInt(inputData.get("ReminderMinutesBeforeStart"), "ReminderMinutesBeforeStart"));
		task.setTaskStartDate(ExchangeUtility.parseDate(inputData.get("StartDate"), "StartDate", true));
		task.setStatus(ExchangeUtility.parseStatus((String) inputData.get("Status")));
		task.setCategories((String) inputData.get("Categories"));
		task.setInReplyTo((String) inputData.get("InReplyTo"));
		task.setSensitivity(ExchangeUtility.parseSensitivity((String) inputData.get("Sensitivity")));
		task.setMileage((String) inputData.get("Mileage"));
		task.setBillingInformation((String) inputData.get("BillingInformation"));
		task.setTotalWork(ExchangeUtility.parseInt(inputData.get("TotalWork"), "TotalWork"));
		task.setActualWork(ExchangeUtility.parseInt(inputData.get("ActualWork"), "ActualWork"));

		task.setCompanies((cfArrayData) inputData.get("Companies"));
		task.setContacts((cfArrayData) inputData.get("Contacts"));
		task.setRecurrence((cfStructData) inputData.get("recurrence"), "task");
	}
}

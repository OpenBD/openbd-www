/* 
 *  Copyright (C) 2000 - 2011 aw2.0 Ltd
 *
 *  This file is part of Open BlueDragon (OpenBD) CFML Server Engine.
 *  
 *  OpenBD is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  Free Software Foundation,version 3.
 *  
 *  OpenBD is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  
 *  You should have received a copy of the GNU General Public License
 *  along with OpenBD.  If not, see http://www.gnu.org/licenses/
 *  
 *  Additional permission under GNU GPL version 3 section 7
 *  
 *  If you modify this Program, or any covered work, by linking or combining 
 *  it with any of the JARS listed in the README.txt (or a modified version of 
 *  (that library), containing parts covered by the terms of that JAR, the 
 *  licensors of this Program grant you additional permission to convey the 
 *  resulting work. 
 *  README.txt @ http://www.openbluedragon.org/license/README.txt
 *  
 *  http://www.openbluedragon.org/
 */

package net.aw20.openbd.plugins.exchange;

import java.io.File;

import com.bluedragon.plugin.Plugin;
import com.bluedragon.plugin.PluginManagerInterface;
import com.naryx.tagfusion.cfm.engine.cfEngine;
import com.naryx.tagfusion.xmlConfig.xmlCFML;

public class ExchangePlugin implements Plugin {
	private static File cfExchangeDirectory;

	public String getPluginDescription() {
		return "Exchange Plugin";
	}

	@Override
	public String getPluginName() {
		return "ExchangePlugin";
	}

	@Override
	public String getPluginVersion() {
		return "0.0.0";
	}

	@Override
	public void pluginStart(PluginManagerInterface manager, xmlCFML systemParameters) {
		cfExchangeDirectory = new File(cfEngine.thisPlatform.getFileIO().getWorkingDirectory(), "cfexchange");
		if (!cfExchangeDirectory.isDirectory())
			cfExchangeDirectory.mkdirs();

		manager.registerFunction("ExchangeOpenConnection", "net.aw20.openbd.plugins.exchange.functions.ExchangeOpenConnection");
		manager.registerFunction("ExchangeGetAllContacts", "net.aw20.openbd.plugins.exchange.functions.ExchangeGetAllContacts");
		manager.registerFunction("ExchangeGetContact", "net.aw20.openbd.plugins.exchange.functions.ExchangeGetContact");
		manager.registerFunction("ExchangeCreateTask", "net.aw20.openbd.plugins.exchange.functions.ExchangeCreateTask");
		manager.registerFunction("ExchangeCreateCalendarItem", "net.aw20.openbd.plugins.exchange.functions.ExchangeCreateCalendarItem");
		manager.registerFunction("ExchangeSearchContacts", "net.aw20.openbd.plugins.exchange.functions.ExchangeSearchContacts");
		manager.registerFunction("ExchangeFindFolders", "net.aw20.openbd.plugins.exchange.functions.ExchangeFindFolders");
		manager.registerFunction("ExchangeCloseConnection", "net.aw20.openbd.plugins.exchange.functions.ExchangeCloseConnection");
		manager.registerFunction("ExchangeUpdateContact", "net.aw20.openbd.plugins.exchange.functions.ExchangeUpdateContact");
		manager.registerFunction("ExchangeGetTask", "net.aw20.openbd.plugins.exchange.functions.ExchangeGetTask");
		manager.registerFunction("ExchangeGetAllTasks", "net.aw20.openbd.plugins.exchange.functions.ExchangeGetAllTasks");
		manager.registerFunction("ExchangeUpdateTask", "net.aw20.openbd.plugins.exchange.functions.ExchangeUpdateTask");
		manager.registerFunction("ExchangeSearchTasks", "net.aw20.openbd.plugins.exchange.functions.ExchangeSearchTasks");
		manager.registerFunction("ExchangeDeleteTask", "net.aw20.openbd.plugins.exchange.functions.ExchangeDeleteTask");
		manager.registerFunction("ExchangeGetCalendarItem", "net.aw20.openbd.plugins.exchange.functions.ExchangeGetCalendarItem");
		manager.registerFunction("ExchangeGetAllCalendarItems", "net.aw20.openbd.plugins.exchange.functions.ExchangeGetAllCalendarItems");
		manager.registerFunction("ExchangeSearchCalendarItems", "net.aw20.openbd.plugins.exchange.functions.ExchangeSearchCalendarItems");
		manager.registerFunction("ExchangeUpdateCalendarItem", "net.aw20.openbd.plugins.exchange.functions.ExchangeUpdateCalendarItem");
		manager.registerFunction("ExchangeDeleteCalendarItem", "net.aw20.openbd.plugins.exchange.functions.ExchangeDeleteCalendarItem");
		manager.registerFunction("ExchangeGetUserInfo", "net.aw20.openbd.plugins.exchange.functions.ExchangeGetUserInfo");
	}

	@Override
	public void pluginStop(PluginManagerInterface manager) {
	}

	public static File getWorkingDirectory() {
		return cfExchangeDirectory;
	}

}
